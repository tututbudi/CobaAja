window.AppPlayer = { Version: "1.13.4" };

System.config({
    baseURL: "./",
    paths: {
        "github:*": "jspm_packages/github/*",
        "npm:*": "jspm_packages/npm/*",
        "appPlayerLib/*": "lib/*",
        "modules/*": "modules@1.13.4/*",
        "main-bundles/*": "bundles@1.13.4/*"
    },
    bundles: {
        "main-bundles/layout.js!loadIndicator": ["index.js"],
        "main-bundles/appPlayerLoader.js!loadIndicator": ["appPlayer/loader.js"],
        "main-bundles/appPlayer.js!loadIndicator": ["appPlayer/appPlayerLoader.js"],
        "main-bundles/libLoader.js!loadIndicator": ["appPlayer/libLoader.js"],
        "main-bundles/devextremeLoader.js!loadIndicator": ["appPlayer/devextremeLoader.js"]
    }
});
