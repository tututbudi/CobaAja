System.register("designerLayout/designerLayout.html!github:systemjs/plugin-text@0.0.8.js", [], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      _export("default", "<div class=\"navbar-layout designer-layout\" data-options=\"dxLayout : { name: 'designer' } \">\r\n\r\n    <div class=\"xet-designer-main-slideoutview\" data-bind=\"dxSlideOutView: { menuVisible: menuVisible, swipeEnabled: false }\">\r\n\r\n        <div class=\"layout-header\">\r\n            <div class=\"navbar-container\" data-bind=\"dxNavBar: { focusStateEnabled: false }\" data-options=\"dxCommandContainer: { id: 'global-navigation' }\">\r\n                <div data-options=\"dxTemplate: { name: 'item' }\" data-bind=\"preventNavbarTabSelection: {}, dxAction: $data.isButton ? $data.onExecute : $root.navigateToBaseView, css: { 'virtual-toolbar-content': $data.isButton }\">\r\n                    <!-- ko if: $data.isButton -->\r\n                    <div data-bind=\"dxButton: { icon: $data.icon, showText: false, onClick: $data.onExecute }\"></div>\r\n                    <!-- /ko -->\r\n                    <!-- ko ifnot: $data.isButton -->\r\n                    <!-- ko if: $data.listView -->\r\n                    <span data-bind=\"text: $data.text\" class=\"tab-caption\"></span>\r\n                    <div class=\"drop-down-icon\" data-bind=\"preventNavbarTabSelection: {}, dxAction: $root.navigateToListView, attr: { id: 'nav-btn-' + id }\"></div>\r\n                    <div class=\"popup-container\" data-bind=\"dxPopover: { width: '300px', position: { my: 'center top', at: 'left bottom', of: '#nav-btn-' + id, offset: '0 0' }, showTitle: false, contentTemplate: 'content', fullScreen: false, deferRendering: false, shading: false, closeOnOutsideClick: true, target: null }\"></div>\r\n                    <!-- /ko -->\r\n                    <!-- ko ifnot: $data.listView -->\r\n                    <div data-bind=\"dxButton: { icon: $data.icon, text: $data.text, showText: true, onClick: function() { $context.$root.navigateToView($data.id) } }\"></div>\r\n                    <!-- /ko -->\r\n                    <!-- /ko -->\r\n                </div>\r\n                <div data-options=\"dxTemplate: { name: 'logo' }\" data-bind=\"dxAction: $data.onExecute, attr: { title: $root.title }\" class=\"virtual-toolbar-content logo-container\">\r\n                    <div data-bind=\"text: $root.title, preventNavbarTabSelection: {}\" class=\"logo\"></div>\r\n                </div>\r\n                <div data-options=\"dxTemplate: { name: 'button' }\" data-bind=\"dxAction: $data.onExecute\" class=\"virtual-toolbar-content\">\r\n                    <div data-bind=\"dxButton: $data.button, preventNavbarTabSelection: {}\"></div>\r\n                </div>\r\n            </div>\r\n            <div data-bind=\"dxToolbar: { }\" data-options=\"dxCommandContainer : { id: 'generic-header-toolbar' }\" class=\"header-toolbar\"></div>\r\n        </div>\r\n\r\n        <div data-options=\"dxTemplate: { name: 'menu' }\" class=\"menu-template\">\r\n            <div data-bind=\"dxButton: { text: 'Create Project', onClick: createProject }\"></div>\r\n            <div data-bind=\"dxButton: { text: 'Import Project', onClick: importProject }\"></div>\r\n            <div class=\"xet-label dx-widget\">PROJECTS</div>\r\n            <div data-bind=\"dxList: { dataSource: navigationDataSource, onItemClick: openDesigner, showScrollbar: 'onHover', noDataText: 'No Projects Found', indicateLoading: false }\">\r\n                <div data-options=\"dxTemplate: { name: 'item' }\" data-bind=\"css: { active: $data.JsonUrl === $root.currentProjectUrl }\" class=\"navigation-item\">\r\n                    <table>\r\n                        <tr>\r\n                            <td>\r\n                                <div class=\"xet-label dx-widget\" data-bind=\"text: $data.Name\"></div>\r\n                            </td>\r\n                            <!-- ko if: $data.JsonUrl === $root.currentProjectUrl -->\r\n                            <td>\r\n                                <button data-bind=\"click: $parent.exportProject\">Export</button>\r\n                            </td>\r\n                            <td>\r\n                                <button data-bind=\"click: $parent.deleteProject\">Delete</button>\r\n                            </td>\r\n                            <!-- /ko -->\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </div>\r\n            <div data-bind=\"dxToolbar: { }\" data-options=\"dxCommandContainer : { id: 'generic-layout-toolbar' }\" class=\"menu-toolbar\"></div>\r\n        </div>\r\n\r\n        <div class=\"transition-frame\" data-options=\"dxTransition: { name: 'main', animation: 'slide' }\">\r\n            <div class=\"transition-frame-content\">\r\n                <div class=\"layout-content\" data-options=\"dxContentPlaceholder : { name: 'content', animation: 'view-content-change' }\"></div>\r\n                <div class=\"layout-footer\">\r\n                    <div class=\"view-toolbar-bottom\" data-bind=\"dxToolbar: { }\" data-options=\"dxCommandContainer : { id: 'generic-view-footer' } \">\r\n                        <div data-options=\"dxTemplate: { name: 'item' }\">\r\n                            <div data-bind=\"dxButton: $data.options, xetCurrentViewDeviceButtonHighlighter: {}\"></div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n\r\n    <div class=\"deploy-popover\" data-bind=\"dxPopover: DevExpress.framework.html.DesignerController.deployPopover\">\r\n        <h3>Hybrid/HTML5 App</h3>\r\n        <div>\r\n            <div data-bind=\"dxButton: { text: 'For Debugging', onClick: function() { AppDesigner.GlobalSave.save().then(function() { document.location.href = $root.jsonUrl() + '/Zip/Debug'; }) } }\"></div>\r\n            <div data-bind=\"dxButton: { text: 'For Production', onClick: function() { AppDesigner.GlobalSave.save().then(function() { document.location.href = $root.jsonUrl() + '/Zip/Production'; }) } }\"></div>\r\n            <a href=\"https://www.youtube.com/v/1UwO8HvLdqo?start=4.7&rel=0\" target=\"_blank\"><!-- ko dxIcon: \"tips\" --><!-- /ko -->How to build the app.</a>\r\n        </div>\r\n        <h3>Native App</h3>\r\n        <div>\r\n            <div data-bind=\"dxButton: { text: 'For Android', onClick: function(e) { DevExpress.framework.html.DesignerController.deployPopoverNotReadyHandler(e, 'android'); } }\"></div>\r\n            <div data-bind=\"dxButton: { text: 'For iOS', onClick: function(e) { DevExpress.framework.html.DesignerController.deployPopoverNotReadyHandler(e, 'ios'); } }\"></div>\r\n        </div>\r\n        <h3>Web App</h3>\r\n        <div>\r\n            <div data-bind=\"dxButton: { text: 'Universal Web App', onClick: function(e) { DevExpress.framework.html.DesignerController.deployPopoverNotReadyHandler(e, 'web'); } }\"></div>\r\n        </div>\r\n    </div>\r\n    <div class=\"more-data-providers-popover\" data-bind=\"dxPopover: DevExpress.framework.html.DesignerController.moreProvidersPopover\">\r\n        <div data-bind=\"dxList: {\r\n             items: ['Offline Data', 'Appery', 'Firebase', 'Google Spreadsheet', 'Office 365 Spreadsheet', 'Salesforce Platform', 'SAP ERP', 'SAP CRM'],\r\n             onItemClick: function(e) { DevExpress.framework.html.DesignerController.moreProviderItemClickHandler(e); },\r\n             showDeleteControls: false,\r\n             showReorderControls: false,\r\n             showSelectionControls: false,\r\n             selectionMode: 'none'\r\n            }\"></div>\r\n    </div>\r\n</div>");
    }
  };
});
System.register("designerLayout/designerLayout.less!npm:systemjs-less-plugin@1.8.3.js", [], function() { return { setters: [], execute: function() {} } });

System.registerDynamic("designerLayout/designerLayout.js", ["jquery", "designerLayout/designerLayout.html!text", "designerLayout/designerLayout.less!less", "devextreme/dx.all"], false, function ($__require, $__exports, $__module) {
    var _retrieveGlobal = System.get("@@global-helpers").prepareGlobal($__module.id, null, {
        "jQuery": $__require("jquery"),
        "htmlTemplate": $__require("designerLayout/designerLayout.html!text")
    });

    (function ($__global) {
        (function ($, DX, htmlTemplate, undefined) {
            appendLayout(document.body, htmlTemplate.default || htmlTemplate, "designerLayout");

            ko.bindingHandlers["preventTabSelection"] = {
                init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                    var preventBubbling = function (e) {
                        e.stopPropagation();
                    };
                    $(element).on("mousedown", preventBubbling);
                    ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
                        $(element).off("mousedown", preventBubbling);
                    });
                }
            };

            DX.framework.html.DesignerController = DX.framework.html.NavBarController.inherit({
                ctor: function (options) {
                    DevExpress.animationPresets.clear();
                    this._global = ko.observable();
                    this._functions = ko.observable();
                    this.menuVisible = ko.observable(false);
                    this.lastNavigatedConfigs = {};
                    this.currentNavigationConfig = {};
                    this.currentProjectUrl = this.getUrlParameter("json");
                    options = options || {};
                    options.layoutModel = options.layoutModel || this._createLayoutModel();
                    options.name = "designer";
                    this.callBase(options);
                },
                init: function (options) {
                    var that = this,
                        navbar,
                        originalNavbarRender;
                    this.callBase(options);
                    this._app = options.app;

                    navbar = this.$navbar.dxNavBar("instance");

                    navbar.option("onContentReady", $.proxy(that._initVirtualToolbar, that));
                    $(".xet-designer-main-slideoutview").dxSlideOutView("instance").option("width", "");

                    options.app.on("viewRendered", function (e) {
                        e.viewInfo.renderResult.$markup.find("iframe").each(function (index, frame) {
                            $(frame).load(function (e) {
                                $(frame.contentWindow).on("click", $.proxy(that._frameClickHandler, that));
                            });
                        });
                    });
                    options.app.on("viewDisposing", function (e) {
                        if (e.viewInfo.renderResult) {
                            e.viewInfo.renderResult.$markup.find("iframe").each(function (index, frame) {
                                $(frame.contentWindow).off("click", $.proxy(that._frameClickHandler, that));
                            });
                        }
                    });
                    options.app.on("navigating", function (e) {
                        var navigationOptions = that._app.router.parse.call(that._app.router, e.uri),
                            tabToHighlight = undefined;
                        that.currentNavigationConfig = navigationOptions;
                        $.each(navbar.option("items"), function (index, item) {
                            if (navigationOptions.view === item.baseView) {
                                that.lastNavigatedConfigs[item.baseView] = navigationOptions;
                                tabToHighlight = item;
                                return false;
                            }
                        });
                        navbar.option("selectedItem", tabToHighlight);
                        that._synchronizeListViewSelection();
                    });

                    originalNavbarRender = $.proxy(navbar._render, navbar);
                    navbar._render = function () {
                        originalNavbarRender();
                        that._initDropDownLists.call(that);
                    };
                },
                _frameClickHandler: function () {
                    this.dropDowns.forEach(function (dropDown) {
                        dropDown.popup.hide();
                    });
                },
                getUrlParameter: function (name) {
                    var parameter = RegExp("[?&]" + name + "=([^&]*)").exec(window.location.search);
                    return parameter && decodeURIComponent(parameter[1].replace(/\+/g, " "));
                },
                toggleMenu: function (e) {
                    this.menuVisible(!this.menuVisible());
                    e.jQueryEvent.stopPropagation();
                },
                _listViewSourceRemoving: function (dropDown, key) {
                    var lastConfig = this.lastNavigatedConfigs[dropDown.baseView];
                    if (lastConfig && lastConfig.parameters[dropDown.baseViewKey] === key) {
                        this.lastNavigatedConfigs[dropDown.baseView] = undefined;
                    }
                },
                _initDropDownLists: function () {
                    var that = this;
                    this.dropDowns = [];
                    this.$navbar.find(".drop-down-icon").each(function (e) {
                        var data = ko.dataFor(this),
                            listView = that._app._xetGetView(data.listView),
                            popupElement = $(this).next(),
                            popupContentElement = popupElement.find(".dx-popup-content"),
                            popup = popupElement.dxPopover("instance"),
                            dropDown = {
                            baseView: data.baseView,
                            baseViewKey: data.baseViewKey,
                            listView: data.listView,
                            listViewSource: undefined,
                            popup: popup
                        },
                            listViewSourceRemovingHandler = function (key) {
                            that._listViewSourceRemoving(dropDown, key);
                        };

                        popupContentElement.addClass("drop-down-menu-content");

                        (function () {
                            var viewModel = listView.viewModel({});

                            popup.option("height", "100%");
                            popup.option("onShowing", function (e) {
                                viewModel.viewShowing({});
                                viewModel.viewShown();
                                var wasOnceHovered = false;
                                var loadingInterval = setInterval(function () {
                                    var topHoverElement = $(":hover").last();
                                    if (!$(topHoverElement).hasClass("dx-overlay-wrapper")) {
                                        var isPopupHover = $(popupContentElement).find(topHoverElement).length !== 0;
                                        if (isPopupHover) {
                                            wasOnceHovered = true;
                                        }
                                        if (!isPopupHover && wasOnceHovered) {
                                            popup.hide();
                                            clearInterval(loadingInterval);
                                        }
                                    }
                                }, 1000);
                            });
                            popup.option("onHiding", viewModel.viewHidden);
                            popup.option("animation", {
                                show: { type: "pop", from: { opacity: 1, scale: 0 }, to: { scale: 1 } },
                                hide: { type: "pop", from: { scale: 1 }, to: { scale: 0 } }
                            });

                            that.dropDowns.push(dropDown);

                            popupContentElement[0].appendChild(listView.viewMarkup[0]);
                            viewModel.onViewRendered = function () {
                                dropDown.listViewSource = viewModel[data.listViewSource];
                                dropDown.listViewSource.store().off("removing", listViewSourceRemovingHandler).on("removing", listViewSourceRemovingHandler);
                                dropDown.list = popupContentElement.find(".dx-list").dxList("instance");
                                dropDown.list.option("onContentReady", $.proxy(that._synchronizeListViewSelection, that));
                                dropDown.list.option("onSelectionChanged", $.proxy(that._disableListViewUnselection, that));
                            };
                            ko.applyBindings(viewModel, popupContentElement[0]);
                        })();
                    });
                },
                _disableListViewUnselection: function (e) {
                    if (!e.addedItems.length && e.removedItems.length) {
                        this._synchronizeListViewSelection();
                    }
                },
                _synchronizeListViewSelection: function () {
                    var that = this;
                    this.dropDowns.forEach(function (dropDown) {
                        var currentSelection, targetView, targetItem, keyProperty;
                        if (dropDown.list && dropDown.list.option("items").length) {
                            if (that.currentNavigationConfig.view === dropDown.baseView) {
                                targetView = that.currentNavigationConfig.parameters[dropDown.baseViewKey];
                                keyProperty = dropDown.list.option("dataSource").key();
                                targetItem = dropDown.list.option("items").filter(function (item) {
                                    return item[keyProperty] === targetView;
                                })[0];
                                currentSelection = dropDown.list.option("selectedItems")[0];
                                if (!dropDown.list.option("selectedItems").length || targetItem !== currentSelection) {
                                    dropDown.list.option("selectedItems", [targetItem]);
                                }
                            } else if (dropDown.list.option("selectedItems").length) {
                                dropDown.list.option("selectedItems", []);
                            }
                        }
                    });
                },
                _clearNavigationWidget: function () {
                    var basicItems = [{ location: "before", template: "button", onExecute: $.proxy(this.toggleMenu, this), button: { icon: "menu" } }, { location: "before", template: "logo", onExecute: $.proxy(this.navigateToRoot, this) }];
                    basicItems.forEach(function (item) {
                        item.command = new DevExpress.framework.dxCommand(item);
                    });
                    this.callBase();
                    this._$navigationWidget.dxNavBar("instance").option("items", basicItems);
                },
                _initVirtualToolbar: function () {
                    this._$mainLayout.find(".navbar-container .virtual-toolbar-content").off("click", this._fadeOutFadeIn).on("click", this._fadeOutFadeIn);
                    this.$navbar.find(".virtual-toolbar-content").closest(".dx-tab").addClass("virtual-toolbar");
                },
                _fadeOutFadeIn: function () {
                    var fadeOut = DevExpress.fx.animate(this, { type: "fadeOut", duration: 600 }),
                        fadeIn = DevExpress.fx.animate(this, { type: "fadeIn", duration: 600 });
                    this.animating = this.animating || $.Deferred().resolve();
                    this.animating = $.when(this.animating).then(fadeOut).then(fadeIn);
                },
                _renderCommandsToGlobalToolbar: function ($element, commands, commandManager) {
                    var toolbar, toolbarItems, newItems;
                    if ($element.length > 0 && commands) {
                        toolbar = $element.data().dxToolbar ? $element.dxToolbar("instance") : $element.dxNavBar("instance"), toolbarItems = toolbar.option("items"), newItems = $.map(toolbarItems, function (item) {
                            return item.command ? undefined : item;
                        });
                        toolbar.option("items", newItems);
                        commandManager.renderCommandsToContainers(commands, [$element.dxCommandContainer("instance")]);
                    }
                },
                _showViewImpl: function (viewInfo, direction) {
                    this._renderCommandsToGlobalToolbar(this._$mainLayout.find(".header-toolbar"), viewInfo.commands, this._commandManager);
                    this._renderCommandsToGlobalToolbar(this._$mainLayout.find(".menu-toolbar"), viewInfo.commands, this._commandManager);
                    var that = this;
                    return this.callBase(viewInfo, direction).done(function () {
                        var $toolbar = that._$mainLayout.find(".dx-active-view .dx-toolbar"),
                            toolbar = $toolbar.length && $toolbar.dxToolbar("instance"),
                            items = toolbar && toolbar.option("items"),
                            isToolbarEmpty = !$toolbar.length || !items || !items.length;
                        $(".layout-footer").toggle(!isToolbarEmpty);
                    });
                },
                _updateLayoutTitle: function (viewInfo, defaultTitle) {
                    if (!this._global() && viewInfo.model && viewInfo.model._global) {
                        this._global(viewInfo.model._global);
                    }
                    if (!this._functions() && viewInfo.model && viewInfo.model._functions) {
                        this._functions(viewInfo.model._functions);
                    }
                },
                navigateToRoot: function (e) {
                    e.jQueryEvent.stopPropagation();
                    this._app.navigate("/");
                    this.$navbar.dxNavBar("instance").option("selectedItem", undefined);
                },
                _createLayoutModel: function () {
                    var that = this,
                        viewModel = {
                        menuVisible: that.menuVisible,
                        currentProjectUrl: that.currentProjectUrl,
                        title: ko.computed(function () {
                            var _global = that._global();
                            return _global && _global.title || "Xenarius Designer";
                        }),
                        jsonUrl: ko.computed(function () {
                            var _global = that._global();
                            return _global && _global.json;
                        }),
                        navigateToView: function (viewId) {
                            that._app.navigate(viewId);
                        },
                        navigateToBaseView: function (e) {
                            if (that.lastNavigatedConfigs[e.model.baseView]) {
                                that._app.navigate(that.lastNavigatedConfigs[e.model.baseView]);
                            } else {
                                viewModel.navigateToListView(e);
                            }
                        },
                        navigateToListView: function (e) {
                            var $element = $(e.element);
                            that._fadeOutFadeIn.call($element.hasClass("drop-down-icon") ? $element : $element.find(".tab-caption"));
                            $.each(that.dropDowns, function (index, mapping) {
                                if (mapping.listView === e.model.listView) {
                                    mapping.popup.show();
                                    return false;
                                }
                            });
                        },
                        navigationDataSource: ko.computed(function () {
                            var _global = that._global();
                            return _global && _global.navigationDataSource || {};
                        }),
                        openDesigner: function (e) {
                            var url = "/?json=" + e.itemData.JsonUrl;
                            window.open(url, "_self");
                        },
                        createProject: function (e) {
                            var global = that._global(),
                                functions = that._functions();
                            functions.createProject(e, global);
                        },
                        importProject: function () {
                            var global = that._global();

                            allowedExts = [".xapp"], // [".xapp", ".json"]
                            allowedExtsString = allowedExts.join(",");

                            var $fileInput = $("<input type=\"file\" accept=\"" + allowedExtsString + "\" />");
                            $fileInput.change(function () {
                                var file = this.files[0];
                                if (allowedExts.some(function (ext) {
                                    return AppPlayer.endsWith(file.name, ext);
                                })) {
                                    var reader = new FileReader();
                                    reader.onloadend = function () {
                                        AppDesigner.utils.importAndOpen(global, reader.result);
                                    };
                                    reader.onerror = function (error) {
                                        DevExpress.ui.dialog.alert("There was an error when opening the file selected.", "Unknown Error");
                                    };
                                    reader.readAsText(file);
                                } else {
                                    DevExpress.ui.dialog.alert("Invalid file extension.", "Project Import");
                                }
                            });
                            $fileInput.click();
                        },
                        exportProject: function (project, e) {
                            e.stopPropagation();
                            AppDesigner.GlobalSave.save().done(function () {
                                document.location.href = "/" + project.JsonUrl + "/Export";
                            });
                        },
                        deleteProject: function (project, e) {
                            e.stopPropagation();
                            var global = that._global(),
                                functions = that._functions();
                            DX.ui.dialog.confirm("Are you sure you want to delete current project?", "Delete Project").then(function (dialogResult) {
                                if (dialogResult) {
                                    var jsonUrl = project.JsonUrl;
                                    global.deleteProject({ jsonUrl: jsonUrl }).then(function (success) {
                                        if (success) {
                                            AppDesigner.utils.deletePreviews(jsonUrl);
                                            AppDesigner.GlobalSave.forget();
                                            document.location.href = "/#projectsLoading";
                                        } else {
                                            DX.ui.dialog.alert("There was an error processing your request. Please try again, or contact our support team.", "Unknown Error");
                                        }
                                    });
                                }
                            });
                        },
                        generateAppFromODataServiceViewModel: function () {
                            var functions = that._functions();
                            return functions.createAppFromODataViewModel(functions);
                        }
                    };

                    return viewModel;
                },
                setViewLoadingState: function (viewInfo, direction) {
                    this._updateLayoutTitle(viewInfo, this.DEFAULT_LOADING_TITLE);
                    return this.callBase(viewInfo, direction);
                },
                showView: function (viewInfo, direction) {
                    var that = this;
                    that._updateLayoutTitle(viewInfo);
                    return that.callBase(viewInfo, direction).done(function () {
                        if (that.toolbarController) {
                            that.toolbarController.showViews(that._activeViews);
                        }
                    });
                }
            });
            DX.framework.html.DesignerController.navigationDisabled = ko.observable(false);
            DX.framework.html.DesignerController.disableNavigation = function () {
                DX.framework.html.DesignerController.navigationDisabled(true);
            };
            DX.framework.html.DesignerController.enableNavigation = function () {
                DX.framework.html.DesignerController.navigationDisabled(false);
            };

            DX.framework.html.DesignerController.deployPopoverNotReadyHandler = function (e, what) {
                AppDesigner.GlobalSave.save().done(function () {
                    if (window.ga) {
                        ga("send", "event", "Buttons", "Deploy", what);
                    }
                    DevExpress.ui.notify({
                        message: "We are sorry, you've found a feature that's not ready yet. Only Hybrid/HTML5 deploy is currently available. So far we're collecting statistics to estimate the demand for various features, which helps us implement the most popular features first. Your vote has been counted.",
                        displayTime: 10000,
                        closeOnClick: true,
                        closeOnOutsideClick: true,
                        position: {
                            of: e.element,
                            collision: "flipfit"
                        }
                    });
                });
            };

            var deployPopoverVisible = ko.observable(false),
                deployPopoverTarget = ko.observable();
            DX.framework.html.DesignerController.deployPopover = {
                target: deployPopoverTarget,
                visible: deployPopoverVisible,
                position: "bottom",
                width: 340
            };
            DX.framework.html.DesignerController.toggleDisplayPopover = function (button) {
                deployPopoverTarget(button);
                deployPopoverVisible(!deployPopoverVisible());
            };

            DX.framework.html.DesignerController.moreProviderItemClickHandler = function (e) {
                if (window.ga) {
                    ga("send", "event", "Buttons", "Data Provider", e.itemData);
                }
                DevExpress.ui.notify({
                    message: "We are sorry, you've found a feature that's not ready yet. So far we're collecting statistics to estimate the demand for various features, which helps us implement the most popular features first. Your vote has been counted.",
                    displayTime: 10000,
                    closeOnClick: true,
                    closeOnOutsideClick: true,
                    position: {
                        of: e.itemElement,
                        collision: "flipfit"
                    }
                });
                DevExpress.framework.html.DesignerController.moreProvidersPopover.visible(false);
            };

            var moreProvidersPopoverVisible = ko.observable(false),
                moreProvidersPopoverTarget = ko.observable();
            DX.framework.html.DesignerController.moreProvidersPopover = {
                target: moreProvidersPopoverTarget,
                visible: moreProvidersPopoverVisible,
                position: { at: "left bottom", my: "top", of: moreProvidersPopoverTarget, offset: "70 0" },
                width: 340
            };
            DX.framework.html.DesignerController.showMoreProvidersPopup = function () {
                var $link = $("a.xet-label").filter(function (index, elem) {
                    return $(elem).text() === "Get More Data Providers";
                });
                moreProvidersPopoverTarget($link);
                moreProvidersPopoverVisible(true);
            };
        })(jQuery, DevExpress, htmlTemplate);
    })(this);

    return _retrieveGlobal();
});
System.register('designerLayout/designerLayout.less!npm:systemjs-less-plugin@1.8.3.js', [], false, function() {});
(function(c){var d=document,a='appendChild',i='styleSheet',s=d.createElement('style');s.type='text/css';d.getElementsByTagName('head')[0][a](s);s[i]?s[i].cssText=c:s[a](d.createTextNode(c));})
("/* Work around for less-pugin url(..\\FrontEnd\\designerLayout/image/tmp.png) */\n.dx-viewport.dx-theme-generic {\n  height: 100%;\n  width: 100%;\n  position: absolute;\n  background-color: white;\n  top: 0;\n}\n.dx-viewport.dx-theme-generic .popup-container {\n  bottom: 60px;\n}\n.dx-viewport.dx-theme-generic .popup-container .dx-overlay-content {\n  bottom: 60px;\n  cursor: default;\n}\n.dx-viewport.dx-theme-generic .popup-container .dx-overlay-content .drop-down-menu-content .dx-button {\n  box-shadow: none;\n  border: none;\n  background-color: transparent;\n}\n.dx-viewport.dx-theme-generic .popup-container .dx-overlay-content .drop-down-menu-content .dx-button .dx-button-text {\n  color: #fb4f35;\n  border-bottom: 1px dashed;\n}\n.dx-viewport.dx-theme-generic .popup-container .dx-overlay-content .drop-down-menu-content .dx-list .dx-list-item .dx-button {\n  visibility: hidden;\n}\n.dx-viewport.dx-theme-generic .popup-container .dx-overlay-content .drop-down-menu-content .dx-list .dx-list-item:hover .dx-button {\n  visibility: visible;\n}\n.dx-viewport.dx-theme-generic > .dx-overlay-wrapper > .dx-popover-arrow {\n  display: none;\n}\n.dx-viewport.dx-theme-generic > .dx-overlay-wrapper .dx-popup-content .dx-view {\n  height: 100%;\n}\n.dx-viewport.dx-theme-generic > .dx-overlay-wrapper .dx-popup-content .dx-view .dx-content {\n  height: 100%;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout {\n  overflow: hidden;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-content {\n  border-left: none;\n  border-right: none;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content {\n  width: 230px;\n  background-color: #393939;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template > .dx-button {\n  box-shadow: none;\n  border: none;\n  background-color: transparent;\n  padding: 20px 20px 25px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template > .dx-button .dx-button-text {\n  color: #fb4f35;\n  border-bottom: 1px dashed;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template > .dx-button .dx-button-content {\n  padding: 0;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .xet-label {\n  font-size: 12px;\n  font-weight: bold;\n  padding: 20px 20px 10px;\n  color: #646464;\n  border-top: 1px solid #4b4b4b;\n  cursor: default;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .dx-list {\n  position: absolute;\n  top: 180px;\n  bottom: 95px;\n  height: auto;\n  margin-right: 5px;\n  margin-left: 5px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .dx-list .dx-list-item:last-of-type,\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .dx-list .dx-empty-message:last-of-type {\n  border-bottom: none;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .dx-list .dx-empty-message {\n  border-top: none;\n  padding: 15px 20px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .dx-list .dx-list-item {\n  border-top: none;\n  border-radius: 3px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .dx-list .dx-list-item.dx-state-hover {\n  background-color: rgba(96, 96, 96, 0.5);\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .dx-list .dx-list-item .dx-list-item-content {\n  padding: 12px 15px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .dx-list .dx-list-item .dx-list-item-content.active {\n  background-color: #606060;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .dx-list .dx-list-item .dx-list-item-content .xet-label {\n  font-size: 14px;\n  font-weight: normal;\n  padding: 0;\n  color: white;\n  border-top: none;\n  cursor: pointer;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .menu-toolbar {\n  position: absolute;\n  bottom: 15px;\n  box-shadow: none;\n  border: none;\n  background-color: transparent;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .menu-toolbar .dx-button {\n  background-color: #575757;\n  border-color: #6b6b6b;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .menu-toolbar .dx-button.dx-button-has-text {\n  padding-left: 40px;\n  padding-right: 40px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .menu-toolbar .dx-button.dx-button-has-text .dx-button-text {\n  color: white;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .menu-toolbar .dx-button.dx-state-hover {\n  background-color: rgba(87, 87, 87, 0.8);\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .dx-slideoutview-menu-content .menu-template .menu-toolbar .dx-button.dx-state-active {\n  border-color: rgba(107, 107, 107, 0.4);\n  background-color: rgba(87, 87, 87, 0.4);\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header {\n  display: table;\n  z-index: 1;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .dx-toolbar .dx-toolbar-items-container {\n  height: 30px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header > div,\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header > img {\n  display: table-cell;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .logo-container {\n  max-width: 400px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .logo {\n  vertical-align: middle;\n  color: white;\n  font-size: 16px;\n  font-weight: bold;\n  cursor: pointer;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  overflow: hidden;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .header-toolbar {\n  padding: 0;\n  color: white;\n  background-color: #393939;\n  height: 30px;\n  border-bottom: none;\n  vertical-align: middle;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .header-toolbar .dx-toolbar-item {\n  padding: 0 2px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .header-toolbar .dx-toolbar-item:first-child .dx-toolbar-item-content .dx-button {\n  padding-left: 2px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .header-toolbar .dx-toolbar-item .dx-toolbar-item-content {\n  height: 30px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .header-toolbar .dx-toolbar-item .dx-toolbar-item-content .dx-button {\n  box-shadow: none;\n  border: none;\n  background-color: transparent;\n  margin-top: -2px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .header-toolbar .dx-toolbar-item .dx-toolbar-item-content .dx-button.dx-button-has-text .dx-icon {\n  padding-bottom: 1px;\n  margin-right: 5px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .header-toolbar .dx-toolbar-item .dx-toolbar-item-content .dx-button.dx-button-has-text .dx-button-text {\n  color: white;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .header-toolbar .dx-toolbar-item .dx-toolbar-item-content .dx-button.dx-button-has-text .dx-button-content {\n  padding: 7px 8px 8px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container {\n  height: 30px;\n  width: auto;\n  vertical-align: middle;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab {\n  padding: 0;\n  color: white;\n  background-color: #393939;\n  height: 30px;\n  border-bottom: none;\n  vertical-align: middle;\n  border-right: 1px solid #575757;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab span {\n  vertical-align: middle;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab .drop-down-icon {\n  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuNWWFMmUAAABISURBVDhPY2hoaPhPLgZrBgIGUvGoZihOTEzEGrIgcWR1IDGsNqMbgK4RhHFqBmGYAdg0gjBezSCMSyMIE9SMDw91zeThhv8Ami96gQcIp6MAAAAASUVORK5CYII=);\n  background-repeat: no-repeat;\n  background-position: center center;\n  width: 30px;\n  height: 30px;\n  margin: 0;\n  padding: 0;\n  display: inline-block;\n  vertical-align: middle;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab .dx-button {\n  box-shadow: none;\n  border: none;\n  background-color: transparent;\n  background-image: none;\n  padding: 0;\n  height: 30px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab .dx-button .dx-icon {\n  transform: none;\n  color: white;\n  font-size: 19px;\n  height: 19px;\n  width: 19px;\n  background-size: 19px 19px;\n  line-height: 19px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab .dx-button.dx-button-has-text .dx-icon {\n  margin-right: 5px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab .dx-button.dx-button-has-text .dx-button-text {\n  color: white;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab .dx-button .dx-button-content {\n  padding: 0;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab:first-child .dx-tab-content {\n  padding-left: 5px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab .dx-tab-content {\n  padding: 0 8px 0 15px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab.virtual-toolbar {\n  background-color: #fb4f35;\n  border-right: none;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab.virtual-toolbar .virtual-toolbar-content {\n  line-height: 28px;\n  height: 30px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-tab.virtual-toolbar .virtual-toolbar-content .logo {\n  line-height: 30px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-nav-item.dx-tab-selected {\n  color: #393939;\n  background: #f3f3f3;\n  box-shadow: none;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-nav-item.dx-tab-selected .drop-down-icon {\n  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuNWWFMmUAAABISURBVDhPY2hoaPhPLgZrBgIGUvGoZihOTEzEGrIgcWR1IDGsNqMbgK4RhHFqBmGYAdg0gjBezSCMSyMIE9SMDw91zeThhv8Ami96gQcIp6MAAAAASUVORK5CYII=);\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-nav-item.dx-tab-selected .dx-button .dx-icon,\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .layout-header .navbar-container .dx-nav-item.dx-tab-selected .dx-button .dx-button-text {\n  color: #393939;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout.navbar-layout .dx-tabs.dx-navbar.navbar-container .dx-icon {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 0 5px 0 0;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .layout-content {\n  top: 30px;\n  bottom: 0;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .layout-content .dx-content .dx-deferrendering > .dx-designer {\n  height: auto;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .layout-content .dx-content .dx-deferrendering > *:not(.dx-loadindicator) {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 65px;\n  left: 0;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .layout-footer {\n  height: auto;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .layout-footer .view-toolbar-bottom {\n  height: 65px;\n  border-top: 1px solid #d0d0d0;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .layout-footer .view-toolbar-bottom .dx-toolbar-items-container {\n  height: 100%;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .layout-footer .view-toolbar-bottom .dx-toolbar-items-container .dx-toolbar-before {\n  margin-left: 10px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .layout-footer .view-toolbar-bottom .dx-toolbar-items-container .dx-toolbar-after {\n  margin-right: 10px;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .transition-frame {\n  background-color: white;\n}\n.dx-viewport.dx-theme-generic .navbar-layout.designer-layout .transition-frame .transition-frame-content.has-toolbox .view-toolbar-bottom {\n  position: absolute;\n  width: auto;\n  left: 288px;\n  right: 0;\n  top: -65px;\n}\n.navigation-item table {\n  width: 100%;\n  table-layout: fixed;\n}\n.navigation-item td:first-child {\n  width: 100%;\n  text-align: start;\n}\n.navigation-item td:first-child .xet-label {\n  overflow: hidden;\n  white-space: nowrap;\n  -ms-text-overflow: ellipsis;\n  -o-text-overflow: ellipsis;\n  text-overflow: ellipsis;\n}\n.navigation-item td:not(:first-child) {\n  width: 45px;\n  text-align: center;\n}\n.navigation-item button {\n  background: none !important;\n  border: none;\n  padding: 0 !important;\n  font: inherit;\n  color: #fb4f35;\n  border-bottom: 1px dashed;\n  cursor: pointer;\n}\ndiv.desktop-only-site {\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  z-index: 100;\n  background: white;\n  padding-top: 50px;\n}\ndiv.desktop-only-site p {\n  display: block;\n  font-size: 200%;\n  width: 50%;\n  margin: 0 auto;\n}\n.deploy-popover h3:first-child {\n  margin-top: 0;\n}\n.deploy-popover h3 {\n  margin-top: 20px;\n  margin-bottom: 5px;\n}\n.deploy-popover .dx-button:first-child {\n  margin-left: 0;\n}\n.deploy-popover a {\n  margin-top: 5px;\n  display: block;\n}\n.deploy-popover a i {\n  margin-right: 3px;\n}\n");