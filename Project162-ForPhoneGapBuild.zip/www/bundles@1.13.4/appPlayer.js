/*!
 * Xenarius - Mobile applications for your data, built without coding.
 * @version v1.13.4 data Wed Nov 30 2016
 * @link http://www.xenarius.net
 * @license http://xenarius.net/legal/eula.html
 * Copyright (c) 2016 Devsoft Baltic OÜ. All rights reserved.
 */
 
 System.registerDynamic("appPlayer/content/app-player.css!github:systemjs/plugin-css@0.1.26.js", [], false, function ($__require, $__exports, $__module) {
  var _retrieveGlobal = System.get("@@global-helpers").prepareGlobal($__module.id, null, null);

  (function ($__global) {})(this);

  return _retrieveGlobal();
});
System.registerDynamic("appPlayer/appPlayer.js", [], false, function ($__require, $__exports, $__module) {
    var _retrieveGlobal = System.get("@@global-helpers").prepareGlobal($__module.id, null, null);

    (function ($__global) {
        var __extends = $__global["__extends"],
            AppPlayer = $__global["AppPlayer"];
        /*!
         * xenarius - Mobile applications for your data, built without coding.
         * @version v1.11.0 data Wed Nov 30 2016
         * @link http://www.xenarius.net
         * @license http://xenarius.net/legal/eula.html
         */
        var __extends = this && this.__extends || function (d, b) {
            for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
            function __() {
                this.constructor = d;
            }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
        var AppPlayer;
        (function (AppPlayer) {
            var Stores;
            (function (Stores) {
                "use strict";

                var dxdata = DevExpress.data;
                function unwrapNestedLists(data) {
                    var valueCallback = function (valueContext) {
                        return valueContext.value;
                    },
                        result = AppPlayer.propertyVisitor(data, valueCallback, {
                        getValueCallback: function (value, context) {
                            return $.isPlainObject(value) && value.results && $.isArray(value.results) ? value.results : AppPlayer.propertyVisitor(value, valueCallback, context);
                        }
                    });
                    return result;
                }
                ;
                function replaceKeysWithObjectLinks(store, object, stores) {
                    var newObject = {},
                        navigationFields = [];
                    if (store.fields) {
                        navigationFields = store.fields.filter(function (field) {
                            return field.storeId && true;
                        });
                    }
                    $.each(object, function (name, value) {
                        if (name === "__metadata" || value && typeof value === "object" && value.__deferred) {
                            return;
                        }
                        newObject[name] = value;
                    });
                    navigationFields.forEach(function (field) {
                        if (newObject[field.name]) {
                            newObject[field.name] = {
                                __metadata: {
                                    uri: stores[field.storeId]["_byKeyUrl"](object[field.name])
                                }
                            };
                        }
                    });
                    return newObject;
                }
                ;
                function isGUID(str) {
                    if (typeof str !== "string") {
                        return false;
                    }
                    return (/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(str)
                    );
                }
                function createGuids(data) {
                    var valueCallback = function (valueContext) {
                        var value = valueContext.value;
                        if (isGUID(value)) {
                            return new dxdata.Guid(value);
                        } else {
                            return value;
                        }
                    };
                    return AppPlayer.propertyVisitor(data, valueCallback, { getValueCallback: function (value, context) {
                            return AppPlayer.propertyVisitor(value, valueCallback, context);
                        } });
                }
                ;
                function prepareLoadOptions(loadOptions) {
                    return loadOptions.filter ? $.extend({}, loadOptions, { filter: createGuids(loadOptions.filter) }) : loadOptions;
                }
                function prepareKey(key, storeOptions) {
                    return storeOptions.keyType === "Guid" ? new dxdata.Guid(key) : key;
                }
                var ODataStore = function (_super) {
                    __extends(ODataStore, _super);
                    function ODataStore(storeOptions, stores, $global) {
                        _super.call(this, ODataStore.createODataStoreOptions(storeOptions, $global));
                        this.storeOptions = storeOptions;
                        this.stores = stores;
                    }
                    ODataStore.createODataStoreOptions = function (storeOptions, $global) {
                        return {
                            url: storeOptions.debugUrl || storeOptions.url,
                            key: storeOptions.key,
                            keyType: storeOptions.keyType,
                            beforeSend: AppPlayer.Utils.continueFunc(Stores.Utils.compileUrl({ $global: $global || {} }), Stores.Utils.addHeaders(storeOptions.headers)),
                            errorHandler: AppPlayer.Utils.correctODataError,
                            version: storeOptions.version,
                            withCredentials: storeOptions.withCredentials !== undefined ? storeOptions.withCredentials : true
                        };
                    };
                    ODataStore.prototype.load = function (loadOptions) {
                        var d = $.Deferred();
                        _super.prototype.load.call(this, prepareLoadOptions(loadOptions)).done(function (data) {
                            d.resolve(unwrapNestedLists(data));
                        }).fail(d.reject);
                        return d.promise();
                    };
                    ODataStore.prototype.byKey = function (key, extraOptions) {
                        var d = $.Deferred();
                        _super.prototype.byKey.call(this, prepareKey(key, this.storeOptions), extraOptions).done(function (data) {
                            d.resolve(unwrapNestedLists(data));
                        }).fail(d.reject);
                        return d.promise();
                    };
                    ODataStore.prototype.insert = function (values) {
                        return _super.prototype.insert.call(this, replaceKeysWithObjectLinks(this.storeOptions, values, this.stores));
                    };
                    ODataStore.prototype.update = function (key, values) {
                        return _super.prototype.update.call(this, key, replaceKeysWithObjectLinks(this.storeOptions, values, this.stores));
                    };
                    ODataStore.prototype.remove = function (key) {
                        return _super.prototype.remove.call(this, prepareKey(key, this.storeOptions));
                    };
                    ODataStore.prototype.totalCount = function (loadOptions) {
                        return _super.prototype.load.call(this, prepareLoadOptions(loadOptions));
                    };
                    return ODataStore;
                }(DevExpress.data.ODataStore);
                Stores.ODataStore = ODataStore;
            })(Stores = AppPlayer.Stores || (AppPlayer.Stores = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Stores;
            (function (Stores) {
                "use strict";

                var RestStore = function (_super) {
                    __extends(RestStore, _super);
                    function RestStore(storeOptions, globalModel, application) {
                        var _this = this;
                        var createProcessResult = function (operationName) {
                            var logic = storeOptions[operationName] && storeOptions[operationName].processResult,
                                processResultCompiler = logic ? application.createFunctionCompiler(logic) : null;
                            return processResultCompiler ? function (context) {
                                return processResultCompiler.run(context, { callerId: operationName + ".processResult", callerType: "RestStore" });
                            } : function (context) {
                                return context.$data;
                            };
                        },
                            processLoadResult = createProcessResult("load"),
                            processByKeyResult = createProcessResult("byKey"),
                            customStoreOptions = $.extend({}, storeOptions, {
                            key: storeOptions.key,
                            load: function (loadOptions) {
                                var result,
                                    context = { $global: globalModel, $options: loadOptions };
                                if (!storeOptions.load.getAjaxData) {
                                    if (!_this._cacheArrayStore || loadOptions.skip === undefined || loadOptions.skip === 0) {
                                        result = _this.getHandler({ storeOptions: storeOptions, operationName: "load", headers: storeOptions.headers, context: context, defaultMethod: "get", defaultGetAjaxData: null }).then(function (data) {
                                            return processLoadResult($.extend({ $data: data }, context));
                                        }).then(function (data) {
                                            if (Array.isArray(data)) {
                                                _this._cacheArrayStore = new DevExpress.data.ArrayStore(data);
                                                return _this._cacheArrayStore.load(loadOptions);
                                            } else {
                                                return data;
                                            }
                                        });
                                    } else {
                                        result = _this._cacheArrayStore.load(loadOptions);
                                    }
                                } else {
                                    result = _this.getHandler({ storeOptions: storeOptions, operationName: "load", headers: storeOptions.headers, context: context, defaultMethod: "get", defaultGetAjaxData: null }).then(function (data) {
                                        return processLoadResult($.extend({ $data: data }, context));
                                    });
                                }
                                return result;
                            },
                            byKey: function (key) {
                                var context = { $global: globalModel, $key: key };
                                return _this.getHandler({ storeOptions: storeOptions, operationName: "byKey", headers: storeOptions.headers, context: context, defaultMethod: "get", defaultGetAjaxData: null }).then(function (data) {
                                    return processByKeyResult($.extend({ $data: data }, context));
                                });
                            },
                            insert: function (values) {
                                var d = $.Deferred();
                                _this.getHandler({ context: { $global: globalModel, $data: values }, storeOptions: storeOptions, operationName: "insert", headers: storeOptions.headers, defaultMethod: "post", defaultGetAjaxData: function () {
                                        return values;
                                    } }).done(function (data) {
                                    d.resolve(_this.keyOf(data));
                                }).fail(d.reject);
                                return d.promise();
                            },
                            update: function (key, values) {
                                return _this.getHandler({
                                    context: { $global: globalModel, $key: key, $data: values },
                                    storeOptions: storeOptions, operationName: "update", headers: storeOptions.headers, defaultMethod: "patch", defaultGetAjaxData: function () {
                                        return values;
                                    }
                                });
                            },
                            remove: function (key) {
                                return _this.getHandler({ context: { $global: globalModel, $key: key }, storeOptions: storeOptions, operationName: "remove", headers: storeOptions.headers, defaultMethod: "delete", defaultGetAjaxData: null });
                            },
                            totalCount: function (loadOptions) {
                                return _this.getHandler({ context: { $global: globalModel, $options: loadOptions }, storeOptions: storeOptions, operationName: "totalCount", headers: storeOptions.headers, defaultMethod: "get", defaultGetAjaxData: null });
                            }
                        });
                        _super.call(this, customStoreOptions);
                        this._handlers = {};
                        this._application = application;
                    }
                    RestStore.prototype._eval = function (expr, context) {
                        return expr ? AppPlayer.Logic.Operation.eval(expr, context) : void 0;
                    };
                    RestStore.prototype._transformData = function (data, method) {
                        if (data) {
                            switch (method) {
                                case "get":
                                    $.each(data, function (name, val) {
                                        if (val) {
                                            if (val instanceof Date) {
                                                data[name] = val.toISOString();
                                            } else {
                                                data[name] = "" + val;
                                            }
                                        } else {
                                            delete data[name];
                                        }
                                    });
                                    break;
                                case "post":
                                case "patch":
                                    data = JSON.stringify(data);
                                    break;
                                default:
                                    break;
                            }
                        }
                        return data;
                    };
                    RestStore._sendRequest = function (url, method, data, dataType, headers) {
                        if (dataType === void 0) {
                            dataType = "json";
                        }
                        if (headers === void 0) {
                            headers = [];
                        }
                        var requestOptions = {
                            url: url,
                            type: method ? method.toUpperCase() : "GET",
                            contentType: "application/json; charset=utf-8",
                            dataType: dataType,
                            data: data
                        };
                        Stores.Utils.addHeaders(headers)(requestOptions);
                        return AppPlayer.Utils.ajax(requestOptions);
                    };
                    RestStore.prototype.getHandler = function (options) {
                        var _this = this;
                        var operationName = options.operationName,
                            defaultMethod = options.defaultMethod,
                            defaultGetAjaxData = options.defaultGetAjaxData,
                            context = options.context,
                            operation = options.storeOptions[operationName],
                            method = operation.method || defaultMethod;
                        if (!this._handlers[options.operationName]) {
                            var bizLogic_1 = operation.getAjaxData;
                            var getAjaxData_1;
                            if (bizLogic_1) {
                                getAjaxData_1 = function (context) {
                                    return _this._application.createFunctionCompiler(bizLogic_1).run(context, { callerId: options.storeOptions.id, callerType: "restStore." + operationName });
                                };
                            } else {
                                getAjaxData_1 = defaultGetAjaxData ? defaultGetAjaxData : function () {
                                    return null;
                                };
                            }
                            this._handlers[operationName] = function (context) {
                                var url = _this._getUrl(operation, context);
                                if (!operation || !url) {
                                    return AppPlayer.Logic.rejectPromise("No " + name + " url specified");
                                }
                                return $.when(getAjaxData_1(context)).then(function (ajaxData) {
                                    var transformetAjaxData = _this._transformData(_this._eval(JSON.stringify(ajaxData), context), method);
                                    return RestStore._sendRequest(url, method, transformetAjaxData, options.storeOptions.dataType, options.headers);
                                });
                            };
                        }
                        return this._handlers[operationName](context);
                    };
                    RestStore.prototype._getUrl = function (options, context) {
                        try {
                            var url = options.debugUrl || options.url;
                            return url.startsWith("=") ? this._eval(url, context) : url;
                        } catch (e) {
                            console.error(e);
                            throw e;
                        }
                    };
                    RestStore.prototype.bind = function (dependent) {
                        Stores.Utils.bindStore(this, dependent);
                    };
                    return RestStore;
                }(DevExpress.data.CustomStore);
                Stores.RestStore = RestStore;
            })(Stores = AppPlayer.Stores || (AppPlayer.Stores = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Stores;
            (function (Stores) {
                "use strict";

                var dxdata = DevExpress.data;
                var ArrayStore = function (_super) {
                    __extends(ArrayStore, _super);
                    function ArrayStore(storeOptions) {
                        _super.call(this, storeOptions);
                    }
                    ArrayStore.prototype.byKey = function (key, extraOptions) {
                        return _super.prototype.byKey.call(this, key, extraOptions).then(function (value) {
                            if (value instanceof Object) {
                                return $.extend({}, value);
                            } else {
                                return value;
                            }
                        });
                    };
                    ArrayStore.prototype.load = function (obj) {
                        return _super.prototype.load.call(this, obj).then(function (value) {
                            if (value) {
                                $.each(value, function (name, val) {
                                    if (val instanceof Object) {
                                        value[name] = $.extend({}, val);
                                    }
                                });
                            }
                            return value;
                        });
                    };
                    return ArrayStore;
                }(dxdata.ArrayStore);
                Stores.ArrayStore = ArrayStore;
            })(Stores = AppPlayer.Stores || (AppPlayer.Stores = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Stores;
            (function (Stores) {
                "use strict";

                var DXError = DevExpress["Error"];
                function isCyclic(obj) {
                    var seenObjects = [];
                    function detect(obj) {
                        if (obj && typeof obj === "object") {
                            if (seenObjects.indexOf(obj) !== -1) {
                                return true;
                            }
                            seenObjects.push(obj);
                            for (var key in obj) {
                                if (obj.hasOwnProperty(key) && detect(obj[key])) {
                                    console.log(obj, "cycle at " + key);
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    return detect(obj);
                }
                var JsonStore = function (_super) {
                    __extends(JsonStore, _super);
                    function JsonStore(storeOptions, $global) {
                        var _this = this;
                        if ($global === void 0) {
                            $global = null;
                        }
                        var cacheKey = storeOptions.jsonPath + storeOptions.url,
                            load = function (options) {
                            var d = $.Deferred(),
                                requestOptions = {
                                url: storeOptions.url,
                                dataType: "json",
                                data: { path: storeOptions.jsonPath }
                            },
                                cachedData = JsonStore.cache[cacheKey];
                            Stores.Utils.addHeaders(storeOptions.headers)(requestOptions);
                            if (cachedData) {
                                requestOptions["headers"] = { "If-None-Match": cachedData.tag };
                            }
                            $.ajax(requestOptions).then(function (data, testStatus, request) {
                                var resultingData = data;
                                if (request.status === 200) {
                                    JsonStore.cache[cacheKey] = { data: data, tag: request.getResponseHeader("ETag") };
                                } else if (request.status === 304) {
                                    resultingData = cachedData.data;
                                }
                                d.resolve(resultingData);
                            });
                            return d.promise();
                        },
                            post = function (data, keyName, keyValue) {
                            var requestOptions = {
                                url: storeOptions.url,
                                data: {
                                    json: JSON.stringify(data),
                                    path: storeOptions.jsonPath,
                                    keyName: keyName,
                                    keyValue: keyValue
                                },
                                method: "POST"
                            };
                            Stores.Utils.addHeaders(storeOptions.headers)(requestOptions);
                            return $.ajax(requestOptions);
                        },
                            keyPrefix = storeOptions.keyPrefix;
                        if (!keyPrefix) {
                            keyPrefix = storeOptions.id;
                            if (AppPlayer.endsWith(keyPrefix, "s")) {
                                keyPrefix = keyPrefix.substring(0, keyPrefix.length - 1);
                            }
                        }
                        $.extend(storeOptions, {
                            totalCount: function () {
                                return load().then(function (result) {
                                    return AppPlayer.Logic.trivialPromise(result ? result.length : 0);
                                });
                            },
                            load: load,
                            byKey: function (key) {
                                var that = _this;
                                return load().then(function (items) {
                                    return AppPlayer.findInArray(items, function (item) {
                                        return item[that.key()] === key;
                                    });
                                });
                            },
                            update: function (key, values) {
                                var d = $.Deferred();
                                isCyclic(values);
                                post(values, _this.key(), key).then(function () {
                                    d.resolve();
                                });
                                return d.promise();
                            },
                            insert: function (values) {
                                var that = _this,
                                    keyExpr = _this.key(),
                                    keyValue,
                                    d = $.Deferred();
                                $.getJSON(storeOptions.url).then(function (data) {
                                    var getter = AppPlayer.compileGetter(storeOptions.jsonPath),
                                        setter,
                                        array = getter(data);
                                    if (!array) {
                                        array = [];
                                        setter = AppPlayer.compileSetter(storeOptions.jsonPath);
                                        setter(data, array);
                                    }
                                    if (keyExpr) {
                                        keyValue = _this.keyOf(values);
                                        if (!keyValue || typeof keyValue === "object" && $.isEmptyObject(keyValue)) {
                                            if ($.isArray(keyExpr)) {
                                                d.reject(DXError("E4007"));
                                                return;
                                            }
                                            var maxKeyNum = 0;
                                            array.forEach(function (item) {
                                                var key = _this.keyOf(item);
                                                if (!AppPlayer.startsWith(key, keyPrefix)) {
                                                    return;
                                                }
                                                try {
                                                    var keyNum = parseInt(key.substr(keyPrefix.length), 10);
                                                    if (keyNum > maxKeyNum) {
                                                        maxKeyNum = keyNum;
                                                    }
                                                } catch (e) {
                                                    return;
                                                }
                                            });
                                            keyValue = values[keyExpr] = keyPrefix + (maxKeyNum + 1);
                                            var context = {
                                                $key: keyValue,
                                                $global: $global
                                            };
                                            (storeOptions.fields || []).forEach(function (field) {
                                                if (!values[field.name]) {
                                                    if (typeof field.defaultValueExpr === "string") {
                                                        var defaultValue = AppPlayer.Logic.Operation.eval(field.defaultValueExpr, context);
                                                        values[field.name] = defaultValue;
                                                    }
                                                }
                                            });
                                        } else if (AppPlayer.findInArray(array, function (p) {
                                            return p.id === keyValue;
                                        })) {
                                            d.reject(DXError("E4008"));
                                        }
                                    } else {
                                        keyValue = values;
                                    }
                                    array.push(values);
                                    post(values, that.key(), keyValue).then(function () {
                                        d.resolve(keyValue);
                                    }, function (error) {
                                        d.reject(error);
                                    });
                                });
                                return d.promise();
                            },
                            remove: function (key) {
                                var that = _this,
                                    result = $.Deferred(),
                                    storeUrl = storeOptions.url,
                                    keyExpr = storeOptions.key;
                                $.getJSON(storeUrl).then(function (data) {
                                    var getter = AppPlayer.compileGetter(storeOptions.jsonPath),
                                        array = getter(data) || [],
                                        index = AppPlayer.indexInArray(array, function (item) {
                                        return item[keyExpr] === key;
                                    });
                                    if (index !== -1) {
                                        array.splice(index, 1);
                                    }
                                    post(null, that.key(), key).then(function () {
                                        result.resolve();
                                    }, function (error) {
                                        result.reject(error);
                                    });
                                }, function (error) {
                                    result.reject(error);
                                });
                                return result.promise();
                            }
                        });
                        _super.call(this, storeOptions);
                    }
                    JsonStore.prototype.bind = function (dependent) {
                        Stores.Utils.bindStore(this, dependent);
                    };
                    JsonStore.cache = {};
                    return JsonStore;
                }(DevExpress.data.CustomStore);
                Stores.JsonStore = JsonStore;
            })(Stores = AppPlayer.Stores || (AppPlayer.Stores = {}));
        })(AppPlayer || (AppPlayer = {}));
        /// <reference path="stores/odatastore.ts" />
        /// <reference path="stores/reststore.ts" />
        /// <reference path="stores/arraystore.ts" />
        /// <reference path="stores/designerstore.ts" />
        var AppPlayer;
        (function (AppPlayer) {
            "use strict";

            var dxhtml = DevExpress.framework.html;
            var dxdata = DevExpress.data;
            var aps = AppPlayer.Stores;
            var dxconsole = DevExpress.utils.console;
            ;
            var Application = function () {
                function Application(appConfig, options) {
                    var _this = this;
                    this.sharedObjects = {};
                    this.started = $.Callbacks();
                    this.dataError = $.Callbacks();
                    this.setAppConfig(appConfig);
                    this.id = appConfig.id;
                    this.localStorage = new AppPlayer.LocalStorageWrapper(this);
                    this.options = options;
                    this.ns = {};
                    this.appConfig.navigation = appConfig.navigation || { defaultView: "", items: [] };
                    this.functions = this.createGlobalFunctions();
                    this.appConfig.params = this.appConfig.params || [];
                    this.appConfig.model = this.appConfig.model || [];
                    this.typeInfoRepository = new AppPlayer.TypeInfoRepository(appConfig.dataStores);
                    this.model = AppPlayer.Model.createAppModel(this.appConfig, this);
                    this.setModelValueFromParameter();
                    this.loadNavigation();
                    this.copyGlobalCommands();
                    this.createStores();
                    AppPlayer.Model.initializeDataSources(this.model, { $model: this.model, $global: this.model }, this, this.stores, false, this.appConfig.dataSources);
                    if (this.model.hasOwnProperty("title")) {
                        var titleObserver = ko.computed(function () {
                            return _this.model["title"];
                        });
                        var formatTitle;
                        if (this.id === "com.devexpress.Xenarius.Designer") {
                            formatTitle = function () {
                                if (titleObserver()) {
                                    document.title = titleObserver() + " - Xenarius Admin";
                                } else {
                                    document.title = "Xenarius Admin";
                                }
                            };
                        } else {
                            formatTitle = function () {
                                document.title = titleObserver();
                            };
                        }
                        titleObserver.subscribe(formatTitle);
                        formatTitle();
                    }
                    if (appConfig["onStarted"]) {
                        var onApplicationStarted = this.createFunctionCompiler(appConfig["onStarted"]);
                        this.started.add(function () {
                            return onApplicationStarted.run({ $global: _this.model });
                        });
                    }
                }
                Object.defineProperty(Application, "SPLIT_NAV_VIEW_ID", {
                    get: function () {
                        return "splitNavigation";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Application, "SHARED_PARAMETER", {
                    get: function () {
                        return "xet-shared-object";
                    },
                    enumerable: true,
                    configurable: true
                });
                Application.prototype.setAppConfig = function (appConfig) {
                    this.appConfig = appConfig;
                    this.appConfig.platforms = this.appConfig.platforms || [{
                        name: "DesktopRule",
                        layout: "desktop",
                        defaultCommandContainer: "header",
                        defaultCommandLocation: "after",
                        options: {
                            generic: true
                        }
                    }, {
                        name: "PhoneRule",
                        layout: "slideout",
                        defaultCommandContainer: "header",
                        defaultCommandLocation: "after",
                        options: {
                            phone: true
                        }
                    }, {
                        name: "TabletRule",
                        layout: "split",
                        defaultCommandContainer: "header",
                        defaultCommandLocation: "after",
                        options: {
                            tablet: true
                        }
                    }];
                    this.appConfig.views = this.appConfig.views || [];
                    this.appConfig.views.forEach(function (view) {
                        (view.commands || []).forEach(function (command) {
                            command.id = view.id + "_" + command.id;
                        });
                    });
                };
                Application.prototype.isSplitLayout = function () {
                    var currentDevice = DevExpress.devices.current(),
                        currentPlatform = AppPlayer.LayoutHelper.tryGetCurrentPlatform(this.appConfig.platforms, currentDevice),
                        usesSplitLayout = currentPlatform && currentPlatform.layout === "split";
                    return usesSplitLayout;
                };
                Application.prototype.setModelValueFromParameter = function () {
                    var _this = this;
                    this.appConfig.params.forEach(function (parameter) {
                        var val = AppPlayer.getQueryVariable(parameter.name);
                        if (val) {
                            _this.model[parameter.name] = val;
                        }
                    });
                };
                Application.prototype.loadNavigation = function () {
                    var navigation = this.appConfig.navigation;
                    if (!this.appConfig["isDesignMode"] && this.isSplitLayout() && navigation) {
                        if (!navigation.customSplitNavigation && navigation.items && navigation.items.length > 0) {
                            this.appConfig.views.splice(0, 0, this.getSplitNavigationView());
                            (this.appConfig.dataStores = this.appConfig.dataStores || []).push(this.getNavigationItemsStore());
                        }
                    }
                };
                Application.prototype.copyGlobalCommands = function () {
                    var _this = this;
                    if (this.appConfig.globalCommands && this.appConfig.views) {
                        var isSplitLayout = this.isSplitLayout();
                        this.appConfig.views.forEach(function (view) {
                            if (isSplitLayout && view.pane !== "master") {
                                return;
                            }
                            if (!view.commands) {
                                view.commands = [];
                            }
                            _this.appConfig.globalCommands.forEach(function (command) {
                                view.commands.push($.extend({}, command, { id: command.id + view.id }));
                            });
                        });
                    }
                };
                Application.prototype.navigate = function (uri, options) {
                    this.dxapp.navigate(uri, options);
                };
                Application.prototype.initializeDefaultView = function (currentDevice) {
                    var currentPlatform = AppPlayer.LayoutHelper.tryGetCurrentPlatform(this.appConfig.platforms, currentDevice),
                        usesSplitLayout = currentPlatform && currentPlatform.layout === "split",
                        defaultView = currentPlatform && currentPlatform.defaultView ? currentPlatform.defaultView : this.appConfig.navigation.defaultView;
                    if (!this.appConfig["isDesignMode"] && usesSplitLayout && !currentPlatform.defaultView) {
                        var splitNav = AppPlayer.findInArray(this.appConfig.views, function (v) {
                            return v.pane === "master";
                        });
                        if (splitNav) {
                            defaultView = splitNav.id;
                        }
                    }
                    return defaultView;
                };
                Application.prototype.restart = function () {
                    window.location.reload(true);
                };
                Application.prototype.run = function () {
                    var _this = this;
                    var that = this;
                    dxdata.errorHandler = this._errorHandler.bind(this);
                    DevExpress.devices.current({ platform: "generic" });
                    var currentDevice = DevExpress.devices.current();
                    this.defaultView = this.initializeDefaultView(currentDevice);
                    this.moduleLoader = new AppPlayer.ModulesLoader(this /*, window["progressReporter"]*/);
                    var htmlApplicationOptions, layoutSet;
                    htmlApplicationOptions = this.htmlAppConfiguration();
                    layoutSet = AppPlayer.LayoutHelper.createLayoutSet(this.appConfig.platforms, this.appConfig["isDesignMode"], this.appConfig.views);
                    htmlApplicationOptions.layoutSet = layoutSet.layoutSet;
                    this.dxapp = this._createApplication(htmlApplicationOptions);
                    this.dxapp["_xetGetView"] = this._getView.bind(this);
                    this.dxapp.on("resolveViewCacheKey", function (args) {
                        var viewId = args.routeData["view"],
                            refresh = that.appConfig.views.some(function (value) {
                            return value.id === viewId && value.refreshWhenShown;
                        });
                        if (refresh) {
                            args.key = viewId;
                        }
                    });
                    this.dxapp["_processRequestResultLockEnabled"] = true;
                    this.dxapp.on("resolveLayoutController", function (args) {
                        var foundController = AppPlayer.LayoutHelper.tryGetViewSpecificLayoutController(args.viewInfo["viewName"], layoutSet.viewSpecificLayouts);
                        if (foundController) {
                            args.layoutController = foundController;
                        }
                    });
                    var onApplicationStarted = function () {
                        _this.dxapp.off("viewShown", onApplicationStarted);
                        // Forces DOM elements height recalculation
                        $(window).resize();
                        _this.started.fire(_this);
                    };
                    /* tslint:disable */
                    new AppPlayer.Modules.Authorization(this.appConfig, this);
                    /* tslint:enable */
                    this.dxapp.on("viewShown", onApplicationStarted);
                    this.dxapp.on("navigating", this._onNavigating.bind(this));
                    this.dxapp.router.register(":view/:parameters", { view: that.defaultView, parameters: "" });
                    if (window["xetHandleOpenURL"]) {
                        var openUrl = window["xetHandleOpenURL"];
                        this.functions["navigateToView"](openUrl.uri, openUrl.params, true);
                    } else {
                        if (location.hash && location.hash !== "#") {
                            if (location.hash === "#test-error") {
                                this.dxapp["bbb"].ccc.ddd = 100;
                            }
                            this.navigate();
                        } else {
                            this.navigateToDefaultView();
                        }
                    }
                    if (window["loadingIndicator"]) {
                        window["loadingIndicator"].clear();
                    }
                };
                Application.prototype._createApplication = function (options) {
                    return new dxhtml.HtmlApplication(options);
                };
                Application.prototype._errorHandler = function (error) {
                    if (error instanceof AppPlayer.Logic.LogicError) {
                        this._logicErrorHandler(error);
                    } else if (error instanceof AppPlayer.Logic.DataLogicError) {
                        this._dataLogicErrorHandler(error);
                    } else {
                        this._dataErrorHandler(error);
                    }
                };
                Application.prototype._logicErrorHandler = function (error) {
                    AppPlayer.Utils.showError(error);
                };
                Application.prototype._dataLogicErrorHandler = function (error) {
                    var args = {
                        error: error.data,
                        handled: false
                    };
                    this.dataError.fire(args);
                    if (!args.handled) {
                        AppPlayer.Utils.showError(error);
                    }
                };
                Application.prototype._dataErrorHandler = function (error) {
                    var args = {
                        error: error,
                        handled: false
                    };
                    this.dataError.fire(args);
                    if (!args.handled) {
                        AppPlayer.Utils.showError(error);
                    }
                };
                Application.prototype._ensureView = function (view) {
                    if (this.ns[view]) {
                        return $.Deferred().resolve().promise();
                    } else {
                        var newView = this._getView(view);
                        this.ns[view] = newView.viewModel;
                        return this.dxapp.loadTemplates(newView.viewMarkup);
                    }
                };
                Application.prototype._getView = function (view) {
                    return new AppPlayer.Views.View(this.appConfig.views.filter(function (v) {
                        return v.id === view;
                    })[0], this);
                };
                Application.prototype.registerMissingTemplate = function (componentType) {
                    if ($.inArray(componentType, Application.missingTemplates) === -1) {
                        Application.missingTemplates.push(componentType);
                    }
                };
                Application.prototype.templateIsMissing = function (componentType) {
                    return $.inArray(componentType, Application.missingTemplates) !== -1;
                };
                //TODO Pletnev: extract into SplitLayoutModule
                //TODO Pletnev: come up with a unique identifier instead of "navigationItems"
                Application.prototype.getNavigationItemsStore = function () {
                    return {
                        id: "navigationItems",
                        type: "array",
                        array: this.htmlAppNavigation()
                    };
                };
                //TODO Pletnev: extract into SplitLayoutModule
                //TODO Pletnev: come up with a unique identifier instead of "splitNavigation"
                Application.prototype.getSplitNavigationView = function () {
                    var _this = this;
                    return {
                        "id": Application.SPLIT_NAV_VIEW_ID,
                        "title": this.appConfig.navigation && this.appConfig.navigation.title ? this.appConfig.navigation.title : "Menu",
                        "pane": "master",
                        "dataSources": [{
                            "id": "navigationItemsDatasource",
                            "store": "navigationItems"
                        }],
                        "components": [{
                            "id": "navigationList",
                            "type": "list",
                            "dataSource": "$model.navigationItemsDatasource",
                            "itemComponents": [{
                                id: "itemContainer",
                                type: "stackPanel",
                                orientation: "horizontal",
                                verticalAlign: "center",
                                style: {
                                    "width": "100%",
                                    "paddingTop": "12px",
                                    "paddingLeft": "12px",
                                    "paddingBottom": "12px"
                                },
                                components: [{
                                    id: "navigationItemIcon",
                                    type: "icon",
                                    icon: "$data.icon"
                                }, {
                                    id: "navigationItem",
                                    type: "label",
                                    text: "$data.title",
                                    style: {
                                        "fontSize": "16px",
                                        "marginLeft": "12px"
                                    }
                                }]
                            }],
                            "onItemClick": function (context) {
                                typeof context.$data["onExecute"] === "function" ? context.$data["onExecute"]() : _this.functions["navigateToView"](context.$data["onExecute"].substr(1));
                            }
                        }]
                    };
                };
                Application.prototype.createGlobalFunctions = function () {
                    var _this = this;
                    var functions = {};
                    var busyCounter = 0;
                    var busyInstance;
                    functions["busy"] = function () {
                        busyCounter++;
                        if (busyCounter === 1) {
                            busyInstance = $("<div>").appendTo(DevExpress.viewPort()).addClass("dx-static").dxLoadPanel({
                                shading: true,
                                shadingColor: "rgba(128, 128, 128, .2)"
                            }).data("dxLoadPanel");
                            busyInstance.option("onHidden", function (args) {
                                args.element.remove();
                            });
                            busyInstance.show();
                        }
                        return busyCounter;
                    };
                    functions["available"] = function () {
                        busyCounter--;
                        if (busyCounter === 0) {
                            busyInstance.hide();
                        }
                        if (busyCounter < 0) {
                            busyCounter = 0;
                        }
                        return busyCounter;
                    };
                    functions["getBusyCounter"] = function () {
                        return busyCounter;
                    };
                    functions["back"] = function () {
                        return _this.dxapp.back();
                    };
                    functions["navigateToView"] = function (viewId, parameters, srcPane) {
                        if (!viewId) {
                            viewId = _this.defaultView;
                        }
                        var view = _this.appConfig.views.filter(function (view) {
                            return view.id === viewId;
                        })[0];
                        if (!view) {
                            throw "View \"" + viewId + "\" has not found. Can not navigate to target view.";
                        }
                        if (view.params && view.params.filter(function (p) {
                            return !AppPlayer.Views.ViewModel.optional(p);
                        }).length > 0 && !parameters) {
                            console.error("NavigateToView '" + view.id + "'. View parameters not found.");
                        } else if (view.params) {
                            var missingParameters = [];
                            view.params.forEach(function (param) {
                                if (!parameters || parameters[param.name] === undefined) {
                                    if (!AppPlayer.Views.ViewModel.optional(param)) {
                                        missingParameters.push(param.name);
                                    }
                                    return;
                                }
                                var parameter = parameters[param.name],
                                    typeInfo = _this.typeInfoRepository.get(param.type);
                                // TODO: typeInfo must be defined (unknown type?)
                                if (typeInfo && typeInfo.kind === AppPlayer.TYPES.STORE_TYPE) {
                                    var store = _this.stores[typeInfo.name];
                                    if (parameter !== undefined) {
                                        if (param.shared) {
                                            _this.sharedObjects[param.name] = parameter;
                                        }
                                        parameters[param.name] = store.keyOf(parameter) || parameter;
                                    }
                                } else if (param.shared) {
                                    _this.sharedObjects[param.name] = parameter;
                                    parameters[param.name] = Application.SHARED_PARAMETER;
                                }
                            });
                            if (missingParameters.length) {
                                console.error("NavigateToView '" + view.id + "'. Missing parameters: " + missingParameters.join(", "));
                            }
                        }
                        if (_this.dxapp) {
                            var navigated = function (e) {
                                var currentViewId = _this.dxapp && _this.dxapp.router ? _this.dxapp.router.parse(e.uri)["view"] : e.uri;
                                if (currentViewId !== viewId) {
                                    console.error("Invalid navigation chaing");
                                    return;
                                }
                                view.params.forEach(function (param) {
                                    return delete _this.sharedObjects[param.name];
                                });
                                _this.dxapp.off("navigated", navigated);
                            };
                            _this.dxapp.on("navigated", navigated);
                        }
                        var options = undefined;
                        if (_this.isSplitLayout() && view.pane === "master") {
                            options = { root: false };
                        } else if (_this.isNavigationItem(viewId) || _this.isCrossPaneTransition(srcPane, view.pane) || _this.isAuthorizationView(viewId)) {
                            options = { root: true, target: "current" };
                        }
                        if (!parameters || $.isEmptyObject(parameters)) {
                            _this.navigate({ view: viewId }, options);
                        } else {
                            _this.navigate({ view: viewId, parameters: parameters }, options);
                        }
                    };
                    functions["load"] = function (storeId, options) {
                        return _this.stores[storeId].load(options);
                    };
                    functions["byKey"] = function (storeId, key, extraOptions) {
                        return _this.stores[storeId].byKey(key, extraOptions);
                    };
                    functions["keyOf"] = function (storeId, object) {
                        return _this.stores[storeId].keyOf(object);
                    };
                    functions["save"] = function (object, storeId, key) {
                        functions["busy"]();
                        var store = _this.stores[storeId];
                        if (!key) {
                            key = store.keyOf(object);
                        }
                        var promise = key === undefined ? store.insert(object) : store.update(key, object);
                        return promise.then(function (storedObject, serverKey) {
                            if (!key) {
                                object[store.key()] = serverKey;
                            }
                        }).always(functions["available"]);
                    };
                    functions["insert"] = function (object, storeId) {
                        functions["busy"]();
                        return _this.stores[storeId].insert(object).always(functions["available"]);
                    };
                    functions["delete"] = function (objectOrKey, storeId) {
                        var store = _this.stores[storeId],
                            key = $.isPlainObject(objectOrKey) ? store.keyOf(objectOrKey) : objectOrKey;
                        functions["busy"]();
                        return store.remove(key).always(functions["available"]);
                    };
                    functions["refresh"] = function (storeId) {
                        var store = _this.stores[storeId];
                        store["fireEvent"]("modified");
                    };
                    functions["getDataStoreConfig"] = function (storeId) {
                        var filtered = _this.appConfig.dataStores.filter(function (store) {
                            return store.id === storeId;
                        });
                        if (filtered.length === 0) {
                            throw "Data provider '" + storeId + "' is not found!";
                        }
                        if (filtered.length > 1) {
                            console.warn("Found %o data providers with id '%o'", filtered.length, storeId);
                        }
                        return filtered[0];
                    };
                    functions["getDataStore"] = function (storeId) {
                        return _this.stores[storeId];
                    };
                    functions["log"] = function (level, message) {
                        var logger = dxconsole.logger;
                        logger[level](message);
                    };
                    functions["getCookie"] = function (params) {
                        var name = params.cookieName + "=",
                            cookieArray = document.cookie.split(";"),
                            result = "",
                            deffered = $.Deferred();
                        for (var i = 0; i < cookieArray.length; i++) {
                            var cookie = cookieArray[i];
                            while (cookie.charAt(0) === " ") {
                                cookie = cookie.substring(1);
                            }
                            if (cookie.indexOf(name) === 0) {
                                result = cookie.substring(name.length, cookie.length);
                                break;
                            }
                        }
                        deffered.resolve(result);
                        return deffered;
                    };
                    functions["createFunctionCompiler"] = this.createFunctionCompiler.bind(this);
                    return functions;
                };
                Application.prototype.isNavigationItem = function (viewId) {
                    return this.appConfig.navigation && AppPlayer.indexInArray(this.appConfig.navigation.items, function (item) {
                        return item.id === viewId;
                    }) !== -1;
                };
                Application.prototype.isAuthorizationView = function (viewId) {
                    return this.appConfig.authorization && this.appConfig.authorization.loginView === viewId;
                };
                Application.prototype.isCrossPaneTransition = function (srcPane, dstPane) {
                    if (srcPane === void 0) {
                        srcPane = "detail";
                    }
                    if (dstPane === void 0) {
                        dstPane = "detail";
                    }
                    return this.isSplitLayout() && srcPane !== dstPane;
                };
                Application.prototype.processParameterLoadingError = function (name, id) {
                    var dialog = DevExpress.ui.dialog.custom({
                        title: "Error",
                        message: "Cannot load an '" + name + "' parameter with the '" + id + "' key.",
                        buttons: [{
                            text: "Go Back",
                            onClick: this.functions["back"]
                        }]
                    });
                    dialog.show();
                };
                Application.prototype.createStores = function () {
                    var _this = this;
                    var app = this;
                    if (this.stores) {
                        return;
                    }
                    this.stores = {};
                    (this.appConfig.dataStores || []).forEach(function (item) {
                        var store = null,
                            storeOptions = AppPlayer.Model.createLinkedModel(item, { $global: _this.model }, { callerType: "data provider options", callerId: item.id }, _this.functions);
                        storeOptions.errorHandler = function (error) {
                            error.initiatorId = storeOptions.id;
                        };
                        switch (item.type) {
                            case "odata":
                                store = new aps.ODataStore(storeOptions, app.stores, _this.model);
                                break;
                            case "array":
                                var array = storeOptions.array;
                                AppPlayer.transformISODates(array);
                                store = new aps.ArrayStore({
                                    data: array,
                                    key: storeOptions.key
                                });
                                break;
                            case "json":
                                store = new aps.JsonStore(storeOptions, _this.model);
                                break;
                            case "rest":
                                store = new aps.RestStore(storeOptions, _this.model, _this);
                                break;
                            case "local":
                                var localArray = storeOptions.array;
                                var name = storeOptions.name;
                                var flushInterval = storeOptions.flushInterval;
                                var immediate = storeOptions.immediate;
                                AppPlayer.transformISODates(array);
                                store = new dxdata.LocalStore({
                                    data: localArray,
                                    key: storeOptions.key,
                                    name: name,
                                    immediate: immediate,
                                    flushInterval: flushInterval
                                });
                                break;
                            default:
                                console.error("Unknown store type '" + storeOptions.type + "'");
                        }
                        _this.stores[storeOptions.id] = store;
                    });
                };
                Application.prototype.getCommandMapping = function () {
                    var _this = this;
                    var commandMapping = {};
                    (this.appConfig.views || []).forEach(function (view) {
                        AppPlayer.LayoutHelper.fillCommandMapping(commandMapping, view.commands, _this.appConfig.platforms, DevExpress.devices.current());
                    });
                    return commandMapping;
                };
                Application.prototype._getNavigatingInfo = function (uri) {
                    var sharedParameterIndex = uri.indexOf(Application.SHARED_PARAMETER),
                        viewId = this.dxapp ? this.dxapp.router.parse(uri)["view"] : uri,
                        viewConfig = this.appConfig.views.filter(function (item) {
                        return item.id === viewId;
                    })[0];
                    // Cancels navigation to urls with shared parameters when shared objects are not set
                    if (sharedParameterIndex >= 0 && Object.keys(this.sharedObjects).length === 0 || !viewConfig) {
                        viewConfig = this._getDefaultViewConfig();
                        if (viewConfig) {
                            viewId = viewConfig.id;
                            uri = viewId;
                        }
                    }
                    return {
                        viewId: viewId,
                        viewConfig: viewConfig,
                        uri: uri
                    };
                };
                Application.prototype._onNavigating = function (e) {
                    var _this = this;
                    var result = $.Deferred().resolve().promise();
                    if (!e.cancel) {
                        var _a = this._getNavigatingInfo(e.uri),
                            view = _a.viewId,
                            viewConfig = _a.viewConfig,
                            uri = _a.uri,
                            viewModules = viewConfig.modules || [],
                            viewModulesToSkip = viewConfig.modulesToSkip || [],
                            appModules = this.appConfig.modules || [],
                            requiredModules = appModules.filter(function (appModule) {
                            return viewModulesToSkip.indexOf(appModule) < 0;
                        }).concat(viewModules);
                        if (uri !== e.uri) {
                            e.uri = uri;
                        }
                        if (this.moduleLoader.getModulesToInit(requiredModules).length !== 0 || !this.ns[view]) {
                            e.cancel = true;
                            this.functions["busy"]();
                            result = this.moduleLoader.initModules(requiredModules).then(function () {
                                var navigate = function () {
                                    return _this.navigate(e.uri, e.options);
                                };
                                if (_this.ns[view]) {
                                    navigate();
                                } else {
                                    try {
                                        return _this._ensureView(view).then(navigate).fail(function (error) {
                                            console.error("Failed to load the '" + view + "' view template.");
                                        });
                                    } catch (error) {
                                        console.error("Failed to load the '" + view + "' view template. " + error);
                                    }
                                }
                            }).always(function () {
                                return _this.functions["available"]();
                            });
                        }
                    }
                    return result;
                };
                Application.prototype.createFunctionCompiler = function (code) {
                    if (!this.functions) {
                        console.error("Functions parameter is necessary for compiler");
                    }
                    return new AppPlayer.Logic.FunctionCompiler(this.functions, code, this._errorHandler.bind(this));
                };
                Application.prototype._getDefaultViewConfig = function () {
                    var _this = this;
                    var defaultView = AppPlayer.findInArray(this.appConfig.views, function (view) {
                        return view.id === _this.defaultView;
                    });
                    if (!defaultView) {
                        if (this.defaultView) {
                            AppPlayer.Utils.showError("Default view '" + this.defaultView + "' doesn't exist.");
                        } else if (this.appConfig.views.length) {
                            defaultView = this.appConfig.views[0];
                            if (this.appConfig.views.length > 1) {
                                AppPlayer.Utils.showError("You can specify app default view in the designer. Click the cogwheel button next to the app title, then change Navigation - Default View property.");
                            }
                        } else {
                            AppPlayer.Utils.showError("Your app doesn't have any views. Please create one in the designer.");
                        }
                    }
                    return defaultView;
                };
                Application.prototype.navigateToDefaultView = function () {
                    var defaultView = this._getDefaultViewConfig();
                    if (defaultView) {
                        this.navigate({ view: defaultView.id }, { target: "current" });
                    }
                };
                Application.prototype.on = function (eventName, handler) {
                    switch (eventName) {
                        case "started":
                            this.started.add(handler);
                            break;
                        case "dataError":
                            this.dataError.add(handler);
                            break;
                        default:
                            this.dxapp.on(eventName, handler);
                    }
                };
                Application.prototype.off = function (eventName, handler) {
                    switch (eventName) {
                        case "started":
                            this.started.remove(handler);
                            break;
                        case "dataError":
                            this.dataError.remove(handler);
                            break;
                        default:
                            this.dxapp.off(eventName, handler);
                    }
                };
                Application.prototype.getNavigationItemTitle = function (item) {
                    var title = item.title,
                        viewId,
                        view;
                    if (!title) {
                        viewId = item.id;
                        view = AppPlayer.findInArray(this.appConfig.views, function (view) {
                            return view.id === viewId;
                        });
                        title = view ? view.title : "View Not Found";
                    }
                    return title;
                };
                Application.prototype.htmlAppNavigation = function () {
                    var _this = this;
                    return this.appConfig.navigation.items.map(function (item) {
                        if (typeof item === "string") {
                            item = { id: item };
                        }
                        var functionCompiler = item.onExecute ? _this.createFunctionCompiler(item.onExecute) : undefined,
                            executionHandler;
                        if (functionCompiler) {
                            executionHandler = function (e) {
                                return functionCompiler.run({
                                    $global: _this.model,
                                    $model: undefined,
                                    $data: e,
                                    $value: undefined
                                }, {
                                    callerType: "navigation item",
                                    callerId: item.id
                                });
                            };
                        }
                        var itemCounter = 0,
                            id = item.id || "item" + ++itemCounter,
                            result = {
                            id: id,
                            onExecute: executionHandler || (_this.appConfig["isDesignMode"] !== true ? "#" + (item.id || item) : function () {}),
                            title: _this.getNavigationItemTitle(item),
                            visible: typeof item.visible === "string" && item.visible.length > 0 ? AppPlayer.wrapModelReference(item.visible, { $global: _this.model }, { callerType: "property of the " + id + " command", callerId: "visible" }, _this.functions) : item.visible || true
                        };
                        if ($.isPlainObject(item)) {
                            result = $.extend({}, item, result);
                        }
                        return result;
                    });
                };
                Application.prototype.htmlAppConfiguration = function () {
                    var options = {
                        namespace: this.ns,
                        navigation: this.htmlAppNavigation(),
                        commandMapping: this.getCommandMapping()
                    };
                    if (AppPlayer.LayoutHelper.getDeviceType() === "desktop") {
                        options.mode = "webSite";
                    }
                    return options;
                };
                Application.missingTemplates = [];
                return Application;
            }();
            AppPlayer.Application = Application;
            ;
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Logic;
            (function (Logic) {
                "use strict";

                Logic.logEnabled = false;
                var FunctionCompiler = function () {
                    function FunctionCompiler(functions, calls, errorHandler) {
                        this.functions = functions;
                        this.calls = calls;
                        this.externalErrorHandler = errorHandler;
                    }
                    FunctionCompiler.prototype.run = function (context, callerInfo) {
                        var _this = this;
                        var promise,
                            errorHandler = function (error) {
                            error.source = _this.calls;
                            error.callerInfo = callerInfo;
                            if (_this.externalErrorHandler) {
                                _this.externalErrorHandler(error);
                            }
                        };
                        if (Logic.logEnabled && callerInfo) {
                            console.groupCollapsed("Run '" + callerInfo.callerId + " \"' " + callerInfo.callerType);
                            console.log("Context: %o", context);
                            console.log("Logic: %o", this.calls);
                            console.groupEnd();
                        }
                        if (!this.strategy) {
                            this.strategy = this.createStrategy(this.functions, this.calls);
                        }
                        try {
                            var contextParams = [];
                            if (context) {
                                $.each(context, function (name) {
                                    contextParams.push(name);
                                });
                            }
                            promise = this.strategy.run(context, contextParams);
                            promise.fail(errorHandler);
                        } catch (e) {
                            var error = new Logic.LogicError(e.message || e, null);
                            errorHandler(error);
                            return rejectPromise(error);
                        }
                        return promise;
                    };
                    FunctionCompiler.prototype.createStrategy = function (functions, calls) {
                        if (calls instanceof Function) {
                            return new CompilerJSFunctionStrategy(functions, calls);
                        } else if (!calls || $.isEmptyObject(calls)) {
                            return new CompilerStrategy(functions);
                        } else if (typeof calls === "string") {
                            return BindingFunctionStrategy.isCompatible(calls) ? new BindingFunctionStrategy(functions, calls) : new CompilerTrivialStrategy(functions, calls);
                        } else {
                            var _calls = calls.logic || calls;
                            return new CompilerInlineFunctionStrategy(functions, _calls);
                        }
                    };
                    return FunctionCompiler;
                }();
                Logic.FunctionCompiler = FunctionCompiler;
                var CompilerStrategy = function () {
                    function CompilerStrategy(functions) {
                        this.functions = functions;
                    }
                    CompilerStrategy.prototype.run = function (context, contextParams) {
                        return trivialPromise();
                    };
                    CompilerStrategy.prototype.compile = function (functions, expr, paramNames) {
                        var funcBody = "with($functions){" + expr + "}",
                            allParamNames = ["$functions"];
                        [].push.apply(allParamNames, paramNames);
                        var func = new Function(allParamNames.join(", "), funcBody);
                        return function (params) {
                            var args = [functions];
                            paramNames.forEach(function (name) {
                                args.push(params[name]);
                            });
                            return func.apply(func, args);
                        };
                    };
                    return CompilerStrategy;
                }();
                var CompilerJSFunctionStrategy = function (_super) {
                    __extends(CompilerJSFunctionStrategy, _super);
                    //private compiledFunctions: (params: {}) => any;
                    function CompilerJSFunctionStrategy(functions, calls) {
                        _super.call(this, functions);
                        this.calls = calls;
                    }
                    CompilerJSFunctionStrategy.prototype.run = function (context, contextParams) {
                        /*if(!this.compiledFunctions) {
                            this.compiledFunctions = this.calls;
                        }*/
                        var result = this.calls(context);
                        // Promise duck typing
                        if (result && typeof result.always === "function" && typeof result.done === "function") {
                            return result;
                        } else {
                            return trivialPromise(result);
                        }
                    };
                    return CompilerJSFunctionStrategy;
                }(CompilerStrategy);
                var CompilerTrivialStrategy = function (_super) {
                    __extends(CompilerTrivialStrategy, _super);
                    function CompilerTrivialStrategy(functions, calls) {
                        _super.call(this, functions);
                        this.calls = calls;
                    }
                    CompilerTrivialStrategy.prototype.run = function (context, contextParams) {
                        if (!this.compiledFunctions) {
                            this.compiledFunctions = this.compile(this.functions, this.calls, contextParams);
                        }
                        var result = this.compiledFunctions(context);
                        // Promise duck typing
                        if (result && typeof result.always === "function" && typeof result.done === "function") {
                            return result;
                        } else {
                            return trivialPromise(result);
                        }
                    };
                    return CompilerTrivialStrategy;
                }(CompilerStrategy);
                var CompilerInlineFunctionStrategy = function (_super) {
                    __extends(CompilerInlineFunctionStrategy, _super);
                    function CompilerInlineFunctionStrategy(functions, calls) {
                        _super.call(this, functions);
                        this.calls = calls;
                    }
                    CompilerInlineFunctionStrategy.prototype.getAllVariables = function (params, variables) {
                        var result = {};
                        variables.forEach(function (v) {
                            result[v.name] = v;
                        });
                        $.each(params, function (name) {
                            if (!result[name]) {
                                result[name] = new Logic.Variable({ name: name, value: null, parameter: true, type: "object" });
                            }
                        });
                        return result;
                    };
                    CompilerInlineFunctionStrategy.prototype.run = function (context, contextParams) {
                        if (!this.calls) {
                            return null;
                        }
                        var variables = [],
                            calls = [];
                        if (this.calls.variables) {
                            variables = this.calls.variables.map(function (value) {
                                return Logic.Variable.fromJson(value);
                            });
                        }
                        if (this.calls.calls) {
                            calls = this.calls.calls.map(function (call) {
                                return Logic.Operation.fromJson(call);
                            });
                        }
                        var allVariables = this.getAllVariables(context, variables);
                        Object.getOwnPropertyNames(allVariables).forEach(function (name) {
                            var variable = allVariables[name];
                            variable.resetValue();
                            variable.value = context && variable.parameter ? context[variable.name] : variable.value;
                            allVariables[variable.name] = variable;
                        });
                        var variableStore = new VariableStore(allVariables, this.functions);
                        return Logic.Operation.run(calls, variableStore, this.functions).then(function (result) {
                            if (result && result.flow === Logic.Flow.Return) {
                                return trivialPromise(result.value);
                            }
                            return trivialPromise();
                        });
                    };
                    return CompilerInlineFunctionStrategy;
                }(CompilerStrategy);
                var BindingFunctionStrategy = function (_super) {
                    __extends(BindingFunctionStrategy, _super);
                    function BindingFunctionStrategy(functions, functionName) {
                        _super.call(this, functions, functionName);
                    }
                    BindingFunctionStrategy.isCompatible = function (functionName) {
                        return (/^\$(global|model)\.[\w\$]+$/.test(functionName)
                        );
                    };
                    BindingFunctionStrategy.prototype.compile = function (functions, functionName, argNames) {
                        var funcBody = "return " + functionName + "($context);",
                            allParamNames = ["$context"];
                        [].push.apply(allParamNames, argNames);
                        var func = new Function(allParamNames.join(", "), funcBody);
                        return function (context) {
                            var args = [context];
                            argNames.forEach(function (name) {
                                args.push(context[name]);
                            });
                            return func.apply(func, args);
                        };
                    };
                    return BindingFunctionStrategy;
                }(CompilerTrivialStrategy);
                var VariableStore = function () {
                    function VariableStore(variables, functions) {
                        this.variables = variables;
                        variables["$functions"] = variables["$functions"] || new Logic.Variable({ name: "$functions", value: functions || {} });
                        this.cachedGetters = {};
                    }
                    VariableStore.prototype.add = function (name, value) {
                        this.variables[name] = new Logic.Variable({ name: name, value: value });
                    };
                    VariableStore.prototype.get = function (name) {
                        return this.variables[name];
                    };
                    VariableStore.prototype.isDefined = function (pathExpr) {
                        if (typeof pathExpr !== "string" || !pathExpr.length) {
                            return false;
                        }
                        var variableName = this.getVariableName(pathExpr);
                        return !!this.variables[variableName];
                    };
                    VariableStore.prototype.getValue = function (valueExpr) {
                        if (typeof valueExpr !== "string" || !valueExpr.length) {
                            return valueExpr;
                        }
                        var getter = this.cachedGetters[valueExpr];
                        if (!getter) {
                            this.cachedGetters[valueExpr] = getter = this.compileGetter(valueExpr);
                        }
                        return getter();
                    };
                    VariableStore.prototype.evalAutoExpression = function (valueOrExpr) {
                        return valueOrExpr.startsWith("=") ? this.getValue(valueOrExpr.substr(1)) : valueOrExpr;
                    };
                    VariableStore.prototype.getValueOrDefault = function (valueExpr, defaultValue) {
                        try {
                            return this.getValue(valueExpr);
                        } catch (error) {
                            return defaultValue;
                        }
                    };
                    VariableStore.prototype.setValue = function (pathExpr, value) {
                        if (typeof pathExpr !== "string" || !pathExpr.length) {
                            return;
                        }
                        var path = this.evalPath(pathExpr),
                            setter = this.compileSetter(path); // TODO Statsenko: cache setters
                        setter(value);
                    };
                    VariableStore.prototype.clone = function () {
                        return new VariableStore($.extend({}, this.variables));
                    };
                    VariableStore.prototype.getContext = function (onlyModel) {
                        if (onlyModel === void 0) {
                            onlyModel = false;
                        }
                        var context = {};
                        $.each(this.variables, function (name, variable) {
                            if (onlyModel && name.indexOf("$") !== 0) {
                                return;
                            }
                            context[name] = variable.value;
                        });
                        return context;
                    };
                    VariableStore.prototype.compileGetter = function (expr) {
                        var _this = this;
                        if (this.variables[expr]) {
                            return function () {
                                return _this.variables[expr].value;
                            };
                        }
                        var varNames = [];
                        $.each(this.variables, function (name, variable) {
                            varNames.push(variable.name);
                        });
                        varNames.push("with($functions) { return (" + expr + "); }");
                        var fn = Function.apply(null, varNames);
                        return function () {
                            var varValues = varNames.slice(0, varNames.length - 1).map(function (varName) {
                                return _this.variables[varName].value;
                            });
                            return fn.apply(null, varValues);
                        };
                    };
                    VariableStore.prototype.evalPath = function (path) {
                        var bracketIndex = path.indexOf("["),
                            closeBracketIndex,
                            result = bracketIndex > 0 ? path.substr(0, bracketIndex) : path,
                            bracketContents;
                        while (bracketIndex > 0) {
                            closeBracketIndex = path.indexOf("]", bracketIndex);
                            bracketContents = path.substring(bracketIndex + 1, closeBracketIndex).trim();
                            result += "." + this.getValue(bracketContents);
                            bracketIndex = path.indexOf("[", closeBracketIndex);
                            result += path.substring(closeBracketIndex + 1, bracketIndex > 0 ? bracketIndex : undefined);
                        }
                        return result;
                    };
                    VariableStore.prototype.compileSetter = function (path) {
                        var _this = this;
                        if (this.variables[path]) {
                            return function (value) {
                                return _this.variables[path].value = value;
                            };
                        }
                        var variableName = this.getVariableName(path),
                            propertyPath = path.substr(variableName.length + 1);
                        if (!this.variables[variableName]) {
                            throw new Error("Variable: " + variableName + " is not defined");
                        }
                        var setter = AppPlayer.compileSetter(propertyPath);
                        return function (value) {
                            return setter(_this.variables[variableName].value, value);
                        };
                    };
                    VariableStore.prototype.getVariableName = function (path) {
                        var dotIndex = path.indexOf(".");
                        dotIndex = dotIndex === -1 ? path.length : dotIndex;
                        var bracketIndex = path.indexOf("[");
                        bracketIndex = bracketIndex === -1 ? path.length : bracketIndex;
                        var variableNameEnd = Math.min(dotIndex, bracketIndex),
                            variableName = path.substring(0, variableNameEnd);
                        return variableName;
                    };
                    VariableStore.createModelDefaults = function (config) {
                        if (config === void 0) {
                            config = {};
                        }
                        var store = new VariableStore({});
                        Object.keys(config).forEach(function (modelName) {
                            var model = {},
                                modelConfig = config[modelName];
                            modelConfig.forEach(function (propertyConfig) {
                                return model[propertyConfig.name] = propertyConfig.defaultValue;
                            });
                            store.add(modelName, model);
                        });
                        return store;
                    };
                    return VariableStore;
                }();
                Logic.VariableStore = VariableStore;
                function trivialPromise() {
                    var args = [];
                    for (var _i = 0; _i < arguments.length; _i++) {
                        args[_i - 0] = arguments[_i];
                    }
                    var d = $.Deferred();
                    return d.resolve.apply(d, arguments).promise();
                }
                Logic.trivialPromise = trivialPromise;
                function rejectPromise() {
                    var args = [];
                    for (var _i = 0; _i < arguments.length; _i++) {
                        args[_i - 0] = arguments[_i];
                    }
                    var d = $.Deferred();
                    return d.reject.apply(d, arguments).promise();
                }
                Logic.rejectPromise = rejectPromise;
                function returnsValue(calls) {
                    if (!calls) {
                        return false;
                    }
                    var result = false,
                        visitor = function (target) {
                        if (target["_type"] === "Event" && target["flow"] === Logic.Flow.Return) {
                            result = true;
                            return;
                        }
                        $.each(target, function (_, value) {
                            if (result) {
                                return false;
                            }
                            if (value && ($.isArray(value) || typeof value === "object")) {
                                visitor(value);
                            }
                        });
                    };
                    visitor(calls);
                    return result;
                }
                Logic.returnsValue = returnsValue;
            })(Logic = AppPlayer.Logic || (AppPlayer.Logic = {}));
        })(AppPlayer || (AppPlayer = {}));
        /// <reference path="logic/functioncompiler.ts" />
        var AppPlayer;
        (function (AppPlayer) {
            var Modules;
            (function (Modules) {
                "use strict";

                var AuthorizationLocation = function () {
                    function AuthorizationLocation() {}
                    return AuthorizationLocation;
                }();
                var Authorization = function () {
                    function Authorization(appConf, app) {
                        var _this = this;
                        this.locations = [];
                        this.loginView = "";
                        this.allowAnonymous = true;
                        this.app = app;
                        if (appConf.authorization) {
                            var auth = appConf.authorization;
                            this.loginView = auth.loginView;
                            this.allowAnonymous = auth.allowAnonymous;
                            (auth.locations || []).forEach(function (item) {
                                var allowAnonymous = item.allowAnonymous;
                                if (typeof allowAnonymous === "string") {
                                    allowAnonymous = allowAnonymous.toLowerCase() === "true";
                                }
                                _this.locations.push({ view: item.view, allowAnonymous: allowAnonymous });
                            });
                        }
                        app.functions["logout"] = function () {
                            _this.logout();
                        };
                        app.on("dataError", function (e) {
                            if (e.error.httpStatus === 401 || e.error.status === 401 || e.error.message === "Unauthorized") {
                                e.handled = true;
                                _this.logout();
                            }
                        });
                        this.onNavigating = function (e) {
                            if (!_this.canNavigate(e.uri)) {
                                e.cancel = true;
                                if (_this.loginView) {
                                    setTimeout(function () {
                                        app.navigate({ view: _this.loginView }, { root: true });
                                    });
                                } else {
                                    AppPlayer.Utils.showError("Login view is not specified and anonymous access is disabled");
                                }
                            }
                        };
                        this.app.on("navigating", this.onNavigating);
                    }
                    Object.defineProperty(Authorization.prototype, "authenticated", {
                        get: function () {
                            return !!this.app.model.authenticated;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Authorization.prototype.canNavigate = function (path) {
                        if (this.authenticated || path === this.loginView || path === encodeURIComponent(this.loginView)) {
                            return true;
                        }
                        var locations = this.locations.filter(function (location) {
                            return path.indexOf(location.view) === 0;
                        });
                        return locations.length ? locations[0].allowAnonymous : this.allowAnonymous;
                    };
                    Authorization.prototype.logout = function () {
                        var application = this.app;
                        application.model.authenticated = false;
                        application.restart();
                    };
                    return Authorization;
                }();
                Modules.Authorization = Authorization;
            })(Modules = AppPlayer.Modules || (AppPlayer.Modules = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            "use strict";

            var dxui = DevExpress.ui;
            // Fixes dxSelectBox from loosing its value when it isn't present in the items/dataSource list
            var XetSelectBox = function (_super) {
                __extends(XetSelectBox, _super);
                function XetSelectBox() {
                    _super.apply(this, arguments);
                }
                XetSelectBox.prototype._processDataSourceChanging = function () {
                    this["_setListDataSource"]();
                    this["_renderValue"]();
                };
                return XetSelectBox;
            }(dxui.dxSelectBox);
            AppPlayer.XetSelectBox = XetSelectBox;
            ;
            DevExpress.registerComponent("xetSelectBox", XetSelectBox);
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            "use strict";

            ko.bindingHandlers["dxOptions"] = {
                update: function (element, valueAccessor) {
                    var value = ko.utils.unwrapObservable(valueAccessor() || {});
                    $.each(value, function (optionName, optionValue) {
                        optionValue = ko.unwrap(optionValue) || 0;
                        element["data-options"] = optionName + optionValue;
                    });
                }
            };
            ko.bindingHandlers["dxPartialView"] = {
                init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                    //var view = ko.utils.unwrapObservable(valueAccessor() || {})["viewName"];
                    $(element).append($("#xet-view").text());
                }
            };
            ko.bindingHandlers["themeCustomizer"] = {
                init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                    ko.computed(function () {
                        var DYNAMIC_STYLES_ID = "dynamic-styles",
                            css = valueAccessor().theme;
                        if (css) {
                            $("#" + DYNAMIC_STYLES_ID).remove();
                            $("<style>" + css + "</style>").attr("type", "text/css").attr("id", DYNAMIC_STYLES_ID).appendTo("head");
                            DevExpress.ui.themes.current({ _autoInit: true });
                        }
                    });
                }
            };
            ko.bindingHandlers["xetScrollViewResetter"] = {
                init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                    valueAccessor()["reset"] = function () {
                        $(element).find(".dx-scrollview").each(function (index, scrollViewElement) {
                            var scrollView = $(scrollViewElement).dxScrollView("instance");
                            scrollView.update();
                            scrollView.scrollTo(0);
                        });
                    };
                }
            };
            function preventCollapsingInSafari(context, propertyName) {
                setTimeout(function () {
                    var targetElement = context.nextElementSibling,
                        propertyValueDeclared = targetElement.style[propertyName],
                        propertyValueCalculated = $(targetElement)[propertyName]();
                    if (propertyValueDeclared.indexOf("%") !== -1 && propertyValueCalculated === 0) {
                        targetElement.style[propertyName] = "initial";
                    }
                });
            }
            ko.bindingHandlers["preventCollapsingInSafari"] = {
                update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                    if (navigator.userAgent.toLowerCase().indexOf("safari") !== -1 && !window["MSStream"]) {
                        ["height", "width"].forEach(function (property) {
                            preventCollapsingInSafari(element, property);
                        });
                    }
                }
            };
            ko.bindingHandlers["debugger"] = {
                update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                    ko.unwrap(valueAccessor().track);
                    /* tslint:disable: no-debugger */
                    debugger;
                    /* tslint:enable */
                }
            };
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            "use strict";

            var dxhtml = DevExpress.framework.html;
            var dx = DevExpress;
            var LayoutHelper = function () {
                function LayoutHelper() {}
                LayoutHelper.tryGetCurrentPlatform = function (platforms, currentDevice) {
                    currentDevice = currentDevice || dx.devices.current();
                    var matchingPlatforms = DevExpress.utils["findBestMatches"](currentDevice, (platforms || []).map(function (platform, index) {
                        return $.extend({ platformIndex: index }, platform.options);
                    }));
                    return matchingPlatforms.length ? platforms[matchingPlatforms[0].platformIndex] : undefined;
                };
                LayoutHelper.getLayoutController = function (platform, designMode) {
                    var layoutNameToControllerMap = {
                        navbar: "NavBarController",
                        slideout: "SlideOutController",
                        split: "IOSSplitLayoutController",
                        simple: "SimpleLayoutController",
                        empty: "EmptyLayoutController",
                        popup: "PopupLayoutController",
                        designer: "DesignerController"
                    },
                        controllerName = layoutNameToControllerMap[platform.layout],
                        controller;
                    if (platform.layout === "split" && platform.options.generic) {
                        controllerName = "GenericSplitLayoutController";
                    }
                    controller = controllerName && dx.framework.html[controllerName] ? new dx.framework.html[controllerName]({
                        swipeEnabled: !designMode
                    }) : new dxhtml.DefaultLayoutController({
                        name: "desktop",
                        swipeEnabled: !designMode
                    });
                    if (designMode && controller instanceof DevExpress.framework.html.SlideOutController) {
                        controller._toggleNavigation = function () {};
                    }
                    return controller;
                };
                LayoutHelper.createLayoutSet = function (platforms, designMode, views) {
                    var result = { layoutSet: [], viewSpecificLayouts: [] };
                    platforms.forEach(function (platform) {
                        result.layoutSet.push($.extend({ controller: LayoutHelper.getLayoutController(platform, designMode) }, platform.options || {}));
                    });
                    if (views) {
                        views.forEach(function (view) {
                            if (!view.platforms) {
                                return;
                            }
                            view.platforms.forEach(function (platform) {
                                var controller = LayoutHelper.getLayoutController(platform, designMode);
                                if (platform && platform.modal) {
                                    controller = new dxhtml["PopupLayoutController"]({ childController: controller });
                                }
                                result.layoutSet.push($.extend({ customResolveRequired: true, controller: controller }, platform.options || {}));
                                result.viewSpecificLayouts.push({
                                    view: view.id,
                                    options: platform.options,
                                    controller: controller
                                });
                            });
                        });
                    }
                    return result;
                };
                LayoutHelper.tryGetViewSpecificLayoutController = function (viewName, viewSpecificLayouts) {
                    var foundController;
                    if (viewSpecificLayouts.length > 0) {
                        for (var i = 0; i < viewSpecificLayouts.length; ++i) {
                            var layoutItem = viewSpecificLayouts[i],
                                fits = true,
                                currentDevice = DevExpress.devices.current();
                            if (layoutItem.view === viewName) {
                                if (layoutItem.options) {
                                    $.each(layoutItem.options, function (field, value) {
                                        if (currentDevice[field] !== value) {
                                            return fits = false;
                                        }
                                    });
                                }
                                if (fits) {
                                    foundController = layoutItem.controller;
                                    break;
                                }
                            }
                        }
                    }
                    return foundController;
                };
                LayoutHelper.getDeviceType = function (currentDevice) {
                    if (currentDevice === void 0) {
                        currentDevice = DevExpress.devices.current();
                    }
                    return currentDevice.deviceType || "pnone";
                };
                LayoutHelper.setSimulatorDevice = function (device) {
                    DevExpress.devices.current(device);
                    var real = DevExpress.devices.real();
                    window.top["dx-force-device"] = real.deviceType !== device.deviceType ? device : undefined;
                };
                LayoutHelper.linkTarget = function () {
                    return LayoutHelper.getDeviceType() === "desktop" ? "_blank" : "_system";
                };
                LayoutHelper.fillCommandMapping = function (commandMapping, commands, platforms, currentDevice) {
                    var deviceType = this.getDeviceType(currentDevice),
                        currentPlatform = LayoutHelper.tryGetCurrentPlatform(platforms, currentDevice),
                        map = {
                        "header": ["ios-header-toolbar",
                        //"android-header-toolbar",
                        //"android-simple-toolbar",
                        //"tizen-header-toolbar",
                        //"tizen-simple-toolbar",
                        "generic-header-toolbar", "desktop-toolbar"],
                        "footer": ["ios-view-footer",
                        //"android-footer-toolbar",
                        //"tizen-footer-toolbar",
                        "generic-view-footer"],
                        "toolbar": ["generic-layout-toolbar"],
                        "none": []
                    };
                    (commands || []).forEach(function (command) {
                        var container = command.container ? command.container[deviceType] : null;
                        if (!container) {
                            container = currentPlatform && currentPlatform.defaultCommandContainer || "header";
                        }
                        var currentCommand = {
                            id: command.id
                        },
                            platformContainers = map[container];
                        if (command.alignment && command.alignment.hasOwnProperty(deviceType)) {
                            currentCommand["location"] = command.alignment[deviceType];
                        } else {
                            currentCommand["location"] = currentPlatform && currentPlatform.defaultCommandLocation || "after";
                        }
                        if (!platformContainers) {
                            console.error("Unknown command container '" + container + "'. Supported values are: header, footer, toolbar");
                            return;
                        }
                        platformContainers.forEach(function (container) {
                            if (commandMapping[container]) {
                                commandMapping[container].commands.push(currentCommand);
                            } else {
                                commandMapping[container] = { commands: [currentCommand] };
                            }
                        });
                    });
                    return commandMapping;
                };
                return LayoutHelper;
            }();
            AppPlayer.LayoutHelper = LayoutHelper;
        })(AppPlayer || (AppPlayer = {}));
        /// <reference path="logic/functioncompiler.ts" />
        var AppPlayer;
        (function (AppPlayer) {
            "use strict";

            ;
            var Model = function () {
                function Model() {}
                Model.createAppModel = function (config, app) {
                    var model = {},
                        context = { $global: model };
                    return Model.createModelCore(config, app, context, "global ", model);
                };
                Model.createModel = function (config, app, onCreatingModel) {
                    var model = {},
                        context = { $global: app["model"], $model: model };
                    return Model.createModelCore(config, app, context, "", model, onCreatingModel);
                };
                Model.createPlainPropertyDescriptor = function (item, options) {
                    var app = options.app,
                        modelId = options.modelId,
                        isDefaultLoaded = false,
                        typeInfo = app.typeInfoRepository.get(item.type),
                        knownType = !item.type || typeInfo,
                        isStore = typeInfo && typeInfo.kind === AppPlayer.TYPES.STORE_TYPE,

                    // TODO: Beresnev Hack for bugs after hand testing, need fix in next release
                    defaultValue = knownType && !isStore ? (typeInfo || null) && typeInfo.defaultValueCtor() : 42,
                        isArray = typeInfo && typeInfo.kind === AppPlayer.TYPES.ARRAY_TYPE,
                        observable = isArray ? ko.observableArray(defaultValue) : ko.observable(defaultValue),
                        getter = function () {
                        return observable();
                    },
                        setter = Model.getObservableSetter(observable.peek(), isArray, observable, "", item.observables);
                    observable.subscribe(function (val) {
                        if (isDefaultLoaded && item.persistent) {
                            app.localStorage.put(modelId, item.name, val);
                        }
                    });
                    if (item.defaultValue !== undefined) {
                        setter(AppPlayer.clone(item.defaultValue));
                    }
                    isDefaultLoaded = true;
                    if (item.persistent) {
                        var localValue = app.localStorage.get(modelId, item.name);
                        if (typeof localValue !== "undefined") {
                            setter(localValue);
                        }
                    }
                    return {
                        modelProperty: item,
                        propertyDescriptor: {
                            enumerable: true,
                            configurable: true,
                            get: getter,
                            set: setter
                        }
                    };
                };
                Model.createCalculatedPropertyDescriptor = function (item, options) {
                    var _this = this;
                    var context = options.context,
                        callerPrefix = options.callerPrefix,
                        app = options.app,
                        observable = ko.observable(),
                        callerInfo = {
                        callerType: callerPrefix + "model property",
                        callerId: item.name
                    },
                        computed = ko.computed(function () {
                        app.createFunctionCompiler(item.getter).run($.extend({}, context), callerInfo).then(function (result) {
                            var observedResult = _this.setObservableProperties(observable(), result, name, item.observables);
                            observable(observedResult);
                        });
                    }, null, { deferEvaluation: true }),
                        descriptor = {
                        enumerable: true,
                        configurable: true,
                        get: function () {
                            computed();
                            return ko.unwrap(observable());
                        }
                    };
                    if (item.setter) {
                        descriptor.set = function (value) {
                            var currentValue = observable();
                            if (currentValue === value) {
                                return;
                            }
                            if (ko.isObservable(currentValue)) {
                                console.error("Property cannot have a setter if getter returns observable.");
                                return;
                            }
                            app.createFunctionCompiler(item.setter).run($.extend({
                                $value: value
                            }, context));
                            var observedValue = _this.setObservableProperties(observable(), value, name, item.observables);
                            observable(observedValue);
                        };
                    }
                    return {
                        modelProperty: item,
                        propertyDescriptor: descriptor,
                        computed: computed
                    };
                };
                Model.createFunctionPropertyDescriptor = function (item, options) {
                    var app = options.app,
                        context = options.context,
                        callerPrefix = options.callerPrefix,
                        callerInfo = {
                        callerType: callerPrefix + "function",
                        callerId: item.name
                    },
                        func = function (args) {
                        return app.createFunctionCompiler(item.function).run($.extend({}, context, args), callerInfo);
                    };
                    return {
                        modelProperty: item,
                        propertyDescriptor: {
                            enumerable: true,
                            configurable: true,
                            value: func
                        }
                    };
                };
                Model.createPropertyDescriptor = function (options) {
                    var item = options.item;
                    if (!!item.getter || !!item.setter) {
                        return this.createCalculatedPropertyDescriptor(item, options);
                    } else if (!!item.function) {
                        return this.createFunctionPropertyDescriptor(item, options);
                    }
                    return this.createPlainPropertyDescriptor(item, options);
                };
                Model.createModelCore = function (config, app, context, callerPrefix, model, onCustomizeProperties) {
                    var _this = this;
                    var allFields = [config.params, config.model, config.functions].reduce(function (p, items) {
                        if (items) {
                            p.push.apply(p, items);
                        }
                        return p;
                    }, []);
                    var properties = allFields.map(function (item) {
                        return _this.createPropertyDescriptor({
                            item: item,
                            app: app,
                            callerPrefix: callerPrefix,
                            context: context,
                            modelId: config.id
                        });
                    });
                    if (onCustomizeProperties) {
                        onCustomizeProperties(properties);
                    }
                    if (this.onCustomizeProperties) {
                        this.onCustomizeProperties(properties);
                    }
                    var observables = properties.filter(function (item) {
                        return !!item.computed;
                    }).map(function (item) {
                        return item.computed;
                    });
                    model.dispose = function () {
                        if (!observables) {
                            return;
                        }
                        observables.forEach(function (item) {
                            return item.dispose();
                        });
                        observables = null;
                    };
                    var descriptors = properties.reduce(function (prev, current) {
                        prev[current.modelProperty.name] = current.propertyDescriptor;
                        return prev;
                    }, {});
                    Object.defineProperties(model, descriptors);
                    return model;
                };
                Model.createLinkedModel = function (options, context, callerInfo, functions) {
                    return AppPlayer.propertyVisitor(options, function (valueContext) {
                        if (AppPlayer.endsWith(valueContext.name, "Expr")) {
                            return valueContext.value;
                        }
                        var expression = valueContext.value;
                        if (expression && typeof expression === "string" && expression.charAt(0) === "$") {
                            var owner = valueContext.owner,
                                propertyName = valueContext.name;
                            var value,
                                modelValue = AppPlayer.getModelValue(expression, context, callerInfo, functions);
                            if (typeof modelValue === "function") {
                                return valueContext.value;
                            }
                            if (valueContext.isArray) {
                                value = ko.computed(function () {
                                    return owner[propertyName] = AppPlayer.getModelValue(expression, context, callerInfo, functions);
                                });
                            } else {
                                value = ko.computed(function () {
                                    return AppPlayer.getModelValue(expression, context, callerInfo, functions);
                                });
                                Object.defineProperty(owner, propertyName, {
                                    enumerable: true,
                                    configurable: true,
                                    get: function () {
                                        return value();
                                    }
                                });
                            }
                            return;
                        }
                        return valueContext.value;
                    });
                };
                Model.processArrayMethodArguments = function (args, methodName, name, observableSelectors) {
                    var newArguments = [],
                        i;
                    switch (methodName) {
                        case "push":
                        case "unshift":
                            for (i = 0; i < args.length; ++i) {
                                newArguments.push(this.setObservableProperties(undefined, args[i], name, observableSelectors));
                            }
                            break;
                        case "splice":
                            newArguments.push(args[0]);
                            newArguments.push(args[1]);
                            for (i = 2; i < args.length; i++) {
                                newArguments.push(this.setObservableProperties(undefined, args[i], name, observableSelectors));
                            }
                            break;
                        case "fill":
                            newArguments.push(this.setObservableProperties(undefined, args[0], name, observableSelectors));
                            for (i = 1; i < args.length; ++i) {
                                newArguments.push(args[i]);
                            }
                            break;
                        case "sort":
                            if (args.length) {
                                newArguments.push(args[0]);
                            }
                            break;
                        default:
                            break;
                    }
                    return newArguments;
                };
                Model.getObservableSetter = function (initialValue, isArray, observable, name, observableSelectors) {
                    var _this = this;
                    if (isArray) {
                        ko.utils.arrayForEach(["pop", "push", "reverse", "shift", "sort", "splice", "unshift", "fill"], function (methodName) {
                            var originalMethod = initialValue[methodName];
                            if (originalMethod) {
                                initialValue[methodName] = function () {
                                    var args = [];
                                    for (var _i = 0; _i < arguments.length; _i++) {
                                        args[_i - 0] = arguments[_i];
                                    }
                                    var processedArguments = _this.processArrayMethodArguments(args, methodName, name, observableSelectors),
                                        methodResult = originalMethod.apply(initialValue, processedArguments || args);
                                    observable.valueHasMutated();
                                    return methodResult;
                                };
                            }
                        });
                    }
                    return function (value) {
                        if (isArray && $.isArray(value) && $.isArray(observable.peek())) {
                            observable.splice.apply(observable, [0, observable.peek().length].concat(value));
                        } else {
                            observable(_this.setObservableProperties(observable(), value, name, observableSelectors));
                        }
                    };
                };
                Model.getObservableDescriptor = function (initialValue, name, observableSelectors) {
                    var isArray = $.isArray(initialValue),
                        observable = isArray ? ko.observableArray(initialValue) : ko.observable(initialValue);
                    return {
                        enumerable: true,
                        configurable: true,
                        get: function () {
                            return observable();
                        },
                        set: Model.getObservableSetter(initialValue, isArray, observable, name, observableSelectors)
                    };
                };
                Model.getPlainDescriptor = function (initialValue, name, observableSelectors) {
                    var _this = this;
                    var currentValue = initialValue;
                    return {
                        enumerable: true,
                        configurable: true,
                        get: function () {
                            return currentValue;
                        },
                        set: function (value) {
                            currentValue = _this.setObservableProperties(currentValue, value, name, observableSelectors);
                        }
                    };
                };
                Model.getDescriptor = function (initialValue, name, observableSelectors) {
                    var nameParts = name.split("."),
                        asterisk = "*";
                    var shouldBeObservable = (observableSelectors || []).some(function (selector) {
                        var selectorParts = selector.split("."),
                            match = true;
                        if (selectorParts.length < nameParts.length) {
                            match = selectorParts[selectorParts.length - 1] === asterisk;
                        } else if (nameParts.length < selectorParts.length) {
                            match = false;
                        } else {
                            for (var i = 0; i < nameParts.length; ++i) {
                                if (selectorParts[i] === asterisk) {
                                    break;
                                } else if (nameParts[i] === selectorParts[i]) {
                                    continue;
                                } else {
                                    match = false;
                                    break;
                                }
                            }
                        }
                        return match;
                    });
                    return shouldBeObservable ? this.getObservableDescriptor(initialValue, name, observableSelectors) : this.getPlainDescriptor(initialValue, name, observableSelectors);
                };
                Model.processArray = function (oldValue, newValue, parentName, observableSelectors) {
                    var _this = this;
                    var processedArray = [];
                    $.each(newValue, function (index, childValue) {
                        processedArray.push(_this.setObservableProperties(oldValue ? ko.unwrap(oldValue)[index] : undefined, childValue, parentName, observableSelectors));
                    });
                    return processedArray;
                };
                Model.setObservableProperties = function (oldValue, newValue, parentName, observableSelectors) {
                    var _this = this;
                    if (!observableSelectors || observableSelectors.length === 0) {
                        return newValue;
                    }
                    if ($.isArray(newValue)) {
                        return this.processArray(oldValue, newValue, parentName, observableSelectors);
                    } else if ($.isPlainObject(newValue)) {
                        var result = $.isPlainObject(oldValue) ? oldValue : {};
                        // NOTE: remove properties from oldValue if not exist in newValue
                        $.each(result, function (name, value) {
                            if (newValue[name] === undefined) {
                                delete result[name];
                            }
                        });
                        // NOTE: set existing or define non-existing properties
                        var descriptors = {};
                        $.each(newValue, function (propName, newPropValue) {
                            if (result[propName] === undefined) {
                                var currentName = parentName === "" ? propName : parentName + "." + propName;
                                var merged = _this.setObservableProperties(result[propName], newPropValue, currentName, observableSelectors);
                                descriptors[propName] = _this.getDescriptor(merged, currentName, observableSelectors);
                            } else {
                                result[propName] = newPropValue;
                            }
                        });
                        Object.defineProperties(result, descriptors);
                        return result;
                    }
                    return newValue;
                };
                Model.initializeDataSources = function (model, context, app, stores, reuseObservables, dataSourceConfigs) {
                    var _this = this;
                    var descriptors = {};
                    (dataSourceConfigs || []).forEach(function (dataSourceConfig) {
                        var dataSource = AppPlayer.Data.DataSource.createDataSource(dataSourceConfig, context, stores, app);
                        /*dataSource.on("loadError", error => {
                            if(error && error.message === "Unauthorized") {
                                return;     // Suppress "Unauthorized" banners since the user will be still redirected to the login page and it won't add any meaning
                            }
                            showErrorDialog(error, error["storeId"]);
                        });*/
                        if (reuseObservables) {
                            model[dataSourceConfig.id].dispose();
                            model[dataSourceConfig.id] = new DevExpress.data.DataSource([{}]);
                            model[dataSourceConfig.id].load().then(function () {
                                model[dataSourceConfig.id].dispose();
                                model[dataSourceConfig.id] = dataSource;
                            });
                        }
                        descriptors[dataSourceConfig.id] = _this.getDescriptor(dataSource, dataSourceConfig.id, [dataSourceConfig.id]);
                    });
                    if (!reuseObservables) {
                        Object.defineProperties(model, descriptors);
                    }
                };
                return Model;
            }();
            AppPlayer.Model = Model;
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            "use strict";

            var ModelTracer = function () {
                function ModelTracer() {}
                ModelTracer.decorate = function (descriptor, modelPropertyName, options, getterStack) {
                    var _this = this;
                    var startCalculating = function (name) {
                        if (options.isCalculating) {
                            getterStack.unshift(name);
                        }
                    },
                        addTrace = function (trace) {
                        var currentCalculatingProp = getterStack[0] || "NonInspected",
                            calcPropTrace = _this.modelTrace[currentCalculatingProp] || [];
                        _this.modelTrace[currentCalculatingProp] = calcPropTrace.concat(trace);
                    },
                        endCalculating = function (inspected) {
                        if (inspected === void 0) {
                            inspected = true;
                        }
                        if (options.isCalculating) {
                            var calculatedGetterTrace = _this.modelTrace[getterStack[0]];
                            getterStack.shift();
                            addTrace(calculatedGetterTrace);
                        }
                    },
                        oldProperty = descriptor[options.property],
                        result;
                    descriptor[options.property] = function (args) {
                        startCalculating(modelPropertyName);
                        if (!options.isCalculating) {
                            addTrace([modelPropertyName]);
                        }
                        result = oldProperty(args);
                        endCalculating();
                        return result;
                    };
                };
                ModelTracer.init = function () {
                    var _this = this;
                    this.modelTrace = {};
                    AppPlayer.Model.onCustomizeProperties = function (descriptors) {
                        var getterStack = [];
                        descriptors.forEach(function (descriptor) {
                            var property = descriptor.modelProperty.function ? "value" : "get",
                                options = { property: property, isCalculating: !!descriptor.modelProperty.function || !!descriptor.modelProperty.getter };
                            _this.decorate(descriptor.propertyDescriptor, descriptor.modelProperty.name, options, getterStack);
                        });
                    };
                };
                ModelTracer.cancel = function () {
                    this.modelTrace = undefined;
                    AppPlayer.Model.onCustomizeProperties = undefined;
                };
                ModelTracer.revertTrace = function (withNonInspect) {
                    if (withNonInspect === void 0) {
                        withNonInspect = true;
                    }
                    var result = {};
                    $.each(this.modelTrace, function (getterName, arrayProp) {
                        arrayProp.forEach(function (name) {
                            result[name] = result[name] || [];
                            if (withNonInspect || getterName !== "NonInspected") {
                                result[name].push(getterName);
                            }
                        });
                    });
                    return result;
                };
                return ModelTracer;
            }();
            AppPlayer.ModelTracer = ModelTracer;
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            "use strict";

            var ModulesLoader = function () {
                /*private _loadModule(rootPath: string, moduleItem: IModuleConfig): JQueryPromise<any> {
                    var result = $.Deferred();
                    this.bootstrap(moduleItem.files, rootPath).done(() => {
                        this._initModule(moduleItem.namespace, rootPath);
                        result.resolve();
                    });
                    return result;
                }*/
                function ModulesLoader(application /*, progressRepoter?: Bootstrapper.TaskProgressReporter*/) {
                    //super(progressRepoter);
                    this._application = application;
                    this.alreadyLoadedModules = [];
                }
                ModulesLoader.prototype._initModule = function (_module) {
                    var _this = this;
                    //var _module: IModule = compileGetter(moduleVarName)(window);
                    if (_module) {
                        if (_module.functions && this._application) {
                            _module.functions.forEach(function (funcDeclaration) {
                                _this._application.functions[funcDeclaration.id] = funcDeclaration.func;
                            });
                        }
                        if (_module.createModule) {
                            _module.createModule(this._application);
                        }
                    }
                };
                ModulesLoader.prototype.insertFingerprint = function (path) {
                    if (ModulesLoader.resourceFingerprint) {
                        var index = path.lastIndexOf(".");
                        return path.substring(0, index) + ModulesLoader.resourceFingerprint + path.substring(index);
                    } else {
                        return path;
                    }
                };
                ModulesLoader.prototype.initModules = function (modulesConfig) {
                    var _this = this;
                    var result = $.Deferred();
                    if (modulesConfig) {
                        var promises = this.getModulesToInit(modulesConfig).map(function (moduleInfo) {
                            var ajaxResult = $.Deferred(),
                                rootModuleName = moduleInfo.src || moduleInfo,
                                rootModuleUrl = "modules" + (AppPlayer["Version"] ? "@" + AppPlayer["Version"] : "") + "/" + rootModuleName + "/distr",
                                systemImport = System.import(rootModuleUrl + "/module.config.js");
                            _this.alreadyLoadedModules.push(rootModuleName);
                            systemImport.catch(function (err) {
                                var index = _this.alreadyLoadedModules.indexOf(rootModuleName);
                                _this.alreadyLoadedModules.splice(index);
                                result.reject(err);
                            });
                            if (AppPlayer["Version"]) {
                                systemImport = systemImport.then(function () {
                                    return System.import(rootModuleUrl + "/bundle.js");
                                });
                            }
                            systemImport.then(function () {
                                return System.import(rootModuleUrl + "/module.js");
                            }).then(function (module) {
                                _this._initModule(module.default);
                                ajaxResult.resolve();
                            });
                            return ajaxResult;
                        });
                        $.when.apply($, promises).done(function () {
                            result.resolve();
                        });
                    } else {
                        result.resolve();
                    }
                    return result.promise();
                };
                ModulesLoader.prototype.getModulesToInit = function (modulesConfig) {
                    var _this = this;
                    return modulesConfig.filter(function (module) {
                        return module && _this.alreadyLoadedModules.indexOf(module["src"] || module) === -1;
                    });
                };
                return ModulesLoader;
            }();
            AppPlayer.ModulesLoader = ModulesLoader;
            var ModuleBase = function () {
                function ModuleBase(application) {
                    this._application = application;
                }
                return ModuleBase;
            }();
            AppPlayer.ModuleBase = ModuleBase;
        })(AppPlayer || (AppPlayer = {}));
        // <reference path="../../bootstrapper/ts/bootstrapper.ts" />
        //module AppPlayer {
        //    "use strict";
        //    export interface IModule {
        //        createModule?: (application: Application) => any;
        //        functions?: { id: string; func: (...args: any[]) => any }[];
        //    }
        //    export interface IModuleConfig {
        //        namespace: string;
        //        files: (string | Bootstrapper.IBootstrapperResource)[];
        //    }
        //    export class ModulesLoader extends Bootstrapper.Bootstrapper {
        //        public static MODULEFILENAME = "module.json";
        //        _application: Application;
        //        private _initModule(moduleVarName, rootPath) {
        //            var _module: IModule = compileGetter(moduleVarName)(window);
        //            if(_module) {
        //                if(_module.functions && this._application) {
        //                    _module.functions.forEach((funcDeclaration) => {
        //                        this._application.functions[funcDeclaration.id] = funcDeclaration.func;
        //                    });
        //                }
        //                if(_module.createModule) {
        //                    _module.createModule(this._application);
        //                }
        //            }
        //        }
        //        private _loadModule(rootPath: string, moduleItem: IModuleConfig): JQueryPromise<any> {
        //            var result = $.Deferred();
        //            this.bootstrap(moduleItem.files, rootPath).done(() => {
        //                this._initModule(moduleItem.namespace, rootPath);
        //                result.resolve();
        //            });
        //            return result;
        //        }
        //        constructor(application: Application, progressRepoter?: Bootstrapper.TaskProgressReporter) {
        //            super(progressRepoter);
        //            this._application = application;
        //            this.alreadyLoadedModules = [];
        //        }
        //        alreadyLoadedModules: string[];
        //        public initModules(modulesConfig: IModulesSrc): JQueryPromise<any> {
        //            var result = $.Deferred();
        //            if(modulesConfig) {
        //                var promises = this.getModulesToInit(modulesConfig)
        //                    .map(moduleInfo => {
        //                        var ajaxResult = $.Deferred();
        //                        var rootModuleUrl = (<{ src: string }>moduleInfo).src || <string>moduleInfo;
        //                        this.alreadyLoadedModules.push(rootModuleUrl);
        //                        $.getJSON(rootModuleUrl + "/" + this.insertFingerprint(ModulesLoader.MODULEFILENAME)).done((moduleItem: IModuleConfig) => {
        //                            this._loadModule(rootModuleUrl, moduleItem).done(() => {
        //                                ajaxResult.resolve();
        //                            });
        //                        }).fail((error) => {
        //                            var index = this.alreadyLoadedModules.indexOf(rootModuleUrl);
        //                            this.alreadyLoadedModules.splice(index);
        //                            ajaxResult.reject(error);
        //                        });
        //                        return ajaxResult;
        //                    });
        //                $.when.apply($, promises).done(() => {
        //                    result.resolve();
        //                });
        //            } else {
        //                result.resolve();
        //            }
        //            return result.promise();
        //        }
        //        public getModulesToInit(modulesConfig: IModulesSrc) {
        //            return modulesConfig.filter((module) => { return module && this.alreadyLoadedModules.indexOf(module["src"] || module) === -1; });
        //        }
        //    }
        //}  
        var AppPlayer;
        (function (AppPlayer) {
            var Utils;
            (function (Utils) {
                var Cast;
                (function (Cast) {
                    "use strict";

                    function isString(value) {
                        return typeof value === "string" || value instanceof String;
                    }
                    Cast.isString = isString;
                    function isPromise(value) {
                        if (value == null || typeof value.then !== "function") {
                            return false;
                        }
                        var promiseThenSrc = String($.Deferred().then);
                        var valueThenSrc = String(value.then);
                        return promiseThenSrc === valueThenSrc;
                    }
                    Cast.isPromise = isPromise;
                })(Cast = Utils.Cast || (Utils.Cast = {}));
            })(Utils = AppPlayer.Utils || (AppPlayer.Utils = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Utils;
            (function (Utils) {
                "use strict";

                function continueFunc(func, continulation) {
                    if (func) {
                        return function (arg) {
                            var result = func(arg);
                            return continulation(result);
                        };
                    } else {
                        return continulation;
                    }
                }
                Utils.continueFunc = continueFunc;
                function appendHtml(parent, html) {
                    var div = document.createElement("div");
                    div.innerHTML = html;
                    while (div.children.length) {
                        var child = div.children[0];
                        parent.appendChild(child);
                    }
                }
                Utils.appendHtml = appendHtml;
                function showErrorDialog(htmlMessage) {
                    var toastOptions = {
                        closeOnOutsideClick: true,
                        closeOnSwipe: false,
                        contentTemplate: function () {
                            return $("<div>").addClass("dx-toast-message").html(htmlMessage).css("word-break", "break-word");
                        }
                    };
                    DevExpress.ui.notify(toastOptions, "error", 30000);
                }
                function showError(error) {
                    if (!error) {
                        return;
                    }
                    if (typeof error === "string") {
                        console.error(error);
                        showErrorDialog(error);
                    } else if (error instanceof AppPlayer.Logic.LogicError || error instanceof AppPlayer.Logic.DataLogicError) {
                        var stringMessage = error.message,
                            htmlMessage = error.message;
                        if (error.callerInfo && error.callerInfo.callerType && error.callerInfo.callerId) {
                            stringMessage = "Error occurred when trying to evaluate the \"" + error.callerInfo.callerId + "\" " + error.callerInfo.callerType + ":\n " + stringMessage;
                            htmlMessage = "Error occurred when trying to evaluate the \"" + error.callerInfo.callerId + "\" " + error.callerInfo.callerType + ":<br> " + htmlMessage;
                        }
                        console.groupCollapsed(stringMessage);
                        console.log("Operation:", error.operation);
                        console.log("Logic:", error.source);
                        console.groupEnd();
                        showErrorDialog(htmlMessage);
                    } else {
                        var stringMessage = error.message,
                            htmlMessage = error.message;
                        if (error.message.indexOf("CORS") !== -1 && showError["CORS"]) {
                            stringMessage += "\nRead more about CORS here: https://xenarius.net/docs/cors.html";
                            htmlMessage += "<br><a href='https://xenarius.net/docs/cors.html'>Read more about CORS</a>";
                        }
                        if (error["initiatorId"]) {
                            stringMessage += "\nInitiated by '" + error["initiatorId"] + "'";
                            stringMessage += "<br>Initiated by '" + error["initiatorId"] + "'";
                        }
                        console.error(stringMessage);
                        showErrorDialog(htmlMessage);
                    }
                }
                Utils.showError = showError;
                showError["CORS"] = true;
                function ajax(settings) {
                    return $.ajax(settings).then(function (data, statusText, xhr) {
                        if (data instanceof Document) {
                            data = AppPlayer.Stores.Utils.convertData(xhr, "xml");
                        }
                        return data;
                    }, function (xhr, statusText, errorThrown) {
                        var result = $.Deferred();
                        if (statusText === "parsererror") {
                            var data = AppPlayer.Stores.Utils.convertData(xhr, settings.dataType);
                            if (data) {
                                result.resolve(data);
                            }
                        }
                        if (result.state() !== "resolved") {
                            var error = getDataError(settings, xhr, statusText, errorThrown);
                            result.reject(error);
                        }
                        return result;
                    });
                }
                Utils.ajax = ajax;
                var dxTextStatusMessages = {
                    timeout: "Network connection timeout",
                    error: "Unspecified network error",
                    parsererror: "Unexpected server response"
                };
                function getErrorTitle(title, url) {
                    return (url ? "Requesting \"" + url + "\" raises an error (" + title + ")" : title) + ".";
                }
                function getDataErrorMessage(settings, xhr, textStatus, errorThrown) {
                    var url = settings && settings.url,
                        message;
                    if (textStatus === "parsererror") {
                        var dataType = settings && settings.dataType,
                            dataPreview = xhr && xhr.responseText && AppPlayer.shorten(xhr.responseText, 50);
                        message = getErrorTitle(dxTextStatusMessages.parsererror, url) + (dataType ? " The received data cannot be parsed as \"" + dataType + "\". You probably specified a wrong data type." : "") + (dataPreview ? " The following data was received: \"" + dataPreview + "." : "");
                    } else if (textStatus === "timeout") {
                        message = getErrorTitle(dxTextStatusMessages.timeout, url);
                    } else if (errorThrown) {
                        message = getErrorTitle(errorThrown, url);
                    } else if (textStatus === "error") {
                        message = getErrorTitle(dxTextStatusMessages.error, url) + " Ensure that the server returns correct CORS headers.";
                    } else {
                        message = getErrorTitle("Unknown error with status \"" + textStatus + "\"", url);
                    }
                    return message;
                }
                Utils.getDataErrorMessage = getDataErrorMessage;
                function getDataError(settings, xhr, textStatus, errorThrown) {
                    var message = getDataErrorMessage(settings, xhr, textStatus, errorThrown),
                        error = new Error(message);
                    error.httpStatus = xhr.status;
                    error.response = xhr.response || AppPlayer.Stores.Utils.convertData(xhr, settings.dataType);
                    return error;
                }
                Utils.getDataError = getDataError;
                function correctODataError(error) {
                    var textStatus = Object.keys(dxTextStatusMessages).filter(function (key) {
                        return dxTextStatusMessages[key] === error.message;
                    })[0],
                        errorThrown = textStatus ? null : error.message;
                    error.message = getDataErrorMessage(null, null, textStatus, errorThrown);
                    if (typeof error["errorDetails"] !== "function") {
                        error.response = error["errorDetails"];
                    }
                }
                Utils.correctODataError = correctODataError;
            })(Utils = AppPlayer.Utils || (AppPlayer.Utils = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            "use strict";

            function bracketsToDots(expr) {
                return expr.replace(/\[/g, ".").replace(/\]/g, "");
            }
            ;
            function getModelValue(expr, runContext, callerInfo, functions) {
                return executeModelSpecificAccessor(expr, runContext, callerInfo, functions, function (specificModel, value) {
                    return compileGetter(value)(specificModel);
                });
            }
            AppPlayer.getModelValue = getModelValue;
            ;
            function executeModelSpecificAccessor(expr, runContext, callerInfo, functions, accessor) {
                var isExpression = expr.charAt(0) === "=",
                    isNegative = expr.charAt(0) === "!",
                    absExpr = isNegative || isExpression ? expr.substring(1) : expr,
                    compiler,
                    pointIndex,
                    rootPropertyName,
                    valuePath;
                if (isExpression) {
                    compiler = functions["createFunctionCompiler"]("return (" + absExpr + ")");
                    return ko.computed(function () {
                        var result,
                            async = true;
                        compiler.run(runContext, callerInfo).done(function (val) {
                            result = val;
                            async = false;
                        });
                        if (async) {}
                        return result;
                    });
                } else {
                    pointIndex = absExpr.indexOf(".");
                    rootPropertyName = absExpr.substring(0, pointIndex) || absExpr;
                    valuePath = pointIndex === -1 ? "" : absExpr.substring(pointIndex + 1);
                    return runContext[rootPropertyName] ? accessor(runContext[rootPropertyName], valuePath, isNegative, expr) : expr;
                }
            }
            function compileGetter(expr, fullExpr) {
                if (!expr) {
                    return function (obj) {
                        return ko.unwrap(obj);
                    };
                }
                expr = bracketsToDots(expr);
                var path = expr.split(".");
                return function (obj) {
                    var current = ko.unwrap(obj);
                    path.forEach(function (name, index) {
                        if (!current) {
                            return false;
                        }
                        if (typeof current[name] === "undefined" && !current.hasOwnProperty(name)) {
                            console.error("Binding path \"%s\" is incorrect for %o", fullExpr || expr, obj);
                        }
                        var next = index !== path.length - 1 ? ko.unwrap(current[name]) : current[name];
                        current = next;
                    });
                    return ko.unwrap(current);
                };
            }
            AppPlayer.compileGetter = compileGetter;
            ;
            AppPlayer.compileSetter = DevExpress.data.utils.compileSetter;
            function getQueryVariable(variable, locationSearch) {
                if (locationSearch === void 0) {
                    locationSearch = window.location.search;
                }
                var query = locationSearch.substring(1);
                var vars = query.split("&");
                for (var i = 0; i < vars.length; i++) {
                    var eqIndex = vars[i].indexOf("="),
                        name = vars[i].slice(0, eqIndex),
                        value = vars[i].slice(eqIndex + 1);
                    if (name === variable) {
                        return value;
                    }
                }
                return null;
            }
            AppPlayer.getQueryVariable = getQueryVariable;
            ;
            function wrapModelReference(value, runContext, callerInfo, functions) {
                return executeModelSpecificAccessor(value, runContext, callerInfo, functions, function (specificModel, expression, negative, fullExpr) {
                    return wrapReferenceField(specificModel, expression, negative, fullExpr);
                });
            }
            AppPlayer.wrapModelReference = wrapModelReference;
            function wrapReferenceField(model, val, negative, fullExpr) {
                var getter,
                    setter,
                    writeNotifier = ko.observable(),
                    read,
                    descriptor;
                if (val) {
                    descriptor = Object.getOwnPropertyDescriptor(model, val);
                    getter = compileGetter(val, fullExpr);
                    if (!descriptor || descriptor.set || descriptor.writable) {
                        setter = AppPlayer.compileSetter(val);
                    }
                } else {
                    getter = function () {
                        return model;
                    };
                }
                read = function () {
                    ko.unwrap(writeNotifier);
                    return negative ? !getter(model) : getter(model);
                };
                return ko.computed(setter ? {
                    read: read,
                    write: function (value) {
                        setter(model, negative ? !value : value);
                        writeNotifier.valueHasMutated();
                    }
                } : { read: read });
            }
            ;
            function propertyVisitor(target, valueCallback, initialContext) {
                if (typeof target === "string") {
                    return target;
                }
                var context = initialContext || { getValueCallback: function (value, context) {
                        return propertyVisitor(value, valueCallback, context);
                    } },
                    isArray = Array.isArray(target),
                    result = isArray ? [] : {};
                context.path = context.path || "";
                $.each(target, function (name, value) {
                    context.name = name;
                    context.value = value;
                    context.isArray = isArray;
                    context.owner = result;
                    if (Array.isArray(value) || $.isPlainObject(value)) {
                        var oldPath = context.path;
                        context.path = context.path ? context.path + (context.isArray ? "[" + context.name + "]" : "." + context.name) : context.name;
                        result[name] = context.getValueCallback(value, context);
                        context.path = oldPath;
                    } else {
                        var newVal = valueCallback(context);
                        if (newVal !== undefined) {
                            result[name] = newVal;
                        }
                    }
                });
                return result;
            }
            AppPlayer.propertyVisitor = propertyVisitor;
            var BindingStringMaker = function () {
                function BindingStringMaker() {}
                BindingStringMaker.valueCallback = function (result, context) {
                    var value = context.value;
                    return context.name + ": " + value + ",";
                };
                BindingStringMaker.arrayValueCallback = function (result, context) {
                    return context.value + ",";
                };
                BindingStringMaker.makeString = function (model, isArray) {
                    if (isArray === void 0) {
                        isArray = false;
                    }
                    var result = "",
                        context = {
                        getValueCallback: function (value, context) {
                            if ($.isArray(value)) {
                                if (isArray) {
                                    result += "[" + BindingStringMaker.makeString(value, true) + "],";
                                } else {
                                    result += context.name + ": " + "[" + BindingStringMaker.makeString(value, true) + "],";
                                }
                            } else {
                                if (isArray) {
                                    result += "{" + BindingStringMaker.makeString(value, false) + "},";
                                } else {
                                    result += context.name + ": " + "{" + BindingStringMaker.makeString(value, false) + "},";
                                }
                            }
                        }
                    };
                    if (isArray) {
                        propertyVisitor(model, function (context) {
                            result += BindingStringMaker.arrayValueCallback(result, context);
                        }, context);
                    } else {
                        propertyVisitor(model, function (context) {
                            result += BindingStringMaker.valueCallback(result, context);
                        }, context);
                    }
                    return result.slice(0, -1);
                };
                return BindingStringMaker;
            }();
            AppPlayer.BindingStringMaker = BindingStringMaker;
            function shorten(value, length, ending) {
                if (ending === void 0) {
                    ending = "...";
                }
                if (ending.length > length) {
                    throw "Incorrect ending length";
                } else if (!value) {
                    return value;
                }
                return value.length > length ? value.substr(0, length - ending.length) + ending : value;
            }
            AppPlayer.shorten = shorten;
            function replaceAll(str, token, newToken) {
                return str.split(token).join(newToken);
            }
            AppPlayer.replaceAll = replaceAll;
            function startsWith(str, token) {
                if (token.length > str.length) {
                    return false;
                } else if (token.length === str.length) {
                    return token === str;
                } else {
                    return str.substr(0, token.length) === token;
                }
            }
            AppPlayer.startsWith = startsWith;
            function endsWith(str, token) {
                if (typeof str !== "string" || typeof token !== "string") {
                    return false;
                }
                if (token.length > str.length) {
                    return false;
                } else if (token.length === str.length) {
                    return token === str;
                } else {
                    if (token.length === 1) {
                        return str.charAt(str.length - 1) === token;
                    } else {
                        return str.substr(str.length - token.length, token.length) === token;
                    }
                }
            }
            AppPlayer.endsWith = endsWith;
            String.prototype.startsWith = function (token) {
                return startsWith(this, token);
            };
            String.prototype.endsWith = function (token) {
                return endsWith(this, token);
            };
            function findInArray(array, predicate) {
                var index = indexInArray(array, predicate);
                return index >= 0 ? array[index] : null;
            }
            AppPlayer.findInArray = findInArray;
            function indexInArray(array, predicate) {
                if (array) {
                    for (var i = 0; i < array.length; i++) {
                        if (predicate(array[i])) {
                            return i;
                        }
                    }
                }
                return -1;
            }
            AppPlayer.indexInArray = indexInArray;
            function clone(value) {
                var key, result;
                if (value instanceof Date) {
                    return new Date(value.getTime());
                } else if (value && value instanceof Object) {
                    result = Array.isArray(value) ? [] : {};
                    for (key in value) {
                        if (value.hasOwnProperty(key)) {
                            result[key] = clone(value[key]);
                        }
                    }
                    return result;
                } else {
                    return value;
                }
            }
            AppPlayer.clone = clone;
            function extract(config, field) {
                var target,
                    leftover = {};
                if (config) {
                    for (var currentField in config) {
                        if (currentField === field) {
                            target = config[currentField];
                        } else {
                            leftover[currentField] = config[currentField];
                        }
                    }
                }
                return {
                    target: target,
                    leftover: leftover
                };
            }
            AppPlayer.extract = extract;
            function extractMany(config, fields) {
                var target = {},
                    leftover = {};
                if (config) {
                    for (var currentField in config) {
                        if ($.inArray(currentField, fields) !== -1) {
                            target[currentField] = config[currentField];
                        } else {
                            leftover[currentField] = config[currentField];
                        }
                    }
                }
                return {
                    target: target,
                    leftover: leftover
                };
            }
            AppPlayer.extractMany = extractMany;
            function destruct(object, property) {
                var extraction = extract(object, property);
                return [extraction.target, extraction.leftover];
            }
            AppPlayer.destruct = destruct;
            function destructMany(object, properties) {
                var extraction = extractMany(object, properties);
                return [extraction.target, extraction.leftover];
            }
            AppPlayer.destructMany = destructMany;
            function remap(config, map, passthrough) {
                var result = {};
                if (config) {
                    for (var currentField in config) {
                        if (map[currentField]) {
                            result[map[currentField]] = config[currentField];
                        } else if (passthrough) {
                            result[currentField] = config[currentField];
                        }
                    }
                }
                return result;
            }
            AppPlayer.remap = remap;
            function remapWithValues(config, map, valuesMap, passthrough) {
                var result = remap(config, map, passthrough) || {};
                for (var key in result) {
                    var value = result[key];
                    result[key] = valuesMap[value] || config[key];
                }
                return result;
            }
            AppPlayer.remapWithValues = remapWithValues;
            var functionNameRegex = /^\s*function\s+([^\(\s]*)\s*/;
            function functionName(func) {
                if (typeof func !== "function") {
                    return undefined;
                }
                if (!func.hasOwnProperty("name")) {
                    var functionText = Function.prototype.toString.call(func),
                        match = functionNameRegex.exec(functionText);
                    Object.defineProperty(func, "name", {
                        enumerable: false,
                        writable: false,
                        value: match && match[1] || ""
                    });
                }
                return func["name"];
            }
            AppPlayer.functionName = functionName;
            var ISO8601_DATE_REGEX = /^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2})(?::([0-9]*)(\.[0-9]*)?)?(?:([+-])([0-9]{2}):?([0-9]{2}))?/;
            // If no timezone specified, transforms date in local time zone. This meets ECMAScript 6 specs and produce the same result as parseRfc2822Date
            function parseISO8601(isoString) {
                var m = ISO8601_DATE_REGEX.exec(isoString);
                var resultDate;
                if (m) {
                    // utcdate is milliseconds since the epoch
                    if (m[9] && m[10] || endsWith(isoString, "Z")) {
                        var utcdate = Date.UTC(parseInt(m[1], 10), parseInt(m[2], 10) - 1, // months are zero-offset (!)
                        parseInt(m[3], 10), parseInt(m[4], 10), parseInt(m[5], 10), // hh:mm
                        m[6] && parseInt(m[6], 10) || 0, // optional seconds
                        m[7] && parseFloat(m[7]) * 1000 || 0); // optional fraction
                        if (m[9] && m[10]) {
                            var offsetMinutes = parseInt(m[9], 10) * 60 + parseInt(m[10], 10);
                            utcdate += (m[8] === "+" ? -1 : +1) * offsetMinutes * 60000;
                        }
                        resultDate = new Date(utcdate);
                    } else {
                        resultDate = new Date(parseInt(m[1], 10), parseInt(m[2], 10) - 1, // months are zero-offset (!)
                        parseInt(m[3], 10), parseInt(m[4], 10), parseInt(m[5], 10), // hh:mm
                        m[6] && parseInt(m[6], 10) || 0, // optional seconds
                        m[7] && parseFloat(m[7]) * 1000 || 0);
                    }
                }
                return resultDate;
            }
            AppPlayer.parseISO8601 = parseISO8601;
            var RFC2822_DATE_REGEX = /\d{2}\s\w{3}\s\d{4}\s\d{2}:\d{2}:\d{2}\s.*$/;
            function transformISODates(obj) {
                if (!obj) {
                    return;
                }
                $.each(obj, function (key, value) {
                    if (value !== null && typeof value === "object") {
                        transformISODates(value);
                    } else if (typeof value === "string") {
                        if (ISO8601_DATE_REGEX.test(value) || RFC2822_DATE_REGEX.test(value)) {
                            obj[key] = parseDate(obj[key]);
                        }
                    }
                });
            }
            AppPlayer.transformISODates = transformISODates;
            ;
            function parseDate(date) {
                if (ISO8601_DATE_REGEX.test(date)) {
                    return parseISO8601(date);
                } else if (RFC2822_DATE_REGEX.test(date)) {
                    return new Date(Date.parse(date));
                }
                return undefined;
            }
            AppPlayer.parseDate = parseDate;
            var LocalStorageWrapper = function () {
                function LocalStorageWrapper(app) {
                    this.app = app;
                }
                LocalStorageWrapper.prototype.put = function (modelId, id, val) {
                    var key = this.getKey(modelId, id);
                    if (val === undefined || val === null) {
                        localStorage.removeItem(key);
                    } else {
                        localStorage.setItem(key, JSON.stringify(val));
                    }
                };
                LocalStorageWrapper.prototype.get = function (modelId, id) {
                    var key = this.getKey(modelId, id);
                    var val = localStorage.getItem(key);
                    return val ? JSON.parse(val) : undefined;
                };
                LocalStorageWrapper.prototype.getKey = function (modelId, id) {
                    return this.getAppUserKey() + (modelId || "global") + "-" + id;
                };
                LocalStorageWrapper.prototype.getAppUserKey = function () {
                    var appId = this.app.id ? this.app.id : "allapps";
                    return "xet-ls-" + appId + "-";
                };
                return LocalStorageWrapper;
            }();
            AppPlayer.LocalStorageWrapper = LocalStorageWrapper;
            function handleOpenURL(url) {
                var uriIndex = url.indexOf("://"),
                    paramsIndex = url.indexOf("?", uriIndex);
                var uri,
                    params = {};
                if (paramsIndex >= 0) {
                    uri = url.substring(uriIndex + 3, paramsIndex);
                    var paramParts = url.substring(paramsIndex + 1).split("&");
                    paramParts.forEach(function (part) {
                        var equalIndex = part.indexOf("="),
                            name,
                            value;
                        if (equalIndex < 0) {
                            params[part] = true;
                        } else {
                            name = part.substring(0, equalIndex);
                            value = part.substr(equalIndex + 1);
                            params[name] = value;
                        }
                    });
                } else {
                    uri = url.substr(uriIndex + 3);
                }
                // if app is open, redirect to the view provided
                // otherwise, save to a temporary variable
                if (window["app"] && window["app"].instance && window["app"].instance.dxapp) {
                    var app = window["app"].instance;
                    app.functions.navigateToView(uri, params, "master");
                } else {
                    window["xetHandleOpenURL"] = {
                        uri: uri,
                        params: params
                    };
                }
            }
            AppPlayer.handleOpenURL = handleOpenURL;
            function showActionPopover(target, items, showCancelButton, title) {
                var $div = $("<div/>");
                $div.appendTo($(document.body));
                $div.dxActionSheet({
                    dataSource: items,
                    visible: true,
                    title: title || "",
                    showTitle: !!title,
                    showCancelButton: showCancelButton,
                    usePopover: true,
                    target: target
                });
            }
            AppPlayer.showActionPopover = showActionPopover;
            function xmlToJs(node) {
                var data = {},
                    c,
                    cn,
                    attr;
                function appendValue(name, value) {
                    var prop = data[name];
                    if (prop) {
                        if (!Array.isArray(prop)) {
                            data[name] = prop = [prop];
                        }
                        prop.push(value);
                    } else {
                        data[name] = value;
                    }
                }
                function allChildrenAreValues(cn) {
                    var len = cn.childNodes.length,
                        i,
                        childNode;
                    if (len > 0) {
                        for (i = 0; i < len; i++) {
                            childNode = cn.childNodes[i];
                            if (childNode.nodeType !== 3 && childNode.nodeType !== 4) {
                                return false;
                            }
                        }
                        return true;
                    } else {
                        return false;
                    }
                }
                function getNodeValue(cn) {
                    var len = cn.childNodes.length,
                        nodeValue,
                        i;
                    if (len === 1) {
                        return cn.firstChild.nodeValue;
                    } else if (len > 0) {
                        nodeValue = "";
                        for (i = 0; i < len; i++) {
                            nodeValue += (cn.childNodes[i].nodeValue || "").trim();
                        }
                        return nodeValue;
                    } else {
                        return void 0;
                    }
                }
                // element attributes
                if (node.attributes) {
                    for (c = 0; attr = node.attributes[c]; c++) {
                        if (!startsWith(attr.name, "xmlns")) {
                            appendValue(attr.name, attr.value);
                        }
                    }
                }
                // child elements
                for (c = 0; cn = node.childNodes[c]; c++) {
                    if (cn.nodeType === 1) {
                        if (allChildrenAreValues(cn)) {
                            // text or CDATA node
                            appendValue(cn.nodeName, getNodeValue(cn));
                        } else {
                            // sub-object
                            appendValue(cn.nodeName, xmlToJs(cn));
                        }
                    }
                }
                return data;
            }
            AppPlayer.xmlToJs = xmlToJs;
            function escapeHtml(html) {
                var div = document.createElement("div");
                // IE converts null to string "null"
                div.innerHTML = ko.unwrap(html) || "";
                // Removes scripts from the html
                function removeByTagName(tagName) {
                    var scripts = div.getElementsByTagName(tagName);
                    var i = scripts.length;
                    while (i--) {
                        scripts[i].parentNode.removeChild(scripts[i]);
                    }
                }
                removeByTagName("script");
                removeByTagName("iframe");
                // Fixes hyperlink targets
                var hrefs = div.getElementsByTagName("a"),
                    i = hrefs.length;
                while (i--) {
                    hrefs[i].setAttribute("onClick", "AppPlayer.defaultLinkClickHandler(event)");
                }
                return div.innerHTML;
            }
            AppPlayer.escapeHtml = escapeHtml;
            function defaultLinkClickHandler() {
                var event = arguments[0].target ? arguments[0] : arguments[1],
                    href = event.target.href,
                    expr,
                    func;
                event.preventDefault();
                event.stopPropagation();
                if (!startsWith(href, "javascript:")) {
                    window.open(href, AppPlayer.LayoutHelper.linkTarget());
                } else {
                    expr = href.substr(href.indexOf("javascript:"));
                    func = new Function("event", expr);
                    func.apply(event.target, [event]);
                }
            }
            AppPlayer.defaultLinkClickHandler = defaultLinkClickHandler;
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Layout;
            (function (Layout) {
                "use strict";

                var Component = function () {
                    function Component() {
                        this.attachedProperties = [];
                    }
                    return Component;
                }();
                Layout.Component = Component;
                var Container = function (_super) {
                    __extends(Container, _super);
                    function Container() {
                        _super.apply(this, arguments);
                        this.components = [];
                    }
                    Container.prototype.layoutChildren = function () {};
                    return Container;
                }(Component);
                Layout.Container = Container;
                var Row = function (_super) {
                    __extends(Row, _super);
                    function Row() {
                        _super.apply(this, arguments);
                    }
                    Row.prototype.layoutChildren = function () {};
                    return Row;
                }(Container);
                Layout.Row = Row;
            })(Layout = AppPlayer.Layout || (AppPlayer.Layout = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Data;
            (function (Data) {
                "use strict";

                var dxdata = DevExpress.data;
                var DataSource = function () {
                    function DataSource() {}
                    DataSource.initDataObservables = function (srcData, observableSelectors) {
                        if (!$.isPlainObject(srcData)) {
                            return srcData;
                        }
                        var data = {};
                        var descriptors = {};
                        $.each(srcData, function (propertyName, value) {
                            var descriptor = AppPlayer.Model.getDescriptor(value, propertyName, observableSelectors);
                            descriptors[propertyName] = descriptor;
                        });
                        Object.defineProperties(data, descriptors);
                        return data;
                    };
                    DataSource.createDataSource = function (dataSourceConfig, context, stores, application) {
                        var _this = this;
                        var dataSourceContext = $.extend({}, context, {
                            callerType: "datasource initializer",
                            callerId: dataSourceConfig.id
                        }),
                            calculatedFieldContext = $.extend({}, context),
                            callerInfo = {
                            callerType: "calculated field",
                            callerId: ""
                        },
                            dsConfig = AppPlayer.Model.createLinkedModel(dataSourceConfig, dataSourceContext, callerInfo, application.functions);
                        // TODO: Vitik OData navigation property scenario. 
                        if (typeof dsConfig.store === "string") {
                            dsConfig.store = stores[dataSourceConfig.store];
                        }
                        var map;
                        if (dataSourceConfig.observables && dataSourceConfig.observables.length) {
                            map = AppPlayer.Utils.continueFunc(map, function (data) {
                                return _this.initDataObservables(data, dataSourceConfig.observables);
                            });
                        }
                        if (dataSourceConfig.calculatedFields && dataSourceConfig.calculatedFields.length) {
                            map = AppPlayer.Utils.continueFunc(map, function (data) {
                                AppPlayer.Model.createModelCore({ model: dataSourceConfig.calculatedFields }, application, $.extend({}, { $data: data }, calculatedFieldContext), callerInfo.callerId, data);
                                delete data.dispose;
                                return data;
                            });
                            if (dsConfig.store && typeof dsConfig.store.on === "function") {
                                dsConfig.store.on("updating", function (key, values) {
                                    dataSourceConfig.calculatedFields.forEach(function (field) {
                                        delete values[field.name];
                                    });
                                });
                                dsConfig.store.on("updated", function (key, values) {
                                    AppPlayer.Model.createModelCore({ model: dataSourceConfig.calculatedFields }, application, $.extend({}, { $data: values }, calculatedFieldContext), callerInfo.callerId, values);
                                    delete values.dispose;
                                });
                            }
                        }
                        ;
                        if (map) {
                            dsConfig["map"] = map;
                        }
                        var dataSource = new dxdata.DataSource(dsConfig);
                        dataSource.on("customizeLoadResult", function (result) {
                            if (result.data && !Array.isArray(result.data)) {
                                var stringData = JSON.stringify(result.data),
                                    dataPreview = AppPlayer.shorten(stringData, 20),
                                    message = "The " + dataSourceConfig.id + " data source returned \"" + dataPreview + "\", whereas an array was expected. Data binding may be performed incorrectly.";
                                AppPlayer.Utils.showError(message);
                            }
                        });
                        // DataSource won't subscribe to observables. Do this for him.
                        ko.computed(function () {
                            return dsConfig.filter;
                        }).subscribe(function (filter) {
                            dataSource.filter(filter);
                            if (dataSource["_xetLoadedAtLeastOnce"]) {
                                dataSource.load();
                            }
                        });
                        ko.computed(function () {
                            return dsConfig.sort;
                        }).subscribe(function (sort) {
                            dataSource.sort(sort);
                            if (dataSource["_xetLoadedAtLeastOnce"]) {
                                dataSource.load();
                            }
                        });
                        var originalLoad = dataSource.load.bind(dataSource);
                        dataSource.load = function () {
                            dataSource["_xetLoadedAtLeastOnce"] = true;
                            return originalLoad();
                        };
                        if (dsConfig.loadOptions) {
                            dataSource.on("customizeStoreLoadOptions", function (loadOptions) {
                                loadOptions.storeLoadOptions.urlOverride = dsConfig.loadOptions.url;
                            });
                        }
                        dataSource["_calculatedFields"] = dataSourceConfig.calculatedFields;
                        dataSource["_refreshOnViewShown"] = dataSourceConfig.refreshOnViewShown;
                        dataSource["_monitor"] = dataSourceConfig.monitor;
                        return dataSource;
                    };
                    return DataSource;
                }();
                Data.DataSource = DataSource;
            })(Data = AppPlayer.Data || (AppPlayer.Data = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Logic;
            (function (Logic) {
                "use strict";

                var dxdialog = DevExpress.ui.dialog;
                (function (Flow) {
                    Flow[Flow["Return"] = 0] = "Return";
                    Flow[Flow["Break"] = 1] = "Break";
                    Flow[Flow["Continue"] = 2] = "Continue";
                })(Logic.Flow || (Logic.Flow = {}));
                var Flow = Logic.Flow;
                var LogicError = function (_super) {
                    __extends(LogicError, _super);
                    function LogicError(message, operation, source, callerInfo) {
                        _super.call(this);
                        this.message = message;
                        this.operation = operation;
                        this.source = source;
                        this.callerInfo = callerInfo;
                    }
                    return LogicError;
                }(Error);
                Logic.LogicError = LogicError;
                var DataLogicError = function (_super) {
                    __extends(DataLogicError, _super);
                    function DataLogicError(data, operation, source, callerInfo) {
                        _super.call(this);
                        this.data = data;
                        this.operation = operation;
                        this.source = source;
                        this.callerInfo = callerInfo;
                        this.message = data.responseText || data.message || "Unknown data error";
                    }
                    return DataLogicError;
                }(Error);
                Logic.DataLogicError = DataLogicError;
                var Operation = function () {
                    function Operation() {}
                    Operation.eval = function (expr, context) {
                        var varNames = [],
                            varValues = [];
                        $.each(context, function (name, value) {
                            varNames.push(name);
                            varValues.push(value);
                        });
                        varNames.push("return (" + (expr.startsWith("=") ? expr.substr(1) : expr) + ")");
                        var fn = Function.apply(null, varNames);
                        return fn.apply(null, varValues);
                    };
                    Operation.run = function (calls, variables, functions) {
                        if (!calls || calls.length === 0) {
                            return Logic.trivialPromise();
                        }
                        var callIndex = 0;
                        function successHandler(result) {
                            if (callIndex === calls.length - 1 || result && result.flow in Flow) {
                                return Logic.trivialPromise(result);
                            }
                            callIndex++;
                            return runCurrentOperation();
                        }
                        function errorHandler(error) {
                            var nextError;
                            if (error instanceof Error) {
                                nextError = error;
                            } else if (error.dataError) {
                                nextError = new DataLogicError(error.data, error.op || calls[callIndex]);
                            } else {
                                nextError = new LogicError(error.data || error, error.op || calls[callIndex]);
                            }
                            return Logic.rejectPromise(nextError);
                        }
                        function runCurrentOperation() {
                            var currentOperation = calls[callIndex];
                            //console.log("Current operation: ", currentOperation);
                            return currentOperation.run(variables, functions).then(successHandler, errorHandler);
                        }
                        try {
                            return runCurrentOperation();
                        } catch (e) {
                            return Logic.rejectPromise(new LogicError(e.message || e, calls[callIndex]));
                        }
                    };
                    //caption: string;  // TODO: Ivan
                    //autoGenerateCaption: boolean; // TODO: Ivan
                    Operation.prototype.run = function (variables, functions) {
                        throw Error("Not implemented");
                    };
                    Operation.fromJson = function (json) {
                        if (json instanceof Operation) {
                            return json;
                        } else {
                            var result = Operation.create(json._type);
                            Operation.restoreProperties(json, result);
                            return result;
                        }
                    };
                    Operation.create = function (type) {
                        return new AppPlayer.Logic[type]();
                    };
                    Operation.restoreProperties = function (json, result) {
                        $.each(json, function (name, value) {
                            if (name === "_type") {
                                return;
                            }
                            if (Array.isArray(value)) {
                                result[name] = value.map(function (element) {
                                    if (typeof element === "object" && element && element._type) {
                                        return Operation.fromJson(element);
                                    } else {
                                        return Operation.restoreProperties(element, Array.isArray(element) ? [] : {});
                                    }
                                });
                            } else if (value && typeof value === "object") {
                                if (value && value._type) {
                                    result[name] = Operation.fromJson(value);
                                } else {
                                    result[name] = Operation.restoreProperties(value, {});
                                }
                            } else {
                                result[name] = value;
                            }
                        });
                        return result;
                    };
                    Operation.prototype.toString = function () {
                        return AppPlayer.functionName(this.constructor);
                    };
                    return Operation;
                }();
                Logic.Operation = Operation;
                var Event = function (_super) {
                    __extends(Event, _super);
                    function Event(flow, returnValue) {
                        _super.call(this);
                        this.returnValue = null;
                        this.returnExpr = "";
                        if (flow in Flow) {
                            this.flow = flow;
                            this.returnValue = returnValue;
                        } else if (flow) {
                            var param = flow;
                            if (typeof param.flow !== "undefined") {
                                this.flow = param.flow;
                            }
                            if (typeof param.returnValue !== "undefined") {
                                this.returnValue = param.returnValue;
                            }
                            if (typeof param.returnExpr !== "undefined") {
                                this.returnExpr = param.returnExpr;
                            }
                        }
                    }
                    Event.prototype.run = function (variables, functions) {
                        var result = {
                            flow: this.flow,
                            value: undefined
                        };
                        if (this.flow === Flow.Return) {
                            if (this.returnExpr) {
                                result.value = variables.getValue(this.returnExpr);
                            } else {
                                result.value = this.returnValue;
                            }
                        }
                        return Logic.trivialPromise(result);
                    };
                    return Event;
                }(Operation);
                Logic.Event = Event;
                var SetValue = function (_super) {
                    __extends(SetValue, _super);
                    function SetValue(params) {
                        var _this = this;
                        _super.call(this);
                        this.valueExpr = "";
                        this.leftExpr = "";
                        if (params) {
                            $.each(params, function (name, value) {
                                _this[name] = value || _this[name];
                            });
                        }
                    }
                    SetValue.prototype.run = function (variables, functions) {
                        var pathExpr;
                        if (this.leftExpr) {
                            pathExpr = this.leftExpr;
                        } else {
                            if (this.variableName) {
                                console.warn("SetValue: variableName and pathExpr are obsolete. Use leftExpr instead");
                                pathExpr = this.pathExpr ? this.variableName + "[" + this.pathExpr + "]" : this.variableName;
                            } else {
                                return Logic.rejectPromise("SetValue: leftExpr must be defined");
                            }
                        }
                        if (this.valueExpr === "") {
                            return Logic.rejectPromise("SetValue: valueExpr must be defined");
                        }
                        var value = variables.getValue(this.valueExpr);
                        variables.setValue(pathExpr, value);
                        return Logic.trivialPromise();
                    };
                    return SetValue;
                }(Operation);
                Logic.SetValue = SetValue;
                var Create = function (_super) {
                    __extends(Create, _super);
                    function Create(params) {
                        _super.call(this);
                        this.variableName = "";
                        this.storeExpr = "";
                        this.storeId = "";
                        if (params) {
                            this.variableName = params.variableName;
                            this.storeId = params.storeId;
                        }
                    }
                    Create.prototype.run = function (variables, functions) {
                        var storeId = !!this.storeExpr ? variables.getValue(this.storeExpr) : this.storeId,
                            dataStoreConfig = functions.getDataStoreConfig(storeId),
                            result = {};
                        if (dataStoreConfig.fields) {
                            dataStoreConfig.fields.forEach(function (field) {
                                result[field.name] = undefined;
                            });
                        }
                        variables.add(this.variableName, result);
                        return Logic.trivialPromise();
                    };
                    return Create;
                }(Operation);
                Logic.Create = Create;
                var AddToList = function (_super) {
                    __extends(AddToList, _super);
                    function AddToList(params) {
                        _super.call(this);
                        this.variableName = "";
                        this.value = null;
                        this.expression = "";
                        if (params) {
                            this.variableName = params.variableName;
                            if (params.expr) {
                                this.expression = params.expr;
                            } else {
                                this.value = params.value;
                            }
                        }
                    }
                    AddToList.prototype.run = function (variables, functions) {
                        var list = variables.getValue(this.variableName),
                            value = this.expression ? variables.getValue(this.expression) : this.value;
                        list.push(value);
                        return Logic.trivialPromise();
                    };
                    return AddToList;
                }(Operation);
                Logic.AddToList = AddToList;
                var InsertToList = function (_super) {
                    __extends(InsertToList, _super);
                    function InsertToList(params) {
                        _super.call(this);
                        this.variableName = "";
                        this.valueExpr = "";
                        this.indexExpr = "";
                        $.extend(this, params);
                    }
                    InsertToList.prototype.run = function (variables, functions) {
                        if (!this.variableName) {
                            return Logic.rejectPromise("invalid variable name");
                        }
                        if (!this.valueExpr) {
                            return Logic.rejectPromise("invalid value expression");
                        }
                        var list = variables.getValue(this.variableName);
                        if (!$.isArray(list)) {
                            return Logic.rejectPromise("variable should be array");
                        }
                        var value = variables.getValue(this.valueExpr),
                            index = this.indexExpr ? variables.getValue(this.indexExpr) : undefined;
                        if (index >= 0) {
                            list.splice(index, 0, value);
                            return Logic.trivialPromise();
                        } else if (index === undefined) {
                            list.push(value);
                            return Logic.trivialPromise();
                        } else {
                            return Logic.rejectPromise("InsertToList: index should be 0 or greater than 0");
                        }
                    };
                    return InsertToList;
                }(Operation);
                Logic.InsertToList = InsertToList;
                var IndexInList = function (_super) {
                    __extends(IndexInList, _super);
                    function IndexInList(params) {
                        var _this = this;
                        _super.call(this);
                        if (params) {
                            $.each(params, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    IndexInList.prototype.run = function (variables, functions) {
                        var _this = this;
                        var list = variables.getValue(this.listExpr);
                        if (!Array.isArray(list)) {
                            return Logic.rejectPromise("listExpr must be evaluated to list");
                        }
                        if (!this.predicateExpr) {
                            return Logic.rejectPromise("predicate expression is not defined");
                        }
                        if (!variables.isDefined(this.resultVariableExpr)) {
                            return Logic.rejectPromise("invalid result variable expression");
                        }
                        var innerContext = variables.clone();
                        innerContext.add("$item");
                        var index = AppPlayer.indexInArray(list, function ($item) {
                            innerContext.setValue("$item", $item);
                            return innerContext.getValue(_this.predicateExpr);
                        });
                        variables.setValue(this.resultVariableExpr, index);
                        return Logic.trivialPromise();
                    };
                    return IndexInList;
                }(Operation);
                Logic.IndexInList = IndexInList;
                var FindInList = function (_super) {
                    __extends(FindInList, _super);
                    function FindInList(params) {
                        var _this = this;
                        _super.call(this);
                        if (params) {
                            $.each(params, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    FindInList.prototype.run = function (variables, functions) {
                        var _this = this;
                        var list = variables.getValue(this.listExpr);
                        if (!Array.isArray(list)) {
                            return Logic.rejectPromise("listExpr must be evaluated to list");
                        }
                        if (!this.predicateExpr) {
                            return Logic.rejectPromise("predicate expression is not defined");
                        }
                        if (!variables.isDefined(this.resultVariableExpr)) {
                            return Logic.rejectPromise("invalid result variable expression");
                        }
                        var innerContext = variables.clone();
                        innerContext.add("$item");
                        var item = AppPlayer.findInArray(list, function ($item) {
                            innerContext.setValue("$item", $item);
                            return innerContext.getValue(_this.predicateExpr);
                        });
                        variables.setValue(this.resultVariableExpr, item);
                        return Logic.trivialPromise();
                    };
                    return FindInList;
                }(Operation);
                Logic.FindInList = FindInList;
                var RemoveFromListByValue = function (_super) {
                    __extends(RemoveFromListByValue, _super);
                    function RemoveFromListByValue(params) {
                        var _this = this;
                        _super.call(this);
                        if (params) {
                            $.each(params, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    RemoveFromListByValue.prototype.run = function (variables, functions) {
                        this.processObsoleteOptions();
                        var list = variables.getValue(this.listExpr);
                        if (!Array.isArray(list)) {
                            return Logic.rejectPromise("listExpr must be evaluated to list");
                        }
                        var value = variables.getValue(this.valueExpr),
                            index = list.indexOf(value);
                        if (index >= 0) {
                            list.splice(index, 1);
                        }
                        return Logic.trivialPromise();
                    };
                    RemoveFromListByValue.prototype.processObsoleteOptions = function () {
                        if (this.listExpr === undefined && this.variableName !== undefined) {
                            console.warn("variableName is obsolete. Use listExpr instead");
                            this.listExpr = this.variableName;
                        }
                    };
                    return RemoveFromListByValue;
                }(Operation);
                Logic.RemoveFromListByValue = RemoveFromListByValue;
                var RemoveFromListByIndex = function (_super) {
                    __extends(RemoveFromListByIndex, _super);
                    function RemoveFromListByIndex(params) {
                        var _this = this;
                        _super.call(this);
                        if (params) {
                            $.each(params, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    RemoveFromListByIndex.prototype.run = function (variables, functions) {
                        this.processObsoleteOptions();
                        var list = variables.getValue(this.listExpr);
                        if (!Array.isArray(list)) {
                            return Logic.rejectPromise("listExpr must be evaluated to list");
                        }
                        var index = variables.getValue(this.indexExpr);
                        if (index < 0) {
                            return Logic.rejectPromise("indexExpr must be evaluated to positive number");
                        }
                        list.splice(this.index, 1);
                        return Logic.trivialPromise();
                    };
                    RemoveFromListByIndex.prototype.processObsoleteOptions = function () {
                        if (this.listExpr === undefined && this.variableName !== undefined) {
                            console.warn("variableName is obsolete. Use listExpr instead");
                            this.listExpr = this.variableName;
                        }
                        if (this.indexExpr === undefined && this.index !== undefined) {
                            console.warn("index is obsolete. Use indexExpr instead");
                            this.indexExpr = this.index.toString();
                        }
                    };
                    return RemoveFromListByIndex;
                }(Operation);
                Logic.RemoveFromListByIndex = RemoveFromListByIndex;
                var CountList = function (_super) {
                    __extends(CountList, _super);
                    function CountList(params) {
                        _super.call(this);
                        this.expr = "";
                        this.resultVariableName = "";
                        if (params) {
                            this.expr = params.expr;
                            this.resultVariableName = params.resultVariableName;
                        }
                    }
                    CountList.prototype.run = function (variables, functions) {
                        var list = variables.getValue(this.expr),
                            len = Array.isArray(list) ? list.length : Object.keys(list).length;
                        variables.setValue(this.resultVariableName, len);
                        return Logic.trivialPromise();
                    };
                    return CountList;
                }(Operation);
                Logic.CountList = CountList;
                (function (AggregateType) {
                    AggregateType[AggregateType["Min"] = 0] = "Min";
                    AggregateType[AggregateType["Max"] = 1] = "Max";
                    AggregateType[AggregateType["Sum"] = 2] = "Sum";
                    AggregateType[AggregateType["Average"] = 3] = "Average";
                })(Logic.AggregateType || (Logic.AggregateType = {}));
                var AggregateType = Logic.AggregateType;
                var AggregateList = function (_super) {
                    __extends(AggregateList, _super);
                    function AggregateList(params) {
                        var _this = this;
                        _super.call(this);
                        this.type = AggregateType.Sum;
                        this.variableName = "";
                        this.resultVariableName = "";
                        this.propertyName = "";
                        this.seed = 0;
                        if (params) {
                            $.each(params, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    AggregateList.prototype.run = function (variables, functions) {
                        var _this = this;
                        var aggregator,
                            resultSelector,
                            valueSelector = function (item) {
                            return _this.propertyName ? item[_this.propertyName] : item;
                        },
                            accumulator,
                            list = variables.getValue(this.variableName);
                        if (!variables.isDefined(this.resultVariableName)) {
                            return Logic.rejectPromise("invalid resultVariableName");
                        }
                        if (list.length === 0) {
                            variables.setValue(this.resultVariableName, null);
                            return Logic.trivialPromise();
                        }
                        switch (this.type) {
                            case AggregateType.Min:
                                aggregator = function (accumulator, value) {
                                    return value < accumulator ? value : accumulator;
                                };
                                resultSelector = function (accumulator, list) {
                                    return accumulator;
                                };
                                break;
                            case AggregateType.Max:
                                aggregator = function (accumulator, value) {
                                    return value > accumulator ? value : accumulator;
                                };
                                resultSelector = function (accumulator, list) {
                                    return accumulator;
                                };
                                break;
                            case AggregateType.Sum:
                                aggregator = function (accumulator, value) {
                                    return accumulator + value;
                                };
                                resultSelector = function (accumulator, list) {
                                    return accumulator;
                                };
                                break;
                            case AggregateType.Average:
                                aggregator = function (accumulator, value) {
                                    return accumulator + value;
                                };
                                resultSelector = function (accumulator, list) {
                                    return accumulator / list.length;
                                };
                                break;
                            default:
                                return Logic.rejectPromise("invalid aggregate function");
                        }
                        accumulator = this.seed;
                        list.forEach(function (item) {
                            accumulator = aggregator(accumulator, valueSelector(item));
                        });
                        variables.setValue(this.resultVariableName, resultSelector(accumulator, list));
                        return Logic.trivialPromise();
                    };
                    return AggregateList;
                }(Operation);
                Logic.AggregateList = AggregateList;
                var SortList = function (_super) {
                    __extends(SortList, _super);
                    function SortList(params) {
                        var _this = this;
                        _super.call(this);
                        this.variableName = "";
                        this.desc = false;
                        this.propertyName = "";
                        if (params) {
                            $.each(params, function (name, val) {
                                return _this[name] = val;
                            });
                        }
                    }
                    SortList.prototype.run = function (variables, functions) {
                        var _this = this;
                        var list = variables.getValue(this.variableName),
                            compare;
                        if (!this.propertyName) {
                            if (this.desc) {
                                compare = function (a, b) {
                                    return b - a;
                                };
                            }
                        } else {
                            if (this.desc) {
                                compare = function (a, b) {
                                    return b[_this.propertyName] - a[_this.propertyName];
                                };
                            } else {
                                compare = function (a, b) {
                                    return a[_this.propertyName] - b[_this.propertyName];
                                };
                            }
                        }
                        list.sort(compare);
                        return Logic.trivialPromise();
                    };
                    return SortList;
                }(Operation);
                Logic.SortList = SortList;
                var Loop = function (_super) {
                    __extends(Loop, _super);
                    function Loop(params) {
                        var _this = this;
                        _super.call(this);
                        this.valueExpr = "";
                        this.indexName = "$loopIndex";
                        this.valueName = "$loopValue";
                        this.calls = [];
                        if (params) {
                            $.each(params, function (name, value) {
                                if (value !== undefined) {
                                    _this[name] = value;
                                }
                            });
                        }
                    }
                    Loop.prototype.run = function (variables, functions) {
                        var _this = this;
                        var value = variables.getValue(this.valueExpr);
                        if (typeof value !== "object") {
                            return Logic.rejectPromise("Passed value should be array or object");
                        }
                        var isArray = Array.isArray(value),
                            objectKeys = isArray ? null : Object.keys(value),
                            savedValue = $.extend(isArray ? [] : {}, value),
                            index = 0,
                            length = isArray ? value.length : objectKeys.length;
                        if (length === 0) {
                            return Logic.trivialPromise();
                        }
                        var localVars = variables.clone();
                        localVars.add(this.indexName);
                        localVars.add(this.valueName);
                        var d = $.Deferred(),
                            loopFn = function () {
                            if (index >= length) {
                                d.resolve();
                                return;
                            }
                            var currentIndexValue = isArray ? index : objectKeys[index];
                            localVars.setValue(_this.indexName, currentIndexValue);
                            localVars.setValue(_this.valueName, savedValue[currentIndexValue]);
                            Operation.run(_this.calls, localVars, functions).done(function (result) {
                                if (result !== undefined) {
                                    if (result.flow === Flow.Break) {
                                        d.resolve();
                                        return;
                                    } else if (result.flow === Flow.Return) {
                                        d.resolve(result);
                                        return;
                                    }
                                }
                                index++;
                                loopFn();
                            }).fail(function (error) {
                                d.reject(error);
                            });
                        };
                        loopFn();
                        return d.promise();
                    };
                    return Loop;
                }(Operation);
                Logic.Loop = Loop;
                var defaultForLoopParameters = {
                    indexName: "$loopIndex",
                    startIndexIncluded: 0,
                    endIndexExcluded: 0,
                    calls: []
                };
                var ForLoop = function (_super) {
                    __extends(ForLoop, _super);
                    function ForLoop(params) {
                        _super.call(this);
                        $.extend(this, defaultForLoopParameters, params);
                    }
                    ForLoop.prototype.run = function (variables, functions) {
                        var _this = this;
                        var startIndexIncluded = parseInt(variables.getValue(this.startIndexIncluded), 10),
                            endIndexExcluded = parseInt(variables.getValue(this.endIndexExcluded), 10),
                            step = startIndexIncluded < endIndexExcluded ? 1 : -1,
                            localVars = variables.clone();
                        localVars.add(this.indexName);
                        var d = $.Deferred(),
                            index = startIndexIncluded,
                            loopFn = function () {
                            if (index === endIndexExcluded) {
                                d.resolve();
                                return;
                            }
                            localVars.setValue(_this.indexName, index);
                            Operation.run(_this.calls, localVars, functions).done(function (result) {
                                if (result !== undefined) {
                                    if (result.flow === Flow.Break) {
                                        d.resolve();
                                        return;
                                    } else if (result.flow === Flow.Return) {
                                        d.resolve(result);
                                        return;
                                    }
                                }
                                index += step;
                                loopFn();
                            }).fail(function (error) {
                                d.reject(error);
                            });
                        };
                        loopFn();
                        return d.promise();
                    };
                    return ForLoop;
                }(Operation);
                Logic.ForLoop = ForLoop;
                var Switch = function (_super) {
                    __extends(Switch, _super);
                    function Switch(param) {
                        _super.call(this);
                        this.expr = "";
                        this.cases = [];
                        this.otherwise = [];
                        if (param) {
                            this.expr = param.expr || this.expr;
                            this.cases = param.cases || this.cases;
                            this.otherwise = param.otherwise || this.otherwise;
                        }
                    }
                    Switch.prototype.run = function (variables, functions) {
                        var _this = this;
                        var exprValue = variables.getValue(this.expr),
                            result = null;
                        this.cases.some(function (switchCase) {
                            var action = _this.getOperatorAction(switchCase.operator || "=="),
                                caseValue = variables.getValue(switchCase.valueExpr);
                            if (action(exprValue, caseValue)) {
                                result = Operation.run(switchCase.calls, variables, functions);
                                return true;
                            }
                            return false;
                        });
                        if (!result && this.otherwise.length) {
                            result = Operation.run(this.otherwise, variables, functions);
                        }
                        return result || Logic.trivialPromise();
                    };
                    Switch.prototype.getOperatorAction = function (operator) {
                        return Switch.operators.filter(function (item) {
                            return item.value === operator;
                        })[0].action;
                    };
                    Switch.operators = [{ value: "==", title: "== (equals)", isBinary: true, action: function (first, second) {
                            return first === second;
                        } }, { value: "!=", title: "!= (not equals)", isBinary: true, action: function (first, second) {
                            return first !== second;
                        } }, { value: ">=", title: ">=", isBinary: true, action: function (first, second) {
                            return first >= second;
                        } }, { value: ">", title: ">", isBinary: true, action: function (first, second) {
                            return first > second;
                        } }, { value: "<=", title: "<=", isBinary: true, action: function (first, second) {
                            return first <= second;
                        } }, { value: "<", title: "<", isBinary: true, action: function (first, second) {
                            return first < second;
                        } }, { value: "is nothing", title: "is nothing", isBinary: false, action: function (first, second) {
                            return !first;
                        } }, { value: "is not nothing", title: "is not nothing", isBinary: false, action: function (first, second) {
                            return !!first;
                        } }];
                    return Switch;
                }(Operation);
                Logic.Switch = Switch;
                (function (RetrieveType) {
                    RetrieveType[RetrieveType["First"] = 0] = "First";
                    RetrieveType[RetrieveType["All"] = 1] = "All";
                })(Logic.RetrieveType || (Logic.RetrieveType = {}));
                var RetrieveType = Logic.RetrieveType;
                var RetrieveObject = function (_super) {
                    __extends(RetrieveObject, _super);
                    // TODO: Ivan filters
                    function RetrieveObject(param) {
                        _super.call(this);
                        this.type = RetrieveType.All;
                        this.storeId = "";
                        this.variableName = "";
                        this.errorVariableName = "";
                        if (param) {
                            this.type = param.type;
                            this.variableName = param.variableName;
                            this.storeId = param.storeId;
                        }
                    }
                    RetrieveObject.prototype.run = function (variables, functions) {
                        var _this = this;
                        var d = $.Deferred(),
                            errorHandler = function (error) {
                            if (_this.errorVariableName) {
                                variables.setValue(_this.errorVariableName, error);
                                d.resolve();
                            } else {
                                d.reject({
                                    op: _this,
                                    data: error,
                                    dataError: true
                                });
                            }
                        };
                        switch (this.type) {
                            case RetrieveType.All:
                                functions.load(this.storeId).then(function (values) {
                                    variables.setValue(_this.variableName, values);
                                    d.resolve();
                                }, errorHandler);
                                break;
                            case RetrieveType.First:
                            default:
                                functions.load(this.storeId, { take: 1 }).then(function (values) {
                                    variables.setValue(_this.variableName, values && values.length > 0 ? values[0] : null);
                                    d.resolve();
                                }, errorHandler);
                                break;
                        }
                        return d.promise();
                    };
                    return RetrieveObject;
                }(Operation);
                Logic.RetrieveObject = RetrieveObject;
                var ResetObject = function (_super) {
                    __extends(ResetObject, _super);
                    function ResetObject(param) {
                        _super.call(this);
                        this.variableName = "";
                        this.errorVariableName = "";
                        this.properties = [];
                        if (param) {
                            if (param.variableName) {
                                this.variableName = param.variableName;
                            }
                            if (param.properties) {
                                this.properties = param.properties;
                            }
                        }
                    }
                    ResetObject.prototype.run = function (variables, functions) {
                        var _this = this;
                        var d = $.Deferred(),
                            variable = variables.get(this.variableName),
                            storeId = variable.type,
                            key = functions.keyOf(storeId, variable);
                        if (!key) {
                            return Logic.rejectPromise({
                                op: this,
                                data: "Object in '" + this.variableName + "' doesn't have a key. Probably, is has not been saved to a store.",
                                dataError: true
                            });
                        } else {
                            return functions.byKey(storeId, key).then(function (dbObject) {
                                if (_this.properties && _this.properties.length > 0) {
                                    _this.properties.forEach(function (propertyName) {
                                        variable.value[propertyName] = dbObject[propertyName];
                                    });
                                } else {
                                    variables.setValue(_this.variableName, dbObject);
                                }
                                d.resolve();
                            }, function (error) {
                                if (_this.errorVariableName) {
                                    variables.setValue(_this.errorVariableName, error);
                                    d.resolve();
                                } else {
                                    d.reject({
                                        op: _this,
                                        data: error,
                                        dataError: true
                                    });
                                }
                            });
                        }
                    };
                    return ResetObject;
                }(Operation);
                Logic.ResetObject = ResetObject;
                var CloneObject = function (_super) {
                    __extends(CloneObject, _super);
                    function CloneObject(param) {
                        _super.call(this);
                        this.variableName = "";
                        this.resultVariableName = "";
                        if (param) {
                            $.extend(this, param);
                        }
                    }
                    CloneObject.prototype.run = function (variables, functions) {
                        var value = variables.getValue(this.variableName),
                            target = Array.isArray(value) ? [] : {};
                        variables.setValue(this.resultVariableName, $.extend(target, value));
                        return Logic.trivialPromise();
                    };
                    return CloneObject;
                }(Operation);
                Logic.CloneObject = CloneObject;
                var NavigateToView = function (_super) {
                    __extends(NavigateToView, _super);
                    function NavigateToView(params) {
                        var _this = this;
                        _super.call(this);
                        this.viewId = "";
                        this.viewIdExpr = "";
                        this.viewParametersExpr = "";
                        if (params) {
                            $.each(params, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    NavigateToView.prototype.run = function (variables, functions) {
                        var viewId = this.viewIdExpr ? variables.getValue(this.viewIdExpr) : this.viewId,
                            parameters = {},
                            currentPane = variables.getValueOrDefault("$model.pane");
                        if (this.viewParameters) {
                            this.viewParameters.forEach(function (viewParameter) {
                                var value = variables.getValue(viewParameter.valueExpr);
                                parameters[viewParameter.name] = value;
                            });
                        } else if (this.viewParametersExpr) {
                            parameters = variables.getValue(this.viewParametersExpr);
                        }
                        functions.navigateToView(viewId, parameters, currentPane);
                        return Logic.trivialPromise();
                    };
                    return NavigateToView;
                }(Operation);
                Logic.NavigateToView = NavigateToView;
                var Save = function (_super) {
                    __extends(Save, _super);
                    function Save(param) {
                        var _this = this;
                        _super.call(this);
                        this.objectExpr = "";
                        this.storeId = "";
                        this.keyExpr = "";
                        this.errorVariableName = "";
                        if (param) {
                            $.each(param, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    Save.prototype.run = function (variables, functions) {
                        var _this = this;
                        var d = $.Deferred(),
                            object = variables.getValue(this.objectExpr),
                            key = this.keyExpr ? variables.getValue(this.keyExpr) : undefined;
                        functions.save(object, this.storeId, key).then(function (result) {
                            return d.resolve(result);
                        }, function (error) {
                            if (_this.errorVariableName) {
                                variables.setValue(_this.errorVariableName, error);
                                d.resolve();
                            } else {
                                d.reject({
                                    op: _this,
                                    data: error,
                                    dataError: true
                                });
                            }
                        });
                        return d.promise();
                    };
                    return Save;
                }(Operation);
                Logic.Save = Save;
                var Insert = function (_super) {
                    __extends(Insert, _super);
                    function Insert(param) {
                        var _this = this;
                        _super.call(this);
                        this.objectExpr = "";
                        this.storeId = "";
                        this.storeExpr = "";
                        this.errorVariableName = "";
                        if (param) {
                            $.each(param, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    Insert.prototype.run = function (variables, functions) {
                        var _this = this;
                        var d = $.Deferred(),
                            object = variables.getValue(this.objectExpr),
                            storeId = !!this.storeExpr ? variables.getValue(this.storeExpr) : this.storeId;
                        functions.insert(object, storeId).then(function (result) {
                            return d.resolve(result);
                        }, function (error) {
                            if (_this.errorVariableName) {
                                variables.setValue(_this.errorVariableName, error);
                                d.resolve();
                            } else {
                                d.reject({
                                    op: _this,
                                    data: error,
                                    dataError: true
                                });
                            }
                        });
                        return d.promise();
                    };
                    return Insert;
                }(Operation);
                Logic.Insert = Insert;
                var Refresh = function (_super) {
                    __extends(Refresh, _super);
                    function Refresh(param) {
                        var _this = this;
                        _super.call(this);
                        this.storeId = "";
                        this.storeExpr = "";
                        if (param) {
                            $.each(param, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    Refresh.prototype.run = function (variables, functions) {
                        var storeId = !!this.storeExpr ? variables.getValue(this.storeExpr) : this.storeId;
                        functions.refresh(storeId);
                        return Logic.trivialPromise();
                    };
                    return Refresh;
                }(Operation);
                Logic.Refresh = Refresh;
                var SendRequest = function (_super) {
                    __extends(SendRequest, _super);
                    function SendRequest(param) {
                        var _this = this;
                        _super.call(this);
                        this.url = null;
                        this.method = "get";
                        this.dataExpr = null;
                        this.variableName = null;
                        this.errorVariableName = null;
                        this.dataType = null;
                        this.cacheResponse = false;
                        this.headersExpr = null;
                        this.timeout = null;
                        this.options = null;
                        this.withCredentials = false;
                        if (param) {
                            $.each(param, function (name, value) {
                                _this[name] = value;
                            });
                        }
                    }
                    SendRequest.prototype.run = function (variables, functions) {
                        var _this = this;
                        if (!this.url) {
                            return Logic.rejectPromise({
                                op: this,
                                data: "no URL provided",
                                dataError: true
                            });
                        }
                        functions["busy"]();
                        var options = $.extend({}, {
                            url: variables.evalAutoExpression(this.url),
                            data: this.dataExpr ? variables.getValue(this.dataExpr) : undefined,
                            dataType: this.dataType,
                            type: this.method ? this.method.toUpperCase() : "POST",
                            cache: this.cacheResponse,
                            headers: this.headersExpr ? variables.getValue(this.headersExpr) : {},
                            timeout: $.isNumeric(this.timeout) ? this.timeout : undefined,
                            xhrFields: { withCredentials: this.withCredentials }
                        }, this.options);
                        return AppPlayer.Utils.ajax(options).then(function (data) {
                            if (_this.variableName) {
                                variables.setValue(_this.variableName, data);
                            }
                        }, function (error) {
                            var result = $.Deferred();
                            if (_this.errorVariableName) {
                                variables.setValue(_this.errorVariableName, error);
                                result.resolve();
                            } else {
                                result.reject({
                                    op: _this,
                                    data: error,
                                    dataError: true
                                });
                            }
                            return result;
                        }).always(functions["available"]);
                    };
                    SendRequest.methods = [{ name: "get", value: "GET" }, { name: "post", value: "POST" }, { name: "delete", value: "DELETE" }, { name: "put", value: "PUT" }, { name: "head", value: "HEAD" }, { name: "options", value: "OPTIONS" }, { name: "merge", value: "MERGE" }, { name: "patch", value: "PATCH" }];
                    return SendRequest;
                }(Operation);
                Logic.SendRequest = SendRequest;
                var Delete = function (_super) {
                    __extends(Delete, _super);
                    function Delete(param) {
                        _super.call(this);
                        this.objectOrKeyExpr = "";
                        this.storeId = "";
                        this.errorVariableName = "";
                        if (param) {
                            this.objectOrKeyExpr = param.objectOrKeyExpr || "";
                            this.storeId = param.storeId || "";
                        }
                    }
                    Delete.prototype.run = function (variables, functions) {
                        var _this = this;
                        var d = $.Deferred(),
                            objectOrKey = variables.getValue(this.objectOrKeyExpr);
                        functions.delete(objectOrKey, this.storeId).then(function (result) {
                            return d.resolve(result);
                        }, function (error) {
                            if (_this.errorVariableName) {
                                variables.setValue(_this.errorVariableName, error);
                                d.resolve();
                            } else {
                                d.reject({
                                    op: _this,
                                    data: error,
                                    dataError: true
                                });
                            }
                        });
                        return d.promise();
                    };
                    return Delete;
                }(Operation);
                Logic.Delete = Delete;
                var NavigateBack = function (_super) {
                    __extends(NavigateBack, _super);
                    function NavigateBack() {
                        _super.apply(this, arguments);
                    }
                    NavigateBack.prototype.run = function (variables, functions) {
                        functions.back();
                        return Logic.trivialPromise();
                    };
                    return NavigateBack;
                }(Operation);
                Logic.NavigateBack = NavigateBack;
                var ShowConfirmDialog = function (_super) {
                    __extends(ShowConfirmDialog, _super);
                    function ShowConfirmDialog(param) {
                        _super.call(this);
                        this.yesNext = [];
                        this.noNext = [];
                        this.message = null;
                        this.title = null;
                        if (param) {
                            this.yesNext = param.yesNext;
                            this.noNext = param.noNext;
                            this.message = param.message;
                            this.title = param.title;
                        }
                    }
                    ShowConfirmDialog.prototype.run = function (variables, functions) {
                        var _this = this;
                        var message = variables.evalAutoExpression(this.message),
                            title = variables.evalAutoExpression(this.title);
                        return dxdialog.confirm(message, title).then(function (result) {
                            var next = result ? _this.yesNext : _this.noNext;
                            if (next && next.length > 0) {
                                return Operation.run(next, variables, functions);
                            }
                            return Logic.trivialPromise();
                        });
                    };
                    return ShowConfirmDialog;
                }(Operation);
                Logic.ShowConfirmDialog = ShowConfirmDialog;
                var ShowAlert = function (_super) {
                    __extends(ShowAlert, _super);
                    function ShowAlert(param) {
                        _super.call(this);
                        this.message = null;
                        this.title = null;
                        if (param) {
                            this.message = param.message;
                            this.title = param.title;
                        }
                    }
                    ShowAlert.prototype.run = function (variables, functions) {
                        var message = variables.evalAutoExpression(this.message),
                            title = variables.evalAutoExpression(this.title);
                        return dxdialog.alert(message, title).then(function () {
                            return Logic.trivialPromise();
                        });
                    };
                    return ShowAlert;
                }(Operation);
                Logic.ShowAlert = ShowAlert;
                var ShowWebPage = function (_super) {
                    __extends(ShowWebPage, _super);
                    function ShowWebPage(param) {
                        _super.call(this);
                        this.url = "";
                        this.sameWindow = false;
                        if (param) {
                            this.url = param.url;
                        }
                    }
                    ShowWebPage.prototype.run = function (variables, functions) {
                        var url = variables.evalAutoExpression(this.url);
                        if (AppPlayer.LayoutHelper.getDeviceType() === "desktop") {
                            if (this.sameWindow) {
                                document.location.href = url;
                            } else {
                                window.open(url, "_blank");
                            }
                        } else {
                            window.open(url, "_system");
                        }
                        return Logic.trivialPromise();
                    };
                    return ShowWebPage;
                }(Operation);
                Logic.ShowWebPage = ShowWebPage;
                var GetDeviceType = function (_super) {
                    __extends(GetDeviceType, _super);
                    function GetDeviceType(param) {
                        _super.call(this);
                        this.resultVariableName = "";
                        if (param) {
                            this.resultVariableName = param.resultVariableName;
                        }
                    }
                    GetDeviceType.prototype.run = function (variables, functions) {
                        if (!variables.isDefined(this.resultVariableName)) {
                            return Logic.rejectPromise("GetDeviceType: variable '" + this.resultVariableName + "' does not exist");
                        }
                        var deviceType = AppPlayer.LayoutHelper.getDeviceType();
                        variables.setValue(this.resultVariableName, deviceType);
                        return Logic.trivialPromise();
                    };
                    return GetDeviceType;
                }(Operation);
                Logic.GetDeviceType = GetDeviceType;
                var FormatDateTime = function (_super) {
                    __extends(FormatDateTime, _super);
                    function FormatDateTime(params) {
                        _super.call(this);
                        this.variableName = "";
                        this.format = "ddMMMM";
                        this.resultVariableName = "";
                        if (params) {
                            this.variableName = params.variableName;
                            this.format = params.format;
                            this.resultVariableName = params.resultVariableName;
                        }
                    }
                    FormatDateTime.prototype.run = function (variables, functions) {
                        if (!variables.isDefined(this.resultVariableName)) {
                            return Logic.rejectPromise("FormatDateTime: variable '" + this.resultVariableName + "' does not exist");
                        }
                        var date = variables.getValue(this.variableName);
                        variables.setValue(this.resultVariableName, Globalize.format(date, this.format));
                        return Logic.trivialPromise();
                    };
                    FormatDateTime.formats = ["HH:mm:ss", "h:mm:ss", "yyyy-MM-dd", "MM/dd/yyyy", "dd.MM.yyyy", "yyyy-MM-dd HH:mm:ss", "dd.MM.yyyy HH:mm:ss", "MM/dd/yyyy h:mm:ss"];
                    return FormatDateTime;
                }(Operation);
                Logic.FormatDateTime = FormatDateTime;
                var ParseDateTime = function (_super) {
                    __extends(ParseDateTime, _super);
                    function ParseDateTime(params) {
                        _super.call(this);
                        this.variableName = "";
                        this.resultVariableName = "";
                        if (params) {
                            this.variableName = params.variableName;
                            this.resultVariableName = params.resultVariableName;
                        }
                    }
                    ParseDateTime.prototype.run = function (variables, functions) {
                        var date = variables.getValue(this.variableName);
                        variables.setValue(this.resultVariableName, AppPlayer.parseDate(date));
                        return Logic.trivialPromise();
                    };
                    return ParseDateTime;
                }(Operation);
                Logic.ParseDateTime = ParseDateTime;
                var XmlToJs = function (_super) {
                    __extends(XmlToJs, _super);
                    function XmlToJs(params) {
                        _super.call(this);
                        this.variableName = "";
                        this.resultVariableName = "";
                        if (params) {
                            this.variableName = params.variableName;
                            this.resultVariableName = params.resultVariableName;
                        }
                    }
                    XmlToJs.prototype.run = function (variables, functions) {
                        if (!this.variableName || !variables.isDefined(this.variableName)) {
                            return Logic.rejectPromise("XmlToJs: variable '" + this.variableName + "' does not exist");
                        }
                        if (!this.resultVariableName || !variables.isDefined(this.resultVariableName)) {
                            return Logic.rejectPromise("XmlToJs: result variable '" + this.resultVariableName + "' does not exist");
                        }
                        var xml = variables.getValue(this.variableName),
                            xmlDoc;
                        try {
                            xmlDoc = $.isXMLDoc(xml) ? xml : $.parseXML(xml);
                            variables.setValue(this.resultVariableName, AppPlayer.xmlToJs(xmlDoc.documentElement));
                        } catch (err) {
                            variables.setValue(this.resultVariableName, {});
                        }
                        return Logic.trivialPromise();
                    };
                    return XmlToJs;
                }(Operation);
                Logic.XmlToJs = XmlToJs;
                var CallParam = function () {
                    function CallParam() {}
                    return CallParam;
                }();
                Logic.CallParam = CallParam;
                ;
                var Call = function (_super) {
                    __extends(Call, _super);
                    function Call(params) {
                        _super.call(this);
                        this.functionName = "";
                        this.resultVariableName = "";
                        this.params = [];
                        if (params) {
                            this.functionName = params.functionName;
                            this.resultVariableName = params.resultVariableName || "";
                            this.params = params.params || [];
                        }
                    }
                    Call.prototype.run = function (variables, functions) {
                        var _this = this;
                        if (typeof this.functionName !== "string" || this.functionName.length === 0) {
                            return Logic.rejectPromise("Call: a function name must be specified");
                        }
                        // NOTE: the alias w/o $... takes function from $global (backward compatibility) or functions (for Module-functions)
                        var modelName = this.functionName.indexOf("$model") === 0 ? "$model" : "$global",
                            model = variables.getValue(modelName),
                            fnName = this.functionName.replace(modelName + ".", ""),
                            fn = model[fnName] || functions[fnName],
                            params = variables.getContext();
                        this.params.forEach(function (param) {
                            var value = variables.getValue(param.expr);
                            params[param.name] = value;
                        });
                        if (this.resultVariableName) {
                            return fn(params).then(function (result) {
                                variables.setValue(_this.resultVariableName, result);
                                return Logic.trivialPromise();
                            });
                        }
                        return fn(params) || Logic.trivialPromise();
                    };
                    return Call;
                }(Operation);
                Logic.Call = Call;
                var Debugger = function (_super) {
                    __extends(Debugger, _super);
                    function Debugger() {
                        _super.apply(this, arguments);
                    }
                    Debugger.prototype.run = function (variables, functions) {
                        /* tslint:disable: no-debugger */
                        debugger;
                        /* tslint:enable */
                        return Logic.trivialPromise();
                    };
                    return Debugger;
                }(Operation);
                Logic.Debugger = Debugger;
                var Log = function (_super) {
                    __extends(Log, _super);
                    function Log(params) {
                        _super.call(this);
                        this.message = "";
                        this.level = "info";
                        if (params) {
                            this.message = params.message;
                            this.level = params.level || this.level;
                        }
                    }
                    Log.prototype.run = function (variables, functions) {
                        if (!this.message) {
                            return Logic.rejectPromise("Log: message must be specified");
                        }
                        var message = variables.evalAutoExpression(this.message);
                        functions["log"](this.level, message);
                        return Logic.trivialPromise();
                    };
                    return Log;
                }(Operation);
                Logic.Log = Log;
                var Eval = function (_super) {
                    __extends(Eval, _super);
                    function Eval(params) {
                        _super.call(this);
                        this.expr = "";
                        this.errorVariableName = "";
                        if (params) {
                            this.expr = params.expr;
                            this.errorVariableName = params.errorVariableName;
                        }
                    }
                    Eval.prototype.run = function (variables, functions) {
                        if (!this.expr) {
                            return Logic.rejectPromise("Eval: an expression must be specified");
                        }
                        return this.eval(this.expr, variables);
                    };
                    Eval.prototype.eval = function (expr, variables) {
                        var _this = this;
                        var vars = variables.getContext(),
                            restoreVariablesExpr = "",
                            errorHandler = function (d, e) {
                            if (_this.errorVariableName) {
                                variables.setValue(_this.errorVariableName, e);
                                d.resolve();
                            } else {
                                d.reject(e);
                            }
                        };
                        //NOTE: restore values to BizLogic-variables after user-code execution
                        $.each(vars, function (name) {
                            restoreVariablesExpr += "variables.setValue('" + name + "', " + name + ");";
                        });
                        return Eval.exec(expr, restoreVariablesExpr, errorHandler, variables, vars);
                    };
                    Eval.runFn = function (body, values, variables) {
                        var bodyEval = body.replace(/\n/g, " ").replace(/\r/g, " ").replace(/"/g, "\\\""),
                            fn = new Function("_values_", "variables", "with(_values_) {return eval(\"" + bodyEval + "\")}");
                        return fn.apply(null, [values, variables]);
                    };
                    Eval.exec = function (body, restoreVariablesExpr, errorHandler, variables, values) {
                        var _result_ = $.Deferred();
                        try {
                            var promise = Eval.runFn(body, values);
                            if (AppPlayer.Utils.Cast.isPromise(promise)) {
                                promise.then(function () {
                                    Eval.runFn(restoreVariablesExpr, values, variables);
                                    _result_.resolve();
                                }, function (e) {
                                    errorHandler(_result_, e);
                                });
                            } else {
                                Eval.runFn(restoreVariablesExpr, values, variables);
                                _result_.resolve();
                            }
                        } catch (e) {
                            errorHandler(_result_, e.message);
                        }
                        return _result_;
                    };
                    return Eval;
                }(Operation);
                Logic.Eval = Eval;
            })(Logic = AppPlayer.Logic || (AppPlayer.Logic = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            "use strict";

            (function (TYPES) {
                TYPES[TYPES["PRIMITIVE_TYPE"] = 0] = "PRIMITIVE_TYPE";
                TYPES[TYPES["ARRAY_TYPE"] = 1] = "ARRAY_TYPE";
                TYPES[TYPES["OBJECT_TYPE"] = 2] = "OBJECT_TYPE";
                TYPES[TYPES["STORE_TYPE"] = 3] = "STORE_TYPE";
                TYPES[TYPES["TYPED_OBJECT"] = 4] = "TYPED_OBJECT";
            })(AppPlayer.TYPES || (AppPlayer.TYPES = {}));
            var TYPES = AppPlayer.TYPES;
            ;
            var TypeInfoRepository = function () {
                function TypeInfoRepository(storesConfig) {
                    // from DevExpress.data.utils.odata.keyConverters
                    this.oDataToJsonTypeMap = {
                        String: "string",
                        Int32: "number",
                        Int64: "number",
                        Guid: "string",
                        Boolean: "boolean"
                    };
                    this.types = [];
                    this.addWithList({
                        name: TypeInfoRepository.BOOLEAN,
                        kind: TYPES.PRIMITIVE_TYPE,
                        defaultValueCtor: function () {
                            return false;
                        },
                        toUIString: function (value) {
                            return ko.unwrap(value).toString();
                        }
                    });
                    this.addWithList({
                        name: "number",
                        kind: TYPES.PRIMITIVE_TYPE,
                        defaultValueCtor: function () {
                            return 0;
                        },
                        toUIString: function (value) {
                            return ko.unwrap(value).toString();
                        }
                    });
                    this.addWithList({
                        name: "string",
                        kind: TYPES.PRIMITIVE_TYPE,
                        defaultValueCtor: function () {
                            return "";
                        },
                        toUIString: function (value) {
                            return "\"" + ko.unwrap(value) + "\"";
                        }
                    });
                    this.addWithList({
                        name: "datetime",
                        kind: TYPES.PRIMITIVE_TYPE,
                        defaultValueCtor: function () {
                            return new Date();
                        },
                        toUIString: function (value) {
                            return ko.unwrap(value).toString();
                        }
                    });
                    this.addWithList({
                        name: "object",
                        kind: TYPES.OBJECT_TYPE,
                        defaultValueCtor: function () {
                            return {};
                        },
                        toUIString: function (value) {
                            if (value === null) {
                                return "null";
                            }
                            if (typeof value === "undefined") {
                                return "undefined";
                            }
                            return ko.unwrap(value).toString();
                        }
                    });
                    this.addWithList({
                        name: "guid",
                        kind: TYPES.PRIMITIVE_TYPE,
                        defaultValueCtor: function () {
                            return "";
                        },
                        toUIString: function (value) {
                            return ko.unwrap(value);
                        }
                    });
                    this.addStoreTypes(storesConfig);
                }
                Object.defineProperty(TypeInfoRepository, "BOOLEAN", {
                    get: function () {
                        return "boolean";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TypeInfoRepository, "OBJECT", {
                    get: function () {
                        return "object";
                    },
                    enumerable: true,
                    configurable: true
                });
                TypeInfoRepository.hasProperties = function (t) {
                    if (t.kind !== TYPES.STORE_TYPE) {
                        return false;
                    }
                    return t.properties.length > 1 && !!t.keyProperty || t.properties.length > 0 && !t.keyProperty;
                };
                TypeInfoRepository.migrateObject = function (obj, t) {
                    if (t.kind !== TYPES.STORE_TYPE) {
                        return obj;
                    }
                    if (obj instanceof Object) {
                        var properties = t.properties;
                        if (properties.length) {
                            var propNames = {};
                            if (t.keyProperty) {
                                propNames[t.keyProperty.name] = true;
                            }
                            properties.forEach(function (prop) {
                                if (!obj.hasOwnProperty(prop.name)) {
                                    obj[prop.name] = prop.type.defaultValueCtor();
                                }
                                propNames[prop.name] = true;
                            });
                            $.each(Object.keys(obj), function (index, propName) {
                                if (!propNames[propName]) {
                                    delete obj[propName];
                                }
                            });
                            return obj;
                        } else {
                            return obj;
                        }
                    } else {
                        return t.defaultValueCtor();
                    }
                };
                TypeInfoRepository.prototype.get = function (typeName) {
                    return this.types[ko.unwrap(typeName)];
                };
                TypeInfoRepository.prototype.getAll = function () {
                    return this.types;
                };
                TypeInfoRepository.prototype.typeOf = function (value) {
                    var valueType = typeof value;
                    if (this.types[valueType]) {
                        return valueType;
                    }
                    for (var i = 0; i < this.types.length; i++) {
                        var typeInfo = this.types[i];
                        if (typeInfo.kind === TYPES.PRIMITIVE_TYPE) {
                            if (typeof typeInfo.defaultValueCtor() === valueType) {
                                return typeInfo.name;
                            } else {
                                if (this.isStoreObject(value, typeInfo)) {
                                    return typeInfo.name;
                                }
                            }
                        }
                    }
                    return null;
                };
                TypeInfoRepository.prototype.storeId = function (typeName) {
                    var type = this.get(typeName);
                    if (type) {
                        if (type.kind === TYPES.STORE_TYPE) {
                            return type.name;
                        } else if (type.kind === TYPES.ARRAY_TYPE && type.nestedType.kind === TYPES.STORE_TYPE) {
                            return type.nestedType.name;
                        }
                    }
                    return null;
                };
                TypeInfoRepository.prototype.addTypedObjectType = function (typeInfo) {
                    if (!typeInfo) {
                        return;
                    }
                    this._add(typeInfo);
                };
                TypeInfoRepository.prototype.addStoreTypes = function (storesConfig) {
                    var _this = this;
                    if (!storesConfig) {
                        return;
                    }
                    storesConfig.forEach(function (store) {
                        var keyProperty;
                        var properties = [];
                        if (store.fields) {
                            store.fields.forEach(function (field) {
                                var baseType = _this.get(field.type);
                                if (!baseType) {
                                    console.warn("Store '" + store.id + "' field '" + field.name + "' has unknown type '" + field.type + "'");
                                    baseType = _this.get("object");
                                }
                                var property = {
                                    name: field.name,
                                    type: baseType
                                };
                                if (field.name === store.key) {
                                    keyProperty = property;
                                } else {
                                    properties.push(property);
                                }
                            });
                        }
                        if (!keyProperty && store.key) {
                            var keyTypeName = _this.oDataToJsonTypeMap[store["keyType"]];
                            keyProperty = { name: store.key, type: _this.get(keyTypeName) || _this.get(TypeInfoRepository.OBJECT) };
                        }
                        _this.addWithList({
                            name: store.id,
                            kind: TYPES.STORE_TYPE,
                            keyProperty: keyProperty,
                            properties: properties,
                            defaultValueCtor: function () {
                                return _this.defaultObjectCtor(properties);
                            },
                            toUIString: function (value) {
                                return "{" + store.id + "}";
                            }
                        });
                    });
                };
                TypeInfoRepository.prototype.isStoreObject = function (object, typeInfo) {
                    if (!$.isPlainObject(object)) {
                        return false;
                    }
                    var result = true;
                    $.each(object, function (propertyName, propertyValue) {
                        result = typeInfo.properties.some(function (property) {
                            return propertyName === property.name;
                        });
                        return result;
                    });
                    return result;
                };
                TypeInfoRepository.prototype.defaultObjectCtor = function (properties) {
                    var result = {};
                    properties.forEach(function (property) {
                        result[property.name] = property.type.defaultValueCtor();
                    });
                    return result;
                };
                TypeInfoRepository.prototype.createListType = function (plainType) {
                    var listType = {
                        name: plainType.name + "[]",
                        kind: TYPES.ARRAY_TYPE,
                        defaultValueCtor: function () {
                            return [];
                        },
                        nestedType: plainType,
                        toUIString: function (value) {
                            value = ko.unwrap(value);
                            var result = plainType.name + "[";
                            if (value && value.length > 0) {
                                result += value.length;
                            }
                            return result + "]";
                        }
                    };
                    return listType;
                };
                TypeInfoRepository.prototype.addWithList = function (type) {
                    this._add(type);
                    var listType = this.createListType(type);
                    this._add(listType);
                };
                TypeInfoRepository.prototype._add = function (type) {
                    this.types.push(type);
                    this.types[type.name] = type;
                };
                return TypeInfoRepository;
            }();
            AppPlayer.TypeInfoRepository = TypeInfoRepository;
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Logic;
            (function (Logic) {
                "use strict";

                var Variable = function () {
                    function Variable(config) {
                        this._config = config;
                        this.value = config.value;
                    }
                    Object.defineProperty(Variable.prototype, "name", {
                        get: function () {
                            return this._config.name;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(Variable.prototype, "parameter", {
                        get: function () {
                            return this._config.parameter || false;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(Variable.prototype, "type", {
                        get: function () {
                            return this._config.type || "object";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Variable.prototype.resetValue = function () {
                        this.value = AppPlayer.clone(this._config.value);
                    };
                    Variable.fromJson = function (json) {
                        var result = new Variable(json);
                        return result;
                    };
                    return Variable;
                }();
                Logic.Variable = Variable;
            })(Logic = AppPlayer.Logic || (AppPlayer.Logic = {}));
        })(AppPlayer || (AppPlayer = {}));
        /*module AppPlayer {
        "use strict";
        import dxdata = DevExpress.data;
        
        export class LocalStore extends dxdata.LocalStore {
            constructor(storeOptions: dxdata.LocalStoreOptions) {
                super(storeOptions);
            }
        
            byKey(key: any, extraOptions: any): JQueryPromise<any> {
                return super.byKey(key, extraOptions)
                    .then((value: any) => {
                        if(value instanceof Object) {
                            return $.extend({}, value);
                        } else {
                            return value;
                        }
                    });
            }
        
            load(obj?: dxdata.LoadOptions): JQueryPromise<any[]> {
                return super.load(obj)
                    .then((value: any[]) => {
                        if(value) {
                            $.each(value, (name, val) => {
                                if(val instanceof Object) {
                                    value[name] = $.extend({}, val);
                                }
                            });
                        }
                        return value;
                    });
            }
        }
        }*/
        var AppPlayer;
        (function (AppPlayer) {
            var Stores;
            (function (Stores) {
                var Utils;
                (function (Utils) {
                    "use strict";

                    function compileUrl(context) {
                        return function (request) {
                            try {
                                request.url = AppPlayer.Logic.Operation.eval(request.url, context);
                            } catch (ignored) {}
                            return request;
                        };
                    }
                    Utils.compileUrl = compileUrl;
                    function addHeaders(headers) {
                        var result = function (request) {};
                        if (headers && headers.length) {
                            result = function (request) {
                                request.headers = request.headers || {};
                                headers.forEach(function (header) {
                                    request.headers[header.name] = header.value;
                                });
                                return request;
                            };
                        }
                        return result;
                    }
                    Utils.addHeaders = addHeaders;
                    var dataConverters = {
                        csv: function (xhr) {
                            if (xhr.responseText) {
                                var text = xhr.responseText,
                                    separator;
                                // Detect separators
                                if (text.indexOf("\";\"") >= 0) {
                                    separator = ";";
                                } else if (text.indexOf("\",\"") >= 0) {
                                    separator = ",";
                                } else if (text.indexOf(";") >= 0) {
                                    separator = ";";
                                } else {
                                    separator = ",";
                                }
                                // Do conversion
                                return csv2array(text, separator);
                            } else {
                                return void 0;
                            }
                        },
                        xml: function (xhr) {
                            if (xhr.responseXML) {
                                return AppPlayer.xmlToJs(xhr.responseXML);
                            } else if (xhr.responseText) {
                                var xml = $.parseXML(xhr.responseText);
                                return xml ? AppPlayer.xmlToJs(xml) : void 0;
                            } else {
                                return void 0;
                            }
                        },
                        json: function (xhr) {
                            if (xhr["responseJson"]) {
                                return xhr["responseJson"];
                            } else if (xhr.responseText) {
                                try {
                                    return JSON.parse(xhr.responseText);
                                } catch (ignored) {}
                            }
                            return void 0;
                        }
                    };
                    var contentTypeMap = {
                        "text/csv": "csv",
                        "text/xml": "xml",
                        "application/xml": "xml",
                        "application/json": "json"
                    };
                    function convertData(xhr, dataType) {
                        var result = dataConverters[dataType] ? dataConverters[dataType](xhr) : void 0;
                        if (!result) {
                            // Try to figure out dataType from response headers
                            var contentType = xhr.getResponseHeader("Content-Type");
                            if (contentType) {
                                for (var mime in contentTypeMap) {
                                    if (AppPlayer.startsWith(contentType, mime)) {
                                        dataType = contentTypeMap[mime];
                                        result = dataConverters[dataType] ? dataConverters[dataType](xhr) : void 0;
                                        break;
                                    }
                                }
                            }
                        }
                        return result;
                    }
                    Utils.convertData = convertData;
                    function csv2array(strData, strDelimiter) {
                        // Check to see if the delimiter is defined. If not,
                        // then default to comma.
                        strDelimiter = strDelimiter || ",";
                        // Create a regular expression to parse the CSV values.
                        var objPattern = new RegExp(
                        // Delimiters.
                        "(\\" + strDelimiter + "|\\r?\\n|\\r|^)" +
                        // Quoted fields.
                        "(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" +
                        // Standard fields.
                        "([^\"\\" + strDelimiter + "\\r\\n]*))", "gi");
                        // Create an array to hold our data. Give the array
                        // a default empty first row.
                        var arrData = [[]];
                        // Create an array to hold our individual pattern
                        // matching groups.
                        var arrMatches = null;
                        // Keep looping over the regular expression matches
                        // until we can no longer find a match.
                        while (arrMatches = objPattern.exec(strData)) {
                            // Get the delimiter that was found.
                            var strMatchedDelimiter = arrMatches[1];
                            // Check to see if the given delimiter has a length
                            // (is not the start of string) and if it matches
                            // field delimiter. If id does not, then we know
                            // that this delimiter is a row delimiter.
                            if (strMatchedDelimiter.length && strMatchedDelimiter !== strDelimiter) {
                                // Since we have reached a new row of data,
                                // add an empty row to our data array.
                                arrData.push([]);
                            }
                            var strMatchedValue;
                            // Now that we have our delimiter out of the way,
                            // let's check to see which kind of value we
                            // captured (quoted or unquoted).
                            if (arrMatches[2]) {
                                // We found a quoted value. When we capture
                                // this value, unescape any double quotes.
                                strMatchedValue = arrMatches[2].replace(new RegExp("\"\"", "g"), "\"");
                            } else {
                                // We found a non-quoted value.
                                strMatchedValue = arrMatches[3];
                            }
                            // Now that we have our value string, let's add
                            // it to the data array.
                            arrData[arrData.length - 1].push(strMatchedValue);
                        }
                        // Return the parsed data.
                        return arrData;
                    }
                    function bindStore(store, dependent) {
                        var keyName = store.key(),
                            oldArray = dependent() || [];
                        store.on("loaded", function (data) {
                            dependent(data);
                        });
                        store.on("removed", function (key) {
                            var newValue = oldArray.filter(function (item) {
                                return item[keyName] !== key;
                            });
                            dependent(newValue);
                        });
                        store.on("inserted", function (values) {
                            oldArray.push(values);
                            dependent(oldArray);
                        });
                        store.on("updated", function (key, newValue) {
                            var updatedItem = oldArray.filter(function (item) {
                                return item[keyName] === key;
                            })[0],
                                index = oldArray.indexOf(updatedItem);
                            oldArray[index] = newValue;
                            dependent(oldArray);
                        });
                    }
                    Utils.bindStore = bindStore;
                })(Utils = Stores.Utils || (Stores.Utils = {}));
            })(Stores = AppPlayer.Stores || (AppPlayer.Stores = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Views;
            (function (Views) {})(Views = AppPlayer.Views || (AppPlayer.Views = {}));
        })(AppPlayer || (AppPlayer = {}));
        /// <template path="../../AppPlayer/Templates/ViewComponents.html"/>
        var AppPlayer;
        (function (AppPlayer) {
            var Views;
            (function (Views) {
                "use strict";

                var eventCounter = 1;
                var DefaultsProvider = function () {
                    function DefaultsProvider() {}
                    DefaultsProvider.GetDefaults = function (config) {
                        return config.type && Views.componentInfos[config.type] && Views.componentInfos[config.type].defaults ? Views.componentInfos[config.type].defaults : {};
                    };
                    return DefaultsProvider;
                }();
                Views.DefaultsProvider = DefaultsProvider;
                var ComponentMarkupRenderBase = function () {
                    function ComponentMarkupRenderBase(config, options) {
                        this.options = {};
                        this.options = $.extend({}, { designMode: false, defaultsGetter: DefaultsProvider.GetDefaults }, options);
                        this.config = $.extend(true, {}, this.options.defaultsGetter(config), config);
                    }
                    ComponentMarkupRenderBase.prototype._getModelObject = function (modelConfig, app) {
                        return this.patchConfig(modelConfig || this.config, app);
                    };
                    ComponentMarkupRenderBase.prototype._getBindnigStringObject = function (modelObject) {
                        var result = $.extend({}, modelObject);
                        delete result["type"];
                        return result;
                    };
                    ComponentMarkupRenderBase.prototype.getModel = function (app, modelConfig) {
                        var modelObject = this._getModelObject(modelConfig || this.config, app),
                            self = this;
                        return {
                            model: modelObject,
                            get bindingString() {
                                return AppPlayer.BindingStringMaker.makeString(self._getBindnigStringObject(modelObject));
                            }
                        };
                    };
                    ComponentMarkupRenderBase.prototype._patchField = function (fieldValue) {
                        if (typeof fieldValue === "string") {
                            fieldValue = "'" + fieldValue.replace(/'/g, "\\'") + "'";
                        }
                        return fieldValue;
                    };
                    ComponentMarkupRenderBase.prototype._patchConfig = function (config, app) {
                        return this.patchConfig({ config: config }, app).config;
                    };
                    ComponentMarkupRenderBase.prototype._patchEvents = function (componentConfig, componentInfo, app) {
                        if (componentInfo.events) {
                            componentInfo.events.forEach(function (eventName) {
                                var event = componentConfig[eventName],
                                    fn,
                                    id,
                                    functionCompiler;
                                if (!event || !app || !app.createFunctionCompiler) {
                                    return;
                                } else {
                                    functionCompiler = app.createFunctionCompiler(event);
                                    fn = function (context) {
                                        return functionCompiler.run($.extend({}, context), {
                                            callerType: "event of the " + componentConfig.id + "component",
                                            callerId: eventName
                                        });
                                    };
                                    id = "anonymousEvent" + eventCounter++;
                                    app.functions[id] = fn;
                                    componentConfig[eventName] = id;
                                }
                            });
                        }
                    };
                    ComponentMarkupRenderBase.prototype.patchConfig = function (config, app) {
                        var _this = this;
                        return AppPlayer.propertyVisitor(this.patchStyles(config), function (context) {
                            return _this.options.designMode || context.name === "type" ? context.value : _this._patchField(context.value);
                        }, {
                            getValueCallback: function (value) {
                                var componentInfo = value.type && Views.componentInfos[value.type];
                                if (componentInfo) {
                                    _this._patchEvents(value, componentInfo, app);
                                    return new componentInfo.rendererType(value, null).getModel(app);
                                } else {
                                    return _this.patchConfig(value, app);
                                }
                            }
                        });
                    };
                    ComponentMarkupRenderBase.prototype.patchStyles = function (config) {
                        $.each(config.style || {}, function (name, value) {
                            var index = name.indexOf("-"),
                                firstLetterUpper = function (str) {
                                if (!str) {
                                    return "";
                                }
                                return str.charAt(0).toUpperCase() + str.slice(1);
                            };
                            if (index !== -1) {
                                delete config.style[name];
                                var prefix = name.substring(0, index),
                                    postfix = firstLetterUpper(name.substring(index + 1));
                                config.style["" + prefix + postfix] = value;
                            }
                        });
                        return config;
                    };
                    return ComponentMarkupRenderBase;
                }();
                Views.ComponentMarkupRenderBase = ComponentMarkupRenderBase;
                var BaseContainerMarkupRenderer = function (_super) {
                    __extends(BaseContainerMarkupRenderer, _super);
                    function BaseContainerMarkupRenderer() {
                        _super.apply(this, arguments);
                    }
                    BaseContainerMarkupRenderer.prototype._patchComponents = function (components, application, mainSize, usePatchConfig) {
                        var _this = this;
                        if (mainSize === void 0) {
                            mainSize = "height";
                        }
                        if (usePatchConfig === void 0) {
                            usePatchConfig = true;
                        }
                        return components.map(function (_component) {
                            var style = _component.style || {},
                                mainValue = style[mainSize] || "",
                                preventShrink = mainValue.indexOf("%") === -1,
                                component = usePatchConfig ? _this._patchConfig(_component, application) : _component;
                            return { preventShrink: preventShrink, component: component };
                        });
                    };
                    return BaseContainerMarkupRenderer;
                }(ComponentMarkupRenderBase);
                Views.BaseContainerMarkupRenderer = BaseContainerMarkupRenderer;
                var ViewMarkupRenderer = function (_super) {
                    __extends(ViewMarkupRenderer, _super);
                    function ViewMarkupRenderer(viewConfig, application) {
                        _super.call(this, viewConfig, {});
                        this.viewConfig = viewConfig;
                        this.application = application;
                    }
                    ViewMarkupRenderer.prototype.getModel = function () {
                        var viewAndComponents = AppPlayer.extract(this.viewConfig, "components"),
                            model = _super.prototype.getModel.call(this, this.application, viewAndComponents.leftover).model,
                            components = this._patchComponents(viewAndComponents.target, this.application);
                        return {
                            model: $.extend(model, { components: components }),
                            bindingString: AppPlayer.BindingStringMaker.makeString({
                                name: model.id,
                                title: model.title,
                                disableCache: model.disableCache,
                                pane: model.pane
                            })
                        };
                    };
                    ViewMarkupRenderer.prototype.render = function () {
                        var _this = this;
                        var result, error;
                        //dust["debugLevel"] = "DEBUG";
                        dust["onLoad"] = function (name, callback) {
                            var template = document.getElementById(name);
                            if (!template) {
                                _this.application.registerMissingTemplate(name.substr("xet-dust-".length));
                            }
                            // TODO Pletnev remove || "!template with name " + name + " is not found!"
                            callback(null, template ? template.innerHTML : "!template with name " + name + " is not found!");
                        };
                        dust.render("xet-dust-view", this.getModel(), function (err, out) {
                            error = err;
                            result = out;
                        });
                        if (!result) {
                            throw new Error("Something went wrong during rendering of the '" + this.viewConfig.id + "' view markup. Error: \n" + error);
                        }
                        return result;
                    };
                    return ViewMarkupRenderer;
                }(BaseContainerMarkupRenderer);
                Views.ViewMarkupRenderer = ViewMarkupRenderer;
                var FormMarkupRenderer = function (_super) {
                    __extends(FormMarkupRenderer, _super);
                    function FormMarkupRenderer(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    FormMarkupRenderer.prototype.getModel = function (app) {
                        var formAndItems = AppPlayer.extract(this.config, "items"),
                            form = formAndItems.leftover,
                            items = formAndItems.target || [];
                        form["items"] = items.map(function (item) {
                            return {
                                label: { text: item.title },
                                template: item.id,
                                visible: item.visible
                            };
                        });
                        return {
                            model: {
                                type: this.config.type,
                                form: _super.prototype.getModel.call(this, app, form),
                                components: this._patchConfig(items, app).map(function (item, index) {
                                    item.model.templateName = "'" + form["items"][index].template + "'";
                                    return item;
                                })
                            }
                        };
                    };
                    return FormMarkupRenderer;
                }(BaseContainerMarkupRenderer);
                Views.FormMarkupRenderer = FormMarkupRenderer;
                var flexDictionary = {
                    vertical: "column",
                    horizontal: "row",
                    top: "flex-start",
                    middle: "center",
                    center: "center",
                    bottom: "flex-end",
                    left: "flex-start",
                    right: "flex-end"
                };
                Views.flexStylesList = ["flexDirection", "justifyContent", "alignItems", "flexWrap", "flexFlow", "alignContent", "flexBasis", "flexGrow", "flexShrink", "flex", "alignSelf", "order"];
                var StackPanelMarkupRender = function (_super) {
                    __extends(StackPanelMarkupRender, _super);
                    function StackPanelMarkupRender(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    StackPanelMarkupRender.prototype.getModel = function (app) {
                        var scrollable = !!this.config["scrollable"],
                            isVerticalOrientation = this.config.orientation === "vertical",
                            flexSettings = { orientation: this.config.orientation, verticalAlign: this.config.verticalAlign, horizontalAlign: this.config.horizontalAlign },
                            flexStyles = AppPlayer.remapWithValues(flexSettings, {
                            orientation: "flexDirection",
                            horizontalAlign: isVerticalOrientation ? "alignItems" : "justifyContent",
                            verticalAlign: isVerticalOrientation ? "justifyContent" : "alignItems"
                        }, flexDictionary, true),
                            config = $.extend({}, this.config, { style: $.extend(this.config.style, flexStyles) }),
                            componentsAndContainer = AppPlayer.extract(config, "components");
                        if (scrollable) {
                            var flexAndUsualStyle = AppPlayer.extractMany(config.style, Views.flexStylesList);
                            componentsAndContainer.leftover["otherStyles"] = flexAndUsualStyle.leftover;
                            componentsAndContainer.leftover["flexStyles"] = flexAndUsualStyle.target;
                        }
                        var model = {
                            type: config.type,
                            scrollable: scrollable,
                            stackPanel: _super.prototype.getModel.call(this, app, componentsAndContainer.leftover),
                            components: this._patchComponents(componentsAndContainer.target || [], app, isVerticalOrientation ? "height" : "width")
                        };
                        return {
                            model: model,
                            bindingString: model.stackPanel.bindingString
                        };
                    };
                    return StackPanelMarkupRender;
                }(BaseContainerMarkupRenderer);
                Views.StackPanelMarkupRender = StackPanelMarkupRender;
                var PassboxMarkupRender = function (_super) {
                    __extends(PassboxMarkupRender, _super);
                    function PassboxMarkupRender(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    PassboxMarkupRender.prototype._getModelObject = function (modelConfig, app) {
                        modelConfig.mode = "password";
                        return _super.prototype._getModelObject.call(this, modelConfig, app);
                    };
                    return PassboxMarkupRender;
                }(ComponentMarkupRenderBase);
                Views.PassboxMarkupRender = PassboxMarkupRender;
                var CommandMarkupRender = function (_super) {
                    __extends(CommandMarkupRender, _super);
                    function CommandMarkupRender(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    CommandMarkupRender.prototype._getModelObject = function (modelConfig, app) {
                        var result = _super.prototype._getModelObject.call(this, modelConfig, app),
                            device = AppPlayer.LayoutHelper.getDeviceType();
                        ["showIcon", "showText"].forEach(function (name) {
                            if (result[name]) {
                                result[name] = result[name][device];
                            }
                        });
                        return result;
                    };
                    CommandMarkupRender.prototype._getBindnigStringObject = function (modelObject) {
                        var result = _super.prototype._getBindnigStringObject.call(this, modelObject);
                        result.type = modelObject.buttonType;
                        return result;
                    };
                    return CommandMarkupRender;
                }(ComponentMarkupRenderBase);
                Views.CommandMarkupRender = CommandMarkupRender;
                var RowMarkupRender = function (_super) {
                    __extends(RowMarkupRender, _super);
                    function RowMarkupRender(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    RowMarkupRender.getBootstrapColStyle = function (column, wrap, totalSpanCount) {
                        var bootstrapColStyle = "",
                            devices = ["lg", "md", "tablet", "phone"],
                            map = {
                            lg: "lg",
                            md: "md",
                            tablet: "sm",
                            phone: "xs"
                        },
                            span = column.span;
                        devices.forEach(function (device) {
                            if (wrap && wrap[device]) {
                                span = totalSpanCount / wrap[device];
                            }
                            bootstrapColStyle += "col-" + map[device] + "-" + span + " ";
                        });
                        return bootstrapColStyle;
                    };
                    RowMarkupRender.prototype.getModel = function (app) {
                        var _this = this;
                        var _a = AppPlayer.destruct(this.config, "columns"),
                            columns = _a[0],
                            row = _a[1];
                        var model = {
                            type: this.config.type,
                            row: _super.prototype.getModel.call(this, app, row),
                            columns: (this._patchConfig(columns, app) || []).map(function (column) {
                                return $.extend(column, {
                                    bootstrapColStyle: _this._patchField(RowMarkupRender.getBootstrapColStyle(column, _this.config.wrap, _this.config.totalSpanCount || 12)),
                                    style: _super.prototype.getModel.call(_this, app, column.style || {})
                                });
                            })
                        };
                        return {
                            model: model,
                            bindingString: model.row.bindingString
                        };
                    };
                    return RowMarkupRender;
                }(ComponentMarkupRenderBase);
                Views.RowMarkupRender = RowMarkupRender;
                var ListMarkupRender = function (_super) {
                    __extends(ListMarkupRender, _super);
                    function ListMarkupRender(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    ListMarkupRender.prototype.getModel = function (app) {
                        var itemAndGroupList = AppPlayer.extract(this.config, "itemComponents"),
                            groupAndList = AppPlayer.extract(itemAndGroupList.leftover, "groupComponents");
                        groupAndList.leftover["scrollingEnabled"] = !!this.config["scrollable"];
                        var model = {
                            type: this.config.type,
                            list: _super.prototype.getModel.call(this, app, groupAndList.leftover),
                            itemComponents: this._patchComponents(itemAndGroupList.target || [], app),
                            groupComponents: this._patchComponents(groupAndList.target || [], app)
                        };
                        return {
                            model: model,
                            bindingString: model.list.bindingString
                        };
                    };
                    return ListMarkupRender;
                }(BaseContainerMarkupRenderer);
                Views.ListMarkupRender = ListMarkupRender;
                var FieldsetMarkupRender = function (_super) {
                    __extends(FieldsetMarkupRender, _super);
                    function FieldsetMarkupRender(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    FieldsetMarkupRender.prototype.getModel = function (app) {
                        var _this = this;
                        var fieldsAndFieldset = AppPlayer.extract(this.config, "fields");
                        var model = {
                            type: this.config.type,
                            fieldset: _super.prototype.getModel.call(this, app, fieldsAndFieldset.leftover),
                            fields: (fieldsAndFieldset.target || []).map(function (field) {
                                field.visible = field.visible === undefined ? true : field.visible;
                                return $.extend(true, {
                                    model: _this._patchConfig({
                                        title: field.title,
                                        visible: field.visible
                                    }, app)
                                }, _this._patchConfig(field, app));
                            }),
                            //TODO Pletnev: Remove this along with its applayer/appdesigner templates when dxFieldSet supports this option out of the box
                            singleColumnLayout: AppPlayer.LayoutHelper.getDeviceType() === "phone"
                        };
                        return {
                            model: model,
                            bindingString: model.fieldset.bindingString
                        };
                    };
                    return FieldsetMarkupRender;
                }(ComponentMarkupRenderBase);
                Views.FieldsetMarkupRender = FieldsetMarkupRender;
                var TabsMarkupRender = function (_super) {
                    __extends(TabsMarkupRender, _super);
                    function TabsMarkupRender(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    TabsMarkupRender.prototype.getModel = function (app) {
                        var _this = this;
                        var tabs = AppPlayer.extract(this.config, "tabs");
                        delete tabs.leftover["type"];
                        if (this.config.style && this.config.style.height) {
                            tabs.leftover["height"] = this.config.style.height;
                        }
                        var style = AppPlayer.extract(tabs.leftover, "style"),
                            tabsTarget = tabs.target || [];
                        tabsTarget = tabsTarget.map(function (tab) {
                            var components = tab.components || [];
                            tab.components = _this._patchComponents(components, app, "height", false);
                            return tab;
                        });
                        var model = {
                            type: this.config.type,
                            tabpanel: _super.prototype.getModel.call(this, app, style.leftover),
                            control: _super.prototype.getModel.call(this, app, { tabpanel: style.leftover, style: style.target }),
                            tabs: this._patchConfig(tabsTarget, app)
                        };
                        return {
                            model: model,
                            bindingString: model.tabpanel.bindingString
                        };
                    };
                    return TabsMarkupRender;
                }(BaseContainerMarkupRenderer);
                Views.TabsMarkupRender = TabsMarkupRender;
                var AccordionMarkupRender = function (_super) {
                    __extends(AccordionMarkupRender, _super);
                    function AccordionMarkupRender(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    AccordionMarkupRender.prototype.getModel = function (app) {
                        var _this = this;
                        var panels = AppPlayer.extract(this.config, "panels");
                        delete panels.leftover["type"];
                        var style = AppPlayer.extract(panels.leftover, "style");
                        panels.target = panels.target.map(function (panel) {
                            var components = panel.components || [];
                            panel.components = _this._patchComponents(components, app, "height", false);
                            return panel;
                        });
                        var model = {
                            type: this.config.type,
                            control: _super.prototype.getModel.call(this, app, { options: style.leftover, style: style.target }),
                            panels: this._patchConfig(panels.target, app)
                        };
                        return {
                            model: model,
                            bindingString: ""
                        };
                    };
                    return AccordionMarkupRender;
                }(BaseContainerMarkupRenderer);
                Views.AccordionMarkupRender = AccordionMarkupRender;
                var ScrollViewMarkupRender = function (_super) {
                    __extends(ScrollViewMarkupRender, _super);
                    function ScrollViewMarkupRender(config, options) {
                        if (options === void 0) {
                            options = {};
                        }
                        _super.call(this, config, options);
                    }
                    ScrollViewMarkupRender.prototype.getModel = function (app) {
                        var contentAndView = AppPlayer.extract(this.config, "components");
                        return {
                            model: {
                                type: this.config.type,
                                scrollview: _super.prototype.getModel.call(this, app, contentAndView.leftover),
                                components: this._patchComponents(contentAndView.target, app)
                            },
                            bindingString: ""
                        };
                    };
                    return ScrollViewMarkupRender;
                }(BaseContainerMarkupRenderer);
                Views.ScrollViewMarkupRender = ScrollViewMarkupRender;
                //TODO Pletnev Cache getComponentModel results by hash of (componentName + viewModel)
                //TODO Pletnev And extract model: any from arguments (getComponentModel should return a function that takes model: any)
                function getComponentModel(params) {
                    var componentInfo = params.componentName ? AppPlayer.Views.componentInfos[params.componentName] : null,
                        bindingProperties = [],
                        componentViewModel = AppPlayer.propertyVisitor(params.viewModel, function (context) {
                        var value = context.value,
                            propName = context.name,
                            isEvent = false,
                            result = value,
                            fn;
                        if (componentInfo && componentInfo.events) {
                            isEvent = componentInfo.events.some(function (eventName) {
                                return eventName === propName;
                            });
                        }
                        if (isEvent) {
                            fn = params.functions[value];
                            var runContext = $.extend({}, params.runContext);
                            result = function (e) {
                                var event = e ? e.jQueryEvent : null;
                                if (event && event.stopPropagation && params.componentName !== "command") {
                                    event.stopPropagation();
                                }
                                // TODO Pletnev Choose itemData or data depending on event and object
                                if (e && (e.itemData || e.data)) {
                                    runContext.$data = e.itemData || e.data;
                                } else {
                                    runContext.$data = params.runContext.$data;
                                }
                                return fn(runContext);
                            };
                        } else {
                            if (typeof value === "string") {
                                var val = value;
                                result = AppPlayer.wrapModelReference(val, params.runContext, params.callerInfo, params.functions);
                                if (result !== val) {
                                    bindingProperties.push(context.path ? context.path + "." + propName : propName);
                                }
                            }
                        }
                        return result;
                    });
                    if (componentInfo && componentInfo.componentViewModel) {
                        componentViewModel = componentInfo.componentViewModel(componentViewModel);
                    }
                    if (bindingProperties.length > 0) {
                        componentViewModel["_bindingProperties"] = bindingProperties;
                    }
                    return componentViewModel;
                }
                Views.getComponentModel = getComponentModel;
                function isNestedTemplateModel(bindingContext) {
                    while (bindingContext.$parent) {
                        if (bindingContext["nestedTemplateModel"] !== undefined) {
                            return bindingContext["nestedTemplateModel"];
                        }
                        bindingContext = bindingContext.$parent;
                    }
                    return false;
                }
                function withModelBinding(element, value, nestedTemplateModel, model, data) {
                    var $templateElements;
                    if (nestedTemplateModel && element) {
                        $templateElements = $(ko.virtualElements.firstChild(element)).parents("[data-options^='dxTemplate']");
                        if ($templateElements.length > 0) {
                            var templateElement = $templateElements.filter(function (index, item) {
                                var dataOptionsValue = item.attributes["data-options"].value;
                                return dataOptionsValue === "dxTemplate: { name: 'item' }";
                            }).get(0);
                            data = ko.dataFor(templateElement);
                        }
                    }
                    var viewModel = getComponentModel({
                        componentName: value.component,
                        runContext: {
                            $data: data,
                            $model: model,
                            $global: model._global
                        },
                        callerInfo: {
                            callerType: "getComponentModel delegate",
                            callerId: value.component
                        },
                        viewModel: value.viewModel,
                        functions: model._functions
                    });
                    viewModel.nestedTemplateModel = nestedTemplateModel;
                    return viewModel;
                }
                Views.withModelBinding = withModelBinding;
                ko.bindingHandlers["withModel"] = {
                    init: function (element, valueAccessor, allBindings, deprecated, bindingContext) {
                        var value = valueAccessor(),
                            nestedTemplateModel = isNestedTemplateModel(bindingContext),
                            model = bindingContext.$root,
                            data = bindingContext.$data;
                        var viewModel = withModelBinding(element, value, nestedTemplateModel, model, data);
                        // Make a modified binding context, with a extra properties, and apply it to descendant elements
                        ko.applyBindingsToDescendants(bindingContext.createChildContext(viewModel, "component", // Optionally, pass a string here as an alias for the data item in descendant contexts
                        function (context) {
                            ko.utils.extend(context, valueAccessor());
                        }), element);
                        // Also tell KO *not* to bind the descendants itself, otherwise they will be bound twice
                        return { controlsDescendantBindings: true };
                    }
                };
                ko.virtualElements.allowedBindings["withModel"] = true;
            })(Views = AppPlayer.Views || (AppPlayer.Views = {}));
        })(AppPlayer || (AppPlayer = {}));
        /// <reference path="viewmarkuprenderer.ts" />
        var AppPlayer;
        (function (AppPlayer) {
            var Views;
            (function (Views) {
                "use strict";

                Views.componentInfos = {
                    "view": {
                        rendererType: Views.ViewMarkupRenderer,
                        events: ["onLoad", "onShow", "onHide", "onDispose"]
                    },
                    "link": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        defaults: { text: "", link: "", visible: true },
                        componentViewModel: function (viewModel) {
                            _a = AppPlayer.destructMany(viewModel.style, ["textOverflow", "wordWrap", "whiteSpace"]), viewModel.textStyle = _a[0], viewModel.style = _a[1];
                            viewModel.clickHandler = AppPlayer.defaultLinkClickHandler;
                            return viewModel;
                            var _a;
                        }
                    },
                    "label": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        defaults: { text: "", visible: true },
                        componentViewModel: function (viewModel) {
                            _a = AppPlayer.destructMany(viewModel.style, ["textOverflow", "wordWrap", "whiteSpace"]), viewModel.textStyle = _a[0], viewModel.style = _a[1];
                            viewModel.htmlText = ko.computed(function () {
                                return AppPlayer.escapeHtml(viewModel.text);
                            });
                            return viewModel;
                            var _a;
                        }
                    },
                    "button": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        events: ["onClick"],
                        componentViewModel: function (viewModel) {
                            var result = $.extend({}, viewModel);
                            result.type = ko.computed(function () {
                                return viewModel.kind === "transparent" ? "normal" : viewModel.kind;
                            });
                            result._classNames = ko.computed(function () {
                                return viewModel.kind === "transparent" ? { transparent: true } : void 0;
                            });
                            return result;
                        }
                    },
                    "input": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        events: ["onChange"]
                    },
                    "image": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        defaults: { src: null, width: "auto", height: "auto", visible: true },
                        events: ["onClick"]
                    },
                    "fileimage": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        defaults: {
                            emptyLabel: "Click or tap to select image",
                            changeImageText: "Take photo or select from gallery",
                            clearText: "Clear",
                            openGalleryText: "Select from gallery",
                            takePhotoText: "Take photo",
                            style: {
                                fontSize: "12px",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                whiteSpace: "normal"
                            }
                        },
                        componentViewModel: function (viewModel) {
                            return new Views.FileImageEditorViewModel(viewModel);
                        }
                    },
                    "icon": {
                        rendererType: Views.ComponentMarkupRenderBase
                    },
                    "textarea": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        events: ["onChange"]
                    },
                    "passbox": {
                        rendererType: Views.PassboxMarkupRender,
                        events: ["onChange"]
                    },
                    "colorpicker": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        events: ["onChange"]
                    },
                    "numberbox": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        defaults: { showSpinButtons: true, value: null },
                        events: ["onValueChanged"]
                    },
                    "radio": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        componentViewModel: function (viewModel) {
                            return AppPlayer.remap(viewModel, { stringItems: "items", stringValue: "value" }, true);
                        }
                    },
                    "actionsheet": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        events: ["onItemClick"]
                    },
                    "switch": {
                        rendererType: Views.ComponentMarkupRenderBase
                    },
                    "loadpanel": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        defaults: {
                            shading: true,
                            shadingColor: "rgba(128,128,128, .2)"
                        }
                    },
                    "datebox": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        events: ["onChange"],
                        componentViewModel: function (viewModel) {
                            return AppPlayer.remap(viewModel, { format: "type" }, true);
                        }
                    },
                    "stackPanel": {
                        rendererType: Views.StackPanelMarkupRender,
                        defaults: {
                            visible: true,
                            orientation: "vertical",
                            verticalAlign: "top",
                            horizontalAlign: "left"
                        }
                    },
                    "list": {
                        rendererType: Views.ListMarkupRender,
                        defaults: {
                            scrollable: true
                        },
                        events: ["onItemClick", "onItemHold", "onPullRefresh"],
                        componentViewModel: function (viewModel) {
                            $.extend(viewModel, viewModel.editConfig);
                            delete viewModel.editConfig;
                            return viewModel;
                        }
                    },
                    "lookup": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        componentViewModel: function (viewModel) {
                            var value = viewModel.value ? ko.unwrap(viewModel.value) : undefined,
                                valueGetter = viewModel.valueExpression ? DevExpress.data.utils.compileGetter(ko.unwrap(viewModel.valueExpression)) : function (value) {
                                return value;
                            };
                            viewModel = AppPlayer.remap(viewModel, { valueExpression: "valueExpr", displayExpression: "displayExpr" }, true);
                            if (viewModel && ko.unwrap(viewModel.items)) {
                                if ($.isArray(ko.unwrap(viewModel.items))) {
                                    ko.unwrap(viewModel.items).forEach(function (item) {
                                        if (JSON.stringify(value) === JSON.stringify(valueGetter(item))) {
                                            viewModel.value(valueGetter(item));
                                        }
                                    });
                                }
                            }
                            return viewModel;
                        }
                    },
                    "tabpanel": {
                        rendererType: Views.TabsMarkupRender,
                        defaults: {
                            style: {}
                        }
                    },
                    "tabs": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        defaults: {
                            showNavButtons: false
                        }
                    },
                    "accordion": {
                        rendererType: Views.AccordionMarkupRender
                    },
                    "datagrid": {
                        rendererType: Views.ComponentMarkupRenderBase,
                        events: ["onRowClick"],
                        componentViewModel: function (viewModel) {
                            var dataSource = ko.unwrap(viewModel.dataSource);
                            if (dataSource && dataSource["_calculatedFields"]) {
                                var calculatedFields = dataSource["_calculatedFields"];
                                viewModel.onRowUpdating = function (rowInfo) {
                                    var newData = rowInfo.newData;
                                    $.each(newData, function (name, value) {
                                        if (AppPlayer.findInArray(calculatedFields, function (m) {
                                            return m.name === name;
                                        })) {
                                            delete newData[name];
                                        }
                                    });
                                };
                            }
                            return viewModel;
                        }
                    },
                    "row": {
                        rendererType: Views.RowMarkupRender,
                        defaults: { visible: true }
                    },
                    "column": {
                        rendererType: Views.ComponentMarkupRenderBase
                    },
                    "fieldset": {
                        rendererType: Views.FieldsetMarkupRender,
                        defaults: { visible: true }
                    },
                    "form": {
                        rendererType: Views.FormMarkupRenderer,
                        defaults: { visible: true }
                    },
                    "command": {
                        rendererType: Views.CommandMarkupRender,
                        defaults: { visible: true, disabled: false, buttonType: "normal" },
                        events: ["onExecute"]
                    },
                    "scrollview": {
                        rendererType: Views.ScrollViewMarkupRender
                    }
                };
            })(Views = AppPlayer.Views || (AppPlayer.Views = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Views;
            (function (Views) {
                "use strict";

                var dxdevice = DevExpress.devices;
                var FileImageEditorViewModel = function () {
                    function FileImageEditorViewModel(options) {
                        var _this = this;
                        this.PHOTOLIBRARY = 0;
                        this.CAMERA = 1;
                        this.actionSheetOptions = ko.observable(null);
                        this.fileSelected = function (_model, event) {
                            var fileInput = event.currentTarget.parentElement.getElementsByTagName("input")[0];
                            _this._handleFiles(event.target, _this.value);
                            fileInput.value = null;
                        };
                        this["style"] = options.style;
                        this.value = options.value || ko.observable();
                        this.visible = options.visible;
                        this.imageSrc = ko.computed(function () {
                            return FileImageEditorViewModel.addBase64Header(ko.unwrap(ko.unwrap(_this.value)));
                        });
                        this.emptyLabelVisible = ko.computed(function () {
                            return !_this.imageSrc();
                        });
                        this.imageStyle = ko.computed(function () {
                            var style = _this["style"],
                                width = !isNaN(parseInt(style.width, 10)) ? style.width : undefined,
                                height = !isNaN(parseInt(style.height, 10)) ? style.height : undefined;
                            if (_this.emptyLabelVisible()) {
                                return { width: width || height, height: height || width };
                            }
                            return { width: width || "auto", height: height || "auto" };
                        });
                        this.emptyLabel = options.emptyLabel;
                        this.clearText = options.clearText;
                        this.takePhotoText = options.takePhotoText;
                        this.openGalleryText = options.openGalleryText;
                    }
                    FileImageEditorViewModel.addBase64Header = function (value) {
                        if (value == null || value === "(Image)" || value === "") {
                            return null;
                        }
                        return AppPlayer.startsWith(value, "http") ? value : this.fullBase64Header + this.removeBase64Header(value);
                    };
                    FileImageEditorViewModel.removeBase64Header = function (value) {
                        if (value !== null) {
                            var index = value.indexOf(this.base64Header);
                            return index === -1 ? value : value.substr(index + this.base64Header.length);
                        }
                    };
                    FileImageEditorViewModel.prototype._getActionSheetOption = function (event) {
                        var _this = this;
                        var isDesktop = dxdevice.current().deviceType === "desktop",
                            isCordova = !!window["cordova"],
                            dataSource = [{
                            text: this.takePhotoText,
                            fileSelected: this.fileSelected,
                            touchStart: function () {},
                            visible: isCordova,
                            click: function (args) {
                                _this._cordovaCameraDelegate(_this.CAMERA);
                            }
                        }, {
                            text: this.openGalleryText,
                            fileSelected: this.fileSelected,
                            touchStart: function () {
                                if (!isCordova) {
                                    _this.control.hide();
                                    _this.showFileDialog(event);
                                }
                            },
                            visible: true,
                            click: function (args) {
                                if (isCordova) {
                                    _this._cordovaCameraDelegate(_this.PHOTOLIBRARY);
                                } else {
                                    _this.showFileDialog(event);
                                }
                            }
                        }, {
                            text: this.clearText,
                            fileSelected: this.fileSelected,
                            visible: !this.emptyLabelVisible(),
                            touchStart: function () {},
                            click: function () {
                                _this.value(null);
                            }
                        }];
                        return {
                            target: event.currentTarget,
                            usePopover: isDesktop,
                            visible: ko.observable(false),
                            showTitle: false,
                            width: isDesktop ? "auto" : undefined,
                            dataSource: dataSource,
                            onItemClick: function (eventArgs) {
                                eventArgs.itemData.click(eventArgs);
                            },
                            onInitialized: function (args) {
                                _this.control = args.component;
                            }
                        };
                    };
                    FileImageEditorViewModel.prototype._cordovaCameraDelegate = function (sourceType) {
                        if (sourceType === void 0) {
                            sourceType = this.CAMERA;
                        }
                        var onSuccess = function (imageData) {
                            this.value(imageData);
                        },
                            onFail = function (message) {
                            console.log("Failed because: " + message);
                        };
                        navigator["camera"].getPicture(onSuccess.bind(this), onFail, { quality: 50, destinationType: 0, sourceType: sourceType });
                    };
                    ;
                    FileImageEditorViewModel.prototype._handleFiles = function (filesHolder, value) {
                        var files = filesHolder.files;
                        for (var i = 0; i < files.length; i++) {
                            var file = files[i];
                            var imageType = /image.*/;
                            if (!file.type.match(imageType)) {
                                continue;
                            }
                            var fr = new FileReader();
                            fr.onload = function (args) {
                                //var encodedImage = fr.result.replace(/^data:[^,]+,/, '');
                                value(FileImageEditorViewModel.removeBase64Header(fr.result));
                            };
                            fr.readAsDataURL(file);
                        }
                    };
                    ;
                    FileImageEditorViewModel.prototype.showFileDialog = function (args) {
                        var fileInput = args.currentTarget.parentElement.getElementsByTagName("input")[0];
                        if (fileInput) {
                            fileInput.click();
                            args.stopPropagation();
                        }
                    };
                    ;
                    FileImageEditorViewModel.prototype.showFileDialogOrActionSheet = function (_viewModel, args) {
                        this.actionSheetOptions(this._getActionSheetOption(args));
                        if (this.emptyLabelVisible() && !window["cordova"]) {
                            this.showFileDialog(args);
                        } else {
                            this.actionSheetOptions().visible(true);
                        }
                    };
                    ;
                    FileImageEditorViewModel.fullBase64Header = "data:image/png;base64,";
                    FileImageEditorViewModel.base64Header = "base64,";
                    return FileImageEditorViewModel;
                }();
                Views.FileImageEditorViewModel = FileImageEditorViewModel;
            })(Views = AppPlayer.Views || (AppPlayer.Views = {}));
        })(AppPlayer || (AppPlayer = {}));
        /// <reference path="viewmarkuprenderer.ts" />
        var AppPlayer;
        (function (AppPlayer) {
            var Views;
            (function (Views) {
                "use strict";

                var View = function () {
                    function View(viewConfig, application, rootElement) {
                        if (AppPlayer.findInArray(viewConfig.params, function (p) {
                            return !!p.shared;
                        })) {
                            viewConfig.disableCache = true;
                        }
                        this.viewMarkup = $(new Views.ViewMarkupRenderer(viewConfig, application).render());
                        this.viewModel = function () {
                            var vm = new Views.ViewModel(viewConfig, application);
                            return vm.model;
                        };
                    }
                    return View;
                }();
                Views.View = View;
            })(Views = AppPlayer.Views || (AppPlayer.Views = {}));
        })(AppPlayer || (AppPlayer = {}));
        /// <reference path="componentsinfo.ts" />
        var AppPlayer;
        (function (AppPlayer) {
            var Views;
            (function (Views) {
                "use strict";

                var dxdata = DevExpress.data;
                var ViewModel = function () {
                    function ViewModel(viewConfig, application) {
                        var _this = this;
                        this.events = {};
                        this.alreadyShown = false;
                        viewConfig.model = viewConfig.model || [];
                        this.model = AppPlayer.Model.createModel(viewConfig, application);
                        this.viewConfig = viewConfig;
                        this.patchEvents(application);
                        this.model["_functions"] = application.functions;
                        this.model["_global"] = application.model;
                        this.model["_scrollViewResetter"] = { reset: function () {} };
                        if ((viewConfig.model || []).filter(function (item) {
                            return item.name === "title";
                        }).length === 0) {
                            this.model["title"] = ko.pureComputed(function () {
                                return AppPlayer.getModelValue(viewConfig.title || "", { $global: application.model, $model: _this.model }, { callerId: "title", callerType: "View model" }, application.functions);
                            });
                        }
                        var _parametersAreReady = ko.observable(viewConfig.params ? viewConfig.params.length === 0 : true);
                        this.model.isReady = ko.observable(false);
                        this.model["viewShowing"] = function (config) {
                            if (!_this.alreadyShown || viewConfig.refreshWhenShown) {
                                _this.setModelValueFromParameter(application, _parametersAreReady, config && config.params && config.params.parameters);
                            }
                            var popup = ((config.viewInfo || {}).layoutController || {})._popup;
                            if (popup) {
                                ["height", "width"].forEach(function (property) {
                                    if (viewConfig[property]) {
                                        popup.option(property, viewConfig[property]);
                                        if (popup.option("fullScreen")) {
                                            popup.option("fullScreen", false);
                                        }
                                    }
                                });
                            }
                        };
                        this.model["viewShown"] = function (config) {
                            if (!_this.alreadyShown) {
                                ko.computed(function () {
                                    _this.model.isReady(ko.unwrap(_parametersAreReady));
                                });
                                AppPlayer.Model.initializeDataSources(_this.model, { $model: _this.model, $global: application.model }, application, application.stores, false, viewConfig.dataSources);
                                _this.alreadyShown = true;
                            } else if (viewConfig.refreshWhenShown) {
                                AppPlayer.Model.initializeDataSources(_this.model, { $model: _this.model, $global: application.model }, application, application.stores, true, viewConfig.dataSources);
                                _this.model["_scrollViewResetter"].reset();
                            }
                            if (!_this.refreshStrategies) {
                                _this.refreshStrategies = _this.createRefreshStrategies(application, config && config.params);
                            } else {
                                _this.refreshStrategies.forEach(function (strategy) {
                                    strategy.enabled = true;
                                    strategy.refresh();
                                });
                            }
                            _this.onEvent("onShow", config && config.params && config.params.parameters);
                        };
                        this.model["viewHidden"] = function () {
                            if (viewConfig.refreshWhenShown) {
                                _parametersAreReady(false);
                                _this.clearModel(application);
                            }
                            _this.refreshStrategies.forEach(function (strategy) {
                                strategy.hidden();
                            });
                            _this.onEvent("onHide");
                        };
                        this.model["viewDisposing"] = function () {
                            _this.model.dispose();
                            if (_this.refreshStrategies) {
                                _this.refreshStrategies.forEach(function (strategy) {
                                    strategy.dispose();
                                });
                                _this.refreshStrategies.splice(0, _this.refreshStrategies.length);
                            }
                            _this.onEvent("onDispose");
                        };
                        this.onEvent("onLoad");
                    }
                    ViewModel.optional = function (param) {
                        return param.defaultValue !== void 0;
                    };
                    ViewModel.prototype.clearModel = function (application) {
                        var _this = this;
                        var emptyModel = AppPlayer.Model.createModel(this.viewConfig, application);
                        this.viewConfig.model.filter(function (propertyConfig) {
                            return !propertyConfig.getter;
                        }).forEach(function (propertyConfig) {
                            var propertyName = propertyConfig.name;
                            _this.model[propertyName] = emptyModel[propertyName];
                        });
                    };
                    ViewModel.prototype.patchEvents = function (application) {
                        var _this = this;
                        var componentInfo = Views.componentInfos["view"];
                        componentInfo.events.forEach(function (eventName) {
                            var event = _this.viewConfig[eventName],
                                functionCompiler;
                            if (!event || !application.createFunctionCompiler) {
                                return;
                            }
                            functionCompiler = application.createFunctionCompiler(event);
                            _this.events[eventName] = function (e) {
                                return functionCompiler.run({
                                    $global: application.model,
                                    $model: _this.model,
                                    $data: e
                                }, {
                                    callerType: "view event",
                                    callerId: eventName
                                });
                            };
                        });
                    };
                    ViewModel.prototype.onEvent = function (eventName, params) {
                        var handler = this.events[eventName];
                        if (handler) {
                            handler(params);
                        }
                    };
                    ViewModel.prototype.createRefreshStrategies = function (application, viewParameters) {
                        var _this = this;
                        var refreshStrategies = [];
                        $.each(this.model, function (index, value) {
                            if (!(value instanceof dxdata.DataSource)) {
                                return;
                            }
                            var ds = value,
                                refreshStrategy = Views.DataSourceRefreshStrategy.create(ds);
                            if (refreshStrategy) {
                                refreshStrategies.push(refreshStrategy);
                            }
                            if (ds["_monitor"] && ds["_monitor"].stores && ds["_monitor"].stores.length > 0) {
                                refreshStrategies.push(new Views.MonitorRefreshStrategy(ds, application, ds["_monitor"].stores));
                            }
                        });
                        if (this.viewConfig.params) {
                            this.viewConfig.params.forEach(function (parameter) {
                                var typeInfo = application.typeInfoRepository.get(parameter.type);
                                if (typeInfo && typeInfo.kind === AppPlayer.TYPES.STORE_TYPE) {
                                    var refreshStrategy = Views.ParameterRefreshStrategy.create(parameter, _this.model, application, viewParameters);
                                    if (refreshStrategy) {
                                        refreshStrategies.push(refreshStrategy);
                                    }
                                }
                            });
                        }
                        return refreshStrategies;
                    };
                    ViewModel.prototype.setModelValueFromParameter = function (application, isReady, params) {
                        var _this = this;
                        var parametersLoadingCount = 0;
                        if (this.viewConfig.params && this.viewConfig.params.length) {
                            this.viewConfig.params.forEach(function (paramConfig) {
                                var typeInfo = application.typeInfoRepository.get(paramConfig.type);
                                if (paramConfig.shared) {
                                    if (typeof application.sharedObjects[paramConfig.name] === "undefined") {
                                        console.error("Shared parameter '" + paramConfig.name + "' is missing from the sharedObjects collection.");
                                    }
                                    _this.model[paramConfig.name] = application.sharedObjects[paramConfig.name];
                                } else if (typeInfo && typeInfo.kind === AppPlayer.TYPES.STORE_TYPE) {
                                    var objectKey = params && params[paramConfig.name];
                                    if (objectKey) {
                                        var store = application.stores[paramConfig.type];
                                        parametersLoadingCount++;
                                        store.byKey(objectKey, { expand: paramConfig.expand }).then(function (data) {
                                            _this.model[paramConfig.name] = data;
                                        }, function () {
                                            application.processParameterLoadingError(paramConfig.name, objectKey);
                                        }).always(function () {
                                            parametersLoadingCount--;
                                            isReady(!parametersLoadingCount);
                                        });
                                    } else {
                                        _this.model[paramConfig.name] = paramConfig.defaultValue;
                                    }
                                } else {
                                    _this.model[paramConfig.name] = params && params[paramConfig.name] || paramConfig.defaultValue;
                                }
                            });
                        }
                        isReady(parametersLoadingCount === 0);
                    };
                    return ViewModel;
                }();
                Views.ViewModel = ViewModel;
            })(Views = AppPlayer.Views || (AppPlayer.Views = {}));
        })(AppPlayer || (AppPlayer = {}));
        var AppPlayer;
        (function (AppPlayer) {
            var Views;
            (function (Views) {
                "use strict";

                var DataSourceRefreshStrategy = function () {
                    function DataSourceRefreshStrategy(ds) {
                        this.ds = ds;
                        this.enabled = true;
                    }
                    DataSourceRefreshStrategy.create = function (ds) {
                        switch (ds["_refreshOnViewShown"]) {
                            case "never":
                                return null;
                            case "always":
                                return new DataSourceRefreshStrategy(ds);
                            case "whenChanges":
                            default:
                                return new WhenChangesSourceRefreshStrategy(ds);
                        }
                    };
                    DataSourceRefreshStrategy.prototype.refresh = function () {
                        this.ds.load();
                    };
                    DataSourceRefreshStrategy.prototype.dispose = function () {};
                    DataSourceRefreshStrategy.prototype.hidden = function () {
                        this.enabled = false;
                    };
                    return DataSourceRefreshStrategy;
                }();
                Views.DataSourceRefreshStrategy = DataSourceRefreshStrategy;
                var WhenChangesSourceRefreshStrategy = function (_super) {
                    __extends(WhenChangesSourceRefreshStrategy, _super);
                    function WhenChangesSourceRefreshStrategy(ds) {
                        var _this = this;
                        _super.call(this, ds);
                        this.ds = ds;
                        this.callback = function () {
                            _this.modified = true;
                            if (_this.enabled) {
                                _this.refresh();
                            }
                        };
                        this.ds.store().on("modified", this.callback);
                    }
                    WhenChangesSourceRefreshStrategy.prototype.refresh = function () {
                        if (this.modified) {
                            this.modified = false;
                            _super.prototype.refresh.call(this);
                        }
                    };
                    WhenChangesSourceRefreshStrategy.prototype.dispose = function () {
                        this.ds.store().off("modified", this.callback);
                    };
                    return WhenChangesSourceRefreshStrategy;
                }(DataSourceRefreshStrategy);
                var ParameterRefreshStrategy = function () {
                    function ParameterRefreshStrategy(param, model, application, viewParameters) {
                        this.enabled = true;
                        this.param = param;
                        this.model = model;
                        this.application = application;
                        this.store = application.stores[param.type];
                    }
                    ParameterRefreshStrategy.create = function (param, model, application, viewParameters) {
                        switch (param.refreshOnViewShown) {
                            case "never":
                                return null;
                            case "always":
                                return new ParameterRefreshStrategy(param, model, application, viewParameters);
                            case "whenChanges":
                            default:
                                return new WhenChangesParameterRefreshStrategy(param, model, application, viewParameters);
                        }
                    };
                    ParameterRefreshStrategy.prototype.refresh = function () {
                        var _this = this;
                        var key = this.store.keyOf(this.model[this.param.name]);
                        if (key) {
                            this.store.byKey(key, { expand: this.param.expand }).done(function (data) {
                                _this.model[_this.param.name] = data;
                            });
                        }
                    };
                    ParameterRefreshStrategy.prototype.dispose = function () {};
                    ParameterRefreshStrategy.prototype.hidden = function () {
                        this.enabled = false;
                    };
                    return ParameterRefreshStrategy;
                }();
                Views.ParameterRefreshStrategy = ParameterRefreshStrategy;
                var WhenChangesParameterRefreshStrategy = function (_super) {
                    __extends(WhenChangesParameterRefreshStrategy, _super);
                    function WhenChangesParameterRefreshStrategy(param, model, application, viewParameters) {
                        var _this = this;
                        _super.call(this, param, model, application, viewParameters);
                        this.modified = false;
                        this.removed = false;
                        var objectKey = viewParameters.parameters ? viewParameters.parameters[param.name] : undefined;
                        this.insertedCallback = function (values, key) {
                            if (key === objectKey) {
                                _this.modified = true;
                                if (_this.enabled) {
                                    _this.refresh();
                                }
                            }
                        };
                        this.store.on("inserted", this.insertedCallback);
                        this.updatedCallback = function (key, values) {
                            if (!_this.enabled && (objectKey === undefined || key === objectKey)) {
                                _this.modified = true;
                                if (_this.enabled) {
                                    _this.refresh();
                                }
                            }
                        };
                        this.store.on("updated", this.updatedCallback);
                    }
                    WhenChangesParameterRefreshStrategy.prototype.refresh = function () {
                        if (this.modified) {
                            this.modified = false;
                            _super.prototype.refresh.call(this);
                        }
                    };
                    WhenChangesParameterRefreshStrategy.prototype.dispose = function () {
                        this.store.off("inserted", this.insertedCallback);
                        this.store.off("updated", this.updatedCallback);
                    };
                    return WhenChangesParameterRefreshStrategy;
                }(ParameterRefreshStrategy);
                var MonitorRefreshStrategy = function () {
                    function MonitorRefreshStrategy(ds, application, storeIds) {
                        var _this = this;
                        this.ds = ds;
                        this.application = application;
                        this.storeIds = storeIds;
                        this.enabled = true;
                        this.modified = false;
                        this.refreshFunc = function () {
                            _this.modified = true;
                            _this.refresh();
                        };
                        this.storeIds.forEach(function (storeId) {
                            var store = _this.application.stores[storeId];
                            store.on("modified", _this.refreshFunc);
                        });
                    }
                    MonitorRefreshStrategy.prototype.refresh = function () {
                        if (this.enabled) {
                            this.ds.load();
                            this.modified = false;
                        }
                    };
                    MonitorRefreshStrategy.prototype.dispose = function () {
                        var _this = this;
                        this.storeIds.forEach(function (storeId) {
                            var store = _this.application.stores[storeId];
                            store.off("modified", _this.refreshFunc);
                        });
                    };
                    MonitorRefreshStrategy.prototype.hidden = function () {
                        this.enabled = false;
                    };
                    return MonitorRefreshStrategy;
                }();
                Views.MonitorRefreshStrategy = MonitorRefreshStrategy;
            })(Views = AppPlayer.Views || (AppPlayer.Views = {}));
        })(AppPlayer || (AppPlayer = {}));
        $__global["__extends"] = __extends;
        $__global["AppPlayer"] = AppPlayer;
    })(this);

    return _retrieveGlobal();
});
System.register("appPlayer/templates/viewcomponents.html!github:systemjs/plugin-text@0.0.8.js", [], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      _export("default", "\r\n<script type=\"text/dust\" id=\"xet-dust-link\">\r\n    <!-- ko withModel: { component: 'link', viewModel:{ {bindingString|s} }} -->\r\n    <div class=\"xet-label dx-widget xet-flex-column-widget\" data-bind=\"visible: visible, style: $data.style\">\r\n        {@if cond=\"'{model.link}'.length && '{model.link}'.charAt(5) === '#'\"}\r\n        <a class=\"xet-label-value\" data-bind=\"text: text, visible: visible, dxAction: $data.link, style: $data.textStyle, attr: { href: $data.link }\"></a>\r\n        {:else}\r\n        <a class=\"xet-label-value\" data-bind=\"text: text, visible: visible, click: $data.clickHandler, style: $data.textStyle, attr: { href: $data.link }\"></a>\r\n        {/if}\r\n    </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/dust\" id=\"xet-dust-label\">\r\n    <!-- ko withModel: { component: 'label', viewModel:{ {bindingString|s} }} -->\r\n        <div class=\"xet-label dx-widget xet-flex-column-widget\" data-bind=\"visible: visible, style: $data.style\">\r\n            <div class=\"xet-label-value\" data-bind=\"html: htmlText, style: $data.textStyle\"></div>\r\n        </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-stackPanel\">\r\n    <!-- ko withModel: { component: 'stackPanel', viewModel:{ {model.stackPanel.bindingString|s} }} -->\r\n        <!-- ko if: $data.scrollable -->\r\n            <div class=\"xet-stack-panel\" data-bind=\"visible: visible, style: otherStyles\">\r\n                <div class=\"xet-scroller xet-scroll-view\" data-bind=\"dxScrollView: {direction: orientation}, style: flexStyles\">\r\n                    <div class=\"xet-inscroller\" data-bind=\"style: flexStyles\">\r\n                        {#model}\r\n                        {>\"xet-dust-inflex-components\" /}\r\n                        {/model}\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        <!-- /ko --> \r\n        <!-- ko if: !$data.scrollable -->\r\n            <div class=\"xet-stack-panel test-stack-panel\" data-bind=\"visible: visible, style: style\">\r\n                {#model}\r\n                    {>\"xet-dust-inflex-components\" /}\r\n                {/model}\r\n                </div>\r\n        <!-- /ko -->\r\n<!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-button\">\r\n    <!-- ko withModel: { component: 'button', viewModel:{ {bindingString|s} }} -->\r\n        <div class=\"xet-button\" data-bind=\"style: $data.style, dxButton: $data, css: $data._classNames\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-radio\">\r\n    <!-- ko withModel: { component: 'radio', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxRadioGroup: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-textarea\">\r\n    <!-- ko withModel: { component: 'textarea', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxTextArea: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-input\">\r\n    <!-- ko withModel: { component: 'input', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxTextBox: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-image\">\r\n    <!-- ko withModel: { component: 'image', viewModel:{ {bindingString|s} }} -->\r\n        <img data-bind=\"attr: { src: $data.src, width: width, height: height }, visible: visible, style: $data.style, click: $data.onClick\" />\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-fileimage\">\r\n    <!-- ko withModel: { component: 'fileimage', viewModel:{ {bindingString|s} }} -->\r\n    <div class=\"xet-fileimage\" data-bind=\"style: $data.style\">\r\n        <!-- ko if: actionSheetOptions -->\r\n        <div data-bind=\"dxActionSheet: actionSheetOptions\" >\r\n            <div data-bind=\"event: { touchstart: touchStart}, dxButton: { text: text }, visible: visible \"></div>\r\n        </div>\r\n        <!-- /ko -->\r\n        <input type=\"file\" accept=\"image/x\" style=\"display: none;\" data-bind=\"event: { change: fileSelected }\" />\r\n        <div  class=\"xet-fileimage-container\" data-bind=\"click: showFileDialogOrActionSheet\">\r\n            <img class=\"xet-fileimage-background-image\" data-bind=\"attr: { src: $data.imageSrc() }, style: imageStyle, visible: !emptyLabelVisible()\"/>\r\n            <span class=\"xet-empty-label\" data-bind=\"style: imageStyle, visible: emptyLabelVisible, text: emptyLabel\"></span>\r\n        </div>\r\n    </div>    \r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-icon\">\r\n    <!-- ko withModel: { component: 'icon', viewModel:{ {bindingString|s} }} -->\r\n    <div data-bind=\"style: $data.style\">\r\n        <!-- ko dxIcon: $data.icon || $data.iconSrc --><!-- /ko -->\r\n    </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/dust\" id=\"xet-dust-switch\">\r\n    <!-- ko withModel: { component: 'switch', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxSwitch: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/dust\" id=\"xet-dust-actionsheet\">\r\n    <!-- ko withModel: { component: 'actionsheet', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxActionSheet: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/dust\" id=\"xet-dust-loadpanel\">\r\n    <!-- ko withModel: { component: 'loadpanel', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxLoadPanel: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-datebox\">\r\n    <!-- ko withModel: { component: 'datebox', viewModel:{ {bindingString|s} }} -->\r\n        <div class=\"xet-datebox\" data-bind=\"style: $data.style,  dxDateBox: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-numberbox\">\r\n    <!-- ko withModel: { component: 'numberbox', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxNumberBox: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-passbox\">\r\n    <!-- ko withModel: { component: 'passbox', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxTextBox: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-colorpicker\">\r\n    <!-- ko withModel: { component: 'colorpicker', viewModel:{ {bindingString|s} }} -->\r\n    <div class=\"xet-color-picker\" data-bind=\"style: $data.style, dxColorBox: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-datagrid\">\r\n    <!-- ko withModel: { component: 'datagrid', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxDataGrid: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-lookup\">\r\n    <!-- ko withModel: { component: 'lookup', viewModel:{ {bindingString|s} }} -->\r\n        <div data-bind=\"style: $data.style, dxLookup: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-fieldset\">\r\n    <!-- ko withModel: { component: 'fieldset', viewModel:{ {model.fieldset.bindingString|s} }} -->\r\n        <div style=\"display: block; align-self: stretch\" class=\"{@if cond=\"{model.singleColumnLayout}\"}xet-single-column-fieldset{:else}dx-fieldset{/if}\" data-bind=\"style: $data.style, visible: visible\">\r\n            {@if cond=\"{model.singleColumnLayout}\"}\r\n                {#model.fields}\r\n                    <!-- ko withModel: { viewModel: { {bindingString|s} } } -->\r\n                    <div class=\"dx-field\" data-bind=\"visible: visible\">\r\n                        <div class=\"xet-label dx-widget xet-fieldset-sigle-column-label\" style=\"overflow: hidden;\" data-bind=\"text: title\"></div>\r\n                        {>\"xet-dust-{model.type}\" /}\r\n                    </div>\r\n                    <!-- /ko -->\r\n                {/model.fields}\r\n            {:else}\r\n                {#model.fields}\r\n                    <!-- ko withModel: { viewModel: { {bindingString|s} } } -->\r\n                    <div class=\"dx-field\" data-bind=\"visible: visible\">\r\n                        <div class=\"dx-field-label\">\r\n                            <div data-bind=\"text: title\"></div>\r\n                        </div>\r\n                        <div class=\"dx-field-value\">\r\n                            {>\"xet-dust-{model.type}\" /}\r\n                        </div>\r\n                    </div>\r\n                    <!-- /ko -->\r\n                {/model.fields}\r\n            {/if}\r\n        </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-tabs\">\r\n    <!-- ko withModel: { component: 'tabs', viewModel:{ {bindingString|s} } } -->\r\n    <div style=\"display: table\" data-bind=\"style: $data.style, dxTabs: $data\"></div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-tabpanel\">\r\n    <!-- ko withModel: { component: 'tabpanel', nestedTemplateModel: false,  viewModel: { {model.control.bindingString|s}} } -->\r\n        <div class=\"xet-flex-column-widget\" data-bind=\"style: style, dxTabPanel: tabpanel\">\r\n            {#model.tabs}\r\n                <div data-options=\"dxItem: { title: {title} }\">\r\n                    {@if cond=\"{scrollable}\"}\r\n                        {>\"xet-dust-scrollview-embedded\" /}\r\n                    {:else}\r\n                        {>\"xet-dust-flex\" /}\r\n                    {/if}\r\n                </div>\r\n            {/model.tabs}\r\n        </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-accordion\">\r\n    <!-- ko withModel: { component: 'accordion', nestedTemplateModel: false,  viewModel: { {model.control.bindingString|s}} } -->\r\n        <div data-bind=\"style: style, dxAccordion: options\">\r\n            {#model.panels}\r\n                <div data-options=\"dxItem: { title: {title} }\">\r\n                    {>\"xet-dust-flex\" /}\r\n                </div>\r\n            {/model.panels}\r\n        </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-row\">\r\n    <!-- ko withModel: { component: 'row', viewModel:{ {model.row.bindingString|s} }} -->\r\n        <div class=\"xet-row row-fluid\" data-bind=\"style: $data.style, visible: $data.visible\">\r\n            {#model.columns}\r\n                <!-- ko withModel: { component: 'column', viewModel:{ {style.bindingString|s} }} -->\r\n                    <div class=\"xet-row-column {bootstrapColStyle}\" data-bind=\"style: $data\">\r\n                        {>\"xet-dust-components\" /}\r\n                    </div>\r\n                <!-- /ko -->\r\n            {/model.columns}\r\n        </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-list\">\r\n    <!-- ko withModel: { component: 'list', nestedTemplateModel: true, viewModel: { {model.list.bindingString|s} } } -->\r\n        <div class=\"xet-list xet-flex-column-widget\" data-bind=\"style: $data.style, dxList: $data\">\r\n            {@if cond=\"'{model.itemComponents}'.length\"}\r\n                <div data-options=\"dxTemplate: { name: 'item' }\" style=\"position: relative;\">\r\n                    <div class=\"xet-flex-interlayer\">\r\n                        {#model.itemComponents}\r\n                            {>\"xet-dust-inflex-component\" /}\r\n                        {/model.itemComponents}                        \r\n                    </div>\r\n                </div>\r\n            {/if}\r\n            {@if cond=\"'{model.group}'.length\"}\r\n                <div data-options=\"dxTemplate: { name: 'group' }\" style=\"position: relative;\">\r\n                    <div class=\"xet-flex-interlayer\">\r\n                        {#model.groupComponents}\r\n                            {>\"xet-dust-inflex-component\" /}\r\n                        {/model.groupComponents}\r\n                    </div>\r\n                </div>\r\n            {/if}\r\n        </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n\r\n<script type=\"text/html\" id=\"xet-dust-form\">\r\n    <!-- ko withModel: { component: 'form', viewModel:{ {model.form.bindingString|s} }} -->\r\n    <div style=\"display: block\" data-bind=\"style: $data.style, dxForm: $data\">\r\n        {#model.components}\r\n        <div data-options=\"dxTemplate: { name: {model.templateName} }\">\r\n            {>\"xet-dust-{model.type}\" /}\r\n        </div>\r\n        {/model.components}        \r\n    </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-scrollview\">\r\n    <!-- ko withModel: { component: 'scrollview', nestedTemplateModel: false, viewModel: { {model.scrollview.bindingString|s} } } -->\r\n        <div class=\"xet-scroll-view\" style=\"display: flex;\" data-bind=\"style: $data.style, dxScrollView: $data\">\r\n            {#.model}\r\n                {>\"xet-dust-flex\" /}\r\n            {/.model}\r\n        </div>\r\n    <!-- /ko -->\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-scrollview-embedded\">\r\n    <div class=\"xet-scroll-view\"  style=\"display: flex;\" data-bind=\"dxScrollView\">\r\n        {>\"xet-dust-flex\" /}\r\n    </div>\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-option-bindings\">\r\n    {~lb}\r\n        {#options}\r\n            {name}: {value},\r\n        {/options}\r\n    {~rb}\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-simple-bindings\">\r\n    {#options}\r\n        {name}: {value},\r\n    {/options}\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-bindings\">\r\n    {~lb}\r\n        {>\"xet-dust-simple-bindings\" /}\r\n    {~rb}\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-components\">\r\n    {#.components}\r\n        {>\"xet-dust-{model.type}\" /}\r\n    {/.components}\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-inflex-component\">\r\n    <div  data-bind=\"preventCollapsingInSafari\" class=\"xet-flex-widget {@if cond=\"{preventShrink}\"}xet-prevent-shrink{/if}\" />\r\n    {#component}\r\n        {>\"xet-dust-{model.type}\" /}\r\n    {/component}\r\n</script>\r\n\r\n\r\n<script type=\"text/html\" id=\"xet-dust-inflex-components\">\r\n    {#.components}\r\n        {>\"xet-dust-inflex-component\" /}\r\n    {/.components}\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-flex\">\r\n    <div class=\"xet-flex-interlayer\">\r\n        {>\"xet-dust-inflex-components\" /}\r\n    </div>\r\n</script>\r\n\r\n<script type=\"text/html\" id=\"xet-dust-view\">\r\n    <div data-options=\"dxView : { {bindingString|s} }\">\r\n        <div data-options=\"dxContent : { targetPlaceholder: 'content' }\" class=\"dx-detail-view dx-content-background\" data-bind=\"xetScrollViewResetter: _scrollViewResetter\">\r\n            {#model}\r\n                {#commands}\r\n                    <!-- ko withModel: { component: 'command', viewModel:{ {bindingString|s} }} -->\r\n                        <div data-bind=\"dxCommand: $data\"></div>\r\n                    <!-- /ko -->\r\n                {/commands}\r\n                <div class=\"dx-full-height\" data-bind=\"dxDeferRendering: { showLoadIndicator: !!window.cordova, animation: 'view-content-rendered', renderWhen: isReady, onRendered: $data.onViewRendered }\">\r\n                    {@if cond=\"{scrollable}\"}\r\n                        {>\"xet-dust-scrollview-embedded\" /}\r\n                    {:else}\r\n                        {>\"xet-dust-flex\" /}\r\n                    {/if}\r\n                </div>\r\n            {/model}\r\n        </div>\r\n    </div>\r\n</script>\r\n");
    }
  };
});
System.register("appPlayer/appPlayerLoader.js", ["appPlayer/content/app-player.css!", "appPlayer/appPlayer", "appPlayer/templates/viewcomponents.html!text"], function (_export) {
  "use strict";

  var htmlTemplate;
  return {
    setters: [function (_appPlayerContentAppPlayerCss) {}, function (_appPlayerAppPlayer) {}, function (_appPlayerTemplatesViewcomponentsHtmlText) {
      htmlTemplate = _appPlayerTemplatesViewcomponentsHtmlText["default"];
    }],
    execute: function () {
      AppPlayer.Utils.appendHtml(document.body, htmlTemplate);
    }
  };
});
