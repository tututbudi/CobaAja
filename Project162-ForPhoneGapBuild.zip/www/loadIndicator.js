"use strict";

if (window.createLoadingIndicator) {
    var loadingIndicator = window.createLoadingIndicator(Object.keys(System.bundles).length);
    exports.translate = function (load) {
        loadingIndicator.updateLoadingProgress();
        return load.source;
    }
} else {
    exports.translate = function (load) {
        return load.source;
    }
}


